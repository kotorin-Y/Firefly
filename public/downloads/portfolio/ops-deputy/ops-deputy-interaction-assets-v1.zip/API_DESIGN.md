﻿# OpsDeputy 接口设计

## 核心原则

- 所有外部系统都通过 Connector 接入。
- 所有自动化能力都通过 Skill 暴露。
- 所有跨步骤流程都通过 Workflow 编排。
- 所有结论都必须能关联 Evidence。
- 高风险动作必须进入 Human Approval。

## Connector 接口

已在 `src/architecture/contracts.ts` 定义：

- `LlmProviderConnector`：OpenAI、Anthropic、Google、Qwen、本地模型、私有模型。
- `KnowledgeBaseConnector`：Notion、Confluence、飞书知识库、语雀、SharePoint、Google Drive、OneDrive、本地文件夹。
- `CollaborationConnector`：Slack、Teams、飞书、企业微信、钉钉、邮件。
- `GithubConnector`：GitHub App、Repo、Issue、PR、Webhook、Actions。
- `AdsPlatformConnector`：TikTok、小红书、抖音、Meta、Google Ads、Amazon Ads、腾讯广告。
- `CommentCrawlerConnector`：包装现有 `comment_crawler.py`。

## API 路由

已在 `src/architecture/apiContracts.ts` 定义：

- `POST /api/agent/chat`：顶部 LLM 对话栏与 Agent 调度。
- `GET /api/dashboard/overview`：首页四项核心看板。
- `POST /api/connectors`：新增外部系统接入。
- `POST /api/connectors/test`：测试API 地址、凭证和权限状态。
- `POST /api/connectors/read`：读取授权资源预览，写入 Evidence Store 或本地数据缓存。
- `POST /api/workflows/run`：运行 Dify 式工作流。
- `POST /api/data/sql/run`：调用 SQLite 文件或 HTTP SQL 网关，返回结构化行数据。
- `POST /api/data/export`：按数据类型输出 XLS 或 CSV。
- `POST /api/crawlers/ad-platforms/run`：运行平台投放采集。
- `POST /api/crawlers/comments/run`：运行评论舆情抓取。
- `POST /api/knowledge/sync`：同步知识库。
- `POST /api/collaboration/tasks`：创建协同任务。
- `POST /api/reports`：由工作流输出节点或办公协同生成报告类文档。
- `GET /api/monitor/events`：读取 24h 监控事件。

## 旧评论抓取工具包装

生产实现建议：

1. UI 选择平台、URL、配置文件、关键词、评分阈值和时间窗口。
2. API 写入任务队列。
3. Worker 调用 `comment_crawler.py`。
4. SQLite 结果进入 Evidence Store。
5. LLM 总结风险主题。
6. 协同 Connector 推送处理任务。
7. 工作流输出节点或办公协同生成舆情风险报告。

## 平台投放采集

生产实现建议：

- TikTok、Meta、Google Ads 等优先走官方 Marketing / Ads API。
- 小红书、抖音等按实际开放能力使用官方商业平台接口或授权导出报表。
- 无 API 场景提供 CSV/XLSX/JSON 导入。
- Public web 只作为合规低频补充，默认关闭。

## 办公协同读取

- 飞书：优先读取多维表格、知识库和文档库授权资源。
- Microsoft 365：优先使用 Graph API 读取 Drive、Teams、Planner 和 SharePoint。
- Google Workspace：优先读取 Drive、Docs、Sheets 和任务相关资源。
- Slack / 企业微信 / 钉钉：优先读取频道、消息、审批、任务和文档链接。
- 所有读取结果都只保存必要摘要和证据索引，不把凭证明文写入仓库。

