﻿# OpsDeputy 泛用软件蓝图

## 语言与形态选择

主实现选择 Electron + TypeScript，保留 Python 评论抓取工具作为独立 Skill Runtime。

原因：

- 同一套类型契约可复用于 Web 前端、Node.js 后端、Electron 桌面端和 Docker 服务。
- LLM、Skill、Connector、Workflow、Report 都适合用接口定义稳定边界。
- 当前渲染层已经由 TypeScript 编译生成，后续可平滑升级到 React/Vite。
- Python 评论抓取工具可以作为独立 Skill Runtime 保留，通过 Node 子进程或任务队列调用。
- Electron 主进程负责本机导出、SQL 调用、凭证保存、连接测试和离线 EXE。

推荐产品形态：

- 本地轻量版：Electron + TypeScript + 本机配置，适合任意机器快速上手。
- 桌面版：Electron + Node.js + Python Skill Runtime，适合顾问和非技术用户。
- Docker 版：Web UI + API Server + Worker + SQLite/Postgres，适合团队。
- 企业私有化：Kubernetes / 私有云 + 权限审计 + 向量库 + 对象存储。

## 软件分层

1. Agent Shell：统一页面、顶部 LLM 对话栏、客户/产品切换。
2. Connector Hub：LLM、GitHub、知识库、办公协同、广告平台、社媒平台、财报股价、CRM、BI、本地文件。
3. Skill Runtime：市场趋势、竞品监控、预算优化、平台投放采集、评论舆情、文档输出。
4. Workflow Engine：参考 Dify 的节点式工作流，支持输入、工具、知识检索、LLM、判断、人审、协同、SQL、输出。
5. Evidence Store：保存 URL、文件、截图、导入批次、抓取时间、模型版本和审批记录。
6. Governance：租户、角色、权限、限额、审计、合规采集策略。

## 页面体系

- 首页：ROI 监控图、预算管理、风险建议、数据分析、顶部 LLM 对话栏，24h 事件内置于此。
- 工作流自动化：Dify 风格节点编排、自由拖拽、毛玻璃右键菜单、删除/复制/重命名/层级调整、定时任务、异常触发、人审和输出。
- 模型 / Skill 管理：LLM Provider、模型路由、成本控制、Skill 权限与 Schema。
- 办公协同：企业文档、知识库、云盘、IM、审批、在线文档，按飞书多维表格模式读取资源。
- 平台投放采集：TikTok、小红书、抖音、Meta、Google 等平台的今日投放数目与看板。
- 舆情风险：内置旧评论抓取工具，生成风险主题、负面样本和证据包。
- 接口设置：GitHub App、Repo、Issue、PR、Webhook、CRM、BI、SQL、财报股价、社媒账号和 API 配置。

不设置独立报告中心模块；XLS / CSV 输出放在每个可视化数据下方，文档类报告由工作流输出节点或办公协同生成。

产品内不设置快速上手页面，不展示设计说明；使用帮助统一放在右上角问号入口。

## 合规采集策略

平台投放采集必须按优先级执行：

1. 官方 API 或授权广告看板。
2. 平台导出的 CSV/XLSX/JSON 报表。
3. 经授权的公开页面低频采集，且必须尊重 robots、限速、记录来源。

不设计绕过登录、验证码、签名、风控或平台限制的能力。

