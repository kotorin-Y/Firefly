﻿# Security Policy

OpsDeputy stores API tokens and social account credentials locally in the desktop app user data directory.

## Supported Security Model

- Do not commit credentials, `.env` files, exported connector files, or customer data.
- Prefer OAuth, official APIs, and authorized dashboard exports.
- Public web collection must respect authorization, robots rules, platform terms, rate limits, and audit logging.
- The app intentionally does not include bypasses for login, CAPTCHA, signature, anti-bot, or platform access controls.

## Reporting Issues

Open a private security issue or contact the maintainer before publishing exploit details.

