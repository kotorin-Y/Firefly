# OpsDeputy

![OpsDeputy hero](assets/opsdeputy-hero.svg)

**OpsDeputy** 是一个本地优先的桌面端 AI 运营工作台，面向需要统一使用大模型、业务数据、工作流、平台接口、舆情监控、办公协同和本地导出的团队。它可以联网调用云端 API，也可以在离线环境中连接本地模型、本地数据库和本地文件。

OpsDeputy 的目标不是替代某一个单点工具，而是把运营分析、预算管理、投放复盘、风险判断、文档输出和自动化流程放在同一个可扩展的 Agent 工作区中。团队可以从一个顶部对话栏提出经营问题，也可以在工作流画布中编排可复用的分析流程。

## 项目定位

现代运营工作通常分散在广告后台、社媒平台、表格、文档、BI、CRM、代码仓库、大模型服务和手工报告之间。OpsDeputy 将这些环节整理为一个桌面应用，让团队在同一界面完成数据接入、分析推理、流程执行、风险归档和文件导出。

它适合下列场景：

- 需要快速搭建运营 Agent 原型，并逐步接入真实 API 的团队。
- 需要同时支持在线云模型和离线本地模型的桌面工具。
- 需要把广告、社媒、评论、财务、SQL、办公资料和知识库统一进入分析流程的运营团队。
- 需要开源、可审计、可扩展的本地优先 AI 工作台项目。

## 核心能力

| 能力 | 说明 | 应用示例 |
| --- | --- | --- |
| 大模型指挥栏 | 在产品顶部直接向已接入模型提问，并在下拉式回复区查看结构化回答。 | 让模型总结今日 ROI 波动、预算风险和下一步运营动作。 |
| 模型与 Skills 管理 | 管理 OpenAI 兼容接口、Anthropic、Gemini、MiniMax、本地模型端点和 GitHub Skills。 | 为不同客户公司启用不同模型、工作技能和执行权限。 |
| 工作流画布 | 使用可拖拽节点编排数据、知识库、大模型、条件判断、人工审批和输出节点。 | 创建“采集数据 -> 分析风险 -> 生成建议 -> 人工审批 -> 导出文件”的流程。 |
| 核心数据看板 | 基于导入或采集的数据展示 ROI、预算、风险建议和分析结果。 | 将平台消耗、收入、转化和风险记录聚合为日常经营看板。 |
| 平台数据接入 | 预留广告平台、社媒平台、CRM、BI、GitHub、Webhook 和自定义 API 接口。 | 接入投放平台后查看当日投放数量、消耗、点击和转化趋势。 |
| 舆情风险监控 | 内置评论抓取与检索能力，支持关键词、日期、平台、评分区间和导出。 | 监控退款、发货、价格、质量等高风险评论主题。 |
| 办公协同与知识库 | 为办公软件、文档库、表格、审批、任务和演示文稿输出预留统一资源入口。 | 将团队文档、知识库和运营数据组合成可复用的分析资料。 |
| 本地导出与 SQL | 支持 CSV、XLS、JSON、JSONL、SQLite 查询和本地文件输入输出。 | 将看板数据导出为会议材料，或用 SQL 查询本地运营数据。 |

## 技术栈

| 层级 | 技术 | 说明 |
| --- | --- | --- |
| 桌面运行时 | Electron | 提供跨平台桌面窗口、本地文件能力和主进程通信。 |
| 语言 | TypeScript 6，严格模式 | 渲染层与业务状态使用严格类型约束，便于长期维护。 |
| 界面层 | Vanilla DOM、CSS、inline SVG、Lucide 图标资源 | 不依赖远程前端运行时，适合离线打包和本地部署。 |
| 主进程 | Electron Main Process、Node.js API | 负责模型调用、连接器配置、文件导出、SQLite 查询和采集工具调度。 |
| 大模型协议 | OpenAI Responses、OpenAI-compatible Chat、Anthropic Messages、Gemini generateContent、MiniMax ChatCompletion v2 | 云端模型和本地 OpenAI 兼容模型共享同一条桌面对话链路。 |
| 本地数据 | SQLite、CSV、XLS、JSON、JSONL | 支持本地优先的数据输入、查询、转换和输出。 |
| 评论与采集工具 | Python comment crawler | 通过配置驱动评论抓取、导入、搜索、归档和导出。 |
| 打包发布 | Electron Builder、unpacked folder packaging | 支持生成 Windows 桌面应用和本地可运行目录。 |
| 持续集成 | GitHub Actions | 在提交和拉取请求中运行依赖安装、类型检查和项目校验。 |

## 架构

```mermaid
flowchart LR
  User["使用者"] --> UI["OpsDeputy 桌面界面"]
  UI --> Command["大模型指挥栏"]
  UI --> Workflow["工作流画布"]
  UI --> Settings["接口与 Skills 设置"]
  Command --> ModelAdapters["模型适配层"]
  ModelAdapters --> CloudLLM["云端大模型 API"]
  ModelAdapters --> LocalLLM["本地模型运行时"]
  Settings --> DataConnectors["数据连接器"]
  Settings --> SkillRegistry["Skill 注册表"]
  DataConnectors --> Dashboard["看板与导出"]
  Workflow --> Dashboard
  SkillRegistry --> Workflow
  UI --> Crawler["评论抓取与检索工具"]
  Crawler --> Dashboard
```

OpsDeputy 默认不附带远程后端。连接器配置、模型端点、本地数据库和导出文件都由桌面应用在用户机器上处理。团队可以按需接入外部 API，也可以只使用本地文件、本地模型和 SQLite 完成离线分析。

## 应用功能示例

### 每日 ROI 与预算复盘

1. 接入广告平台 API，或导入 CSV，或查询 SQL 数据源。
2. 在首页查看 ROI、消耗、预算进度、转化和风险卡片。
3. 在顶部对话栏输入：`总结今天的预算风险，并给出三个下一步动作。`
4. 将当前数据导出为 CSV 或 XLS，用于晨会、复盘或客户沟通。

适用场景：投放团队可以把平台消耗、收入、转化率和预算上限放入同一看板，避免反复切换广告后台和表格。

### 舆情风险队列

1. 选择本地评论数据库或导入评论文件。
2. 设置关键词，例如“退款”“发货”“价格”“质量”。
3. 按日期范围、平台、评分区间和命中词筛选。
4. 运行内置评论检索，将命中记录转为风险队列并导出。

适用场景：客服、品牌和运营团队可以快速定位高频负面主题，把需要人工跟进的评论交给负责人处理。

### 离线模型工作台

1. 启动 Ollama、LM Studio、LocalAI 或其他 OpenAI 兼容本地模型服务。
2. 在模型设置中添加本地端点、模型名称和调用参数。
3. 使用同一个顶部对话栏分析本地 CSV、SQLite 和手动导入数据。
4. 在不发送到云端模型的情况下完成内部数据总结和报告草稿。

适用场景：涉及敏感经营数据、客户资料或内部文档时，可以优先使用本地模型和本地文件流程。

### 基于 Skill 的自动化工作流

1. 从 GitHub 仓库添加 Skill，或启用内置 Skill。
2. 为当前客户工作区选择需要启用的 Skill。
3. 在画布中组合数据节点、知识库节点、大模型节点、条件节点、审批节点和输出节点。
4. 运行工作流，并把高风险动作保留在人工作业或审批节点之后。

适用场景：运营团队可以把“数据采集、异常判断、模型总结、审批、文件输出”固化为流程，减少重复操作。

### 办公协同资源准备

1. 添加办公软件连接器。
2. 准备文档、表格、任务、审批和演示文稿输出资源。
3. 将 CSV、XLS 或工作流结果作为协作材料。
4. 把运营分析结果整理为团队可继续编辑的文档或表格。

适用场景：项目经理可以把投放复盘、舆情风险、预算调整和客户汇报资料沉淀为统一资源列表。

### 平台投放数据巡检

1. 为各平台配置授权 API 或导入官方导出文件。
2. 在平台数据页面查看投放数量、消耗、点击、转化、成本和异常状态。
3. 通过可视化图表比较不同平台的当日表现。
4. 将异常数据交给大模型生成排查建议，再进入审批或导出流程。

适用场景：多平台投放团队可以每天快速发现预算过快、转化异常、素材疲劳或平台数据缺失。

## 示例指令

```text
根据已捕获的 ROI、预算、平台投放和舆情风险，生成今天的运营动作。
```

```text
检索近期关于退款和发货的评论，并按风险等级归类。
```

```text
基于当前看板数据，输出一份适合发送给客户的预算调整建议。
```

## 快速启动

```powershell
npm install
npm run check
npm start
```

## 构建 Windows 桌面应用

```powershell
npm run build:renderer
npm run pack:folder
```

打包后的桌面应用会生成在 `release/` 目录中。该目录默认不提交到 Git。

## 仓库结构

```text
electron/                 Electron 主进程与本地 IPC 桥
src/renderer/              TypeScript 渲染层应用
resources/skills/          内置评论抓取 Skill
scripts/                   构建与验证脚本
vendor/                    离线前端资源
assets/                    README 公共视觉素材
```

## 安全与合规说明

- 请勿提交 API Key、Access Token、导出的连接器配置、客户数据或本地数据库。
- 优先使用官方 API、OAuth、授权导出和用户主动提供的本地文件。
- 公开网页采集必须遵守授权、平台规则、robots 规则、限速和审计要求。
- 本项目不包含登录、验证码、签名、反爬或访问控制绕过能力。

## 许可证

MIT

---

# OpsDeputy

**OpsDeputy** is a local-first desktop AI operations workspace for teams that need one place to use LLMs, business data, workflows, platform connectors, sentiment monitoring, office collaboration, and local exports. It can call cloud APIs when online, or work with local models, local databases, and local files in offline environments.

OpsDeputy is not designed to replace a single tool. It brings operations analysis, budget management, campaign review, risk assessment, document output, and workflow automation into one extensible Agent workspace. Teams can ask operational questions from the top command bar or build reusable analysis flows on the workflow canvas.

## Product Positioning

Modern operations work is often scattered across ad dashboards, social platforms, spreadsheets, documents, BI tools, CRM systems, code repositories, model providers, and manual reports. OpsDeputy organizes these moving parts into a desktop app where teams can connect data, analyze signals, run workflows, archive risks, and export files in one place.

It is useful for:

- Teams that want to build an operations Agent prototype and gradually connect real APIs.
- Desktop tools that need both online cloud models and offline local models.
- Operations teams that need to combine ads, social media, comments, finance, SQL, office assets, and knowledge bases in one workflow.
- Open-source, auditable, and extensible local-first AI workspace projects.

## Core Capabilities

| Capability | Description | Example |
| --- | --- | --- |
| LLM Command Bar | Ask connected models from the top command bar and view structured answers in a dropdown response panel. | Ask the model to summarize today's ROI movement, budget risk, and next operating actions. |
| Model and Skills Management | Manage OpenAI-compatible endpoints, Anthropic, Gemini, MiniMax, local model endpoints, and GitHub Skills. | Enable different models, skills, and execution permissions for different client workspaces. |
| Workflow Canvas | Build draggable node workflows for data, knowledge, LLM calls, conditions, human approvals, and outputs. | Create a flow that collects data, analyzes risk, generates recommendations, waits for approval, and exports files. |
| Core Dashboard | Display ROI, budget, risk recommendations, and analysis rows from imported or captured data. | Combine spend, revenue, conversions, and risk records into a daily operations dashboard. |
| Platform Connectors | Prepare interfaces for ad platforms, social platforms, CRM, BI, GitHub, webhooks, and custom APIs. | Connect campaign platforms and review daily delivery count, spend, clicks, and conversion trends. |
| Sentiment Risk Monitoring | Search and archive comment data with keywords, dates, platforms, rating bands, and exports. | Monitor high-risk themes such as refunds, shipping, price, and product quality. |
| Office Collaboration and Knowledge Bases | Provide resource entry points for office tools, document libraries, tables, approvals, tasks, and slide outputs. | Combine team documents, knowledge bases, and operating data into reusable analysis material. |
| Local Exports and SQL | Support CSV, XLS, JSON, JSONL, SQLite queries, and local file input and output. | Export dashboard rows for meetings or query local operating data with SQL. |

## Tech Stack

| Layer | Technology | Notes |
| --- | --- | --- |
| Desktop Runtime | Electron | Provides the cross-platform desktop window, local file access, and main-process communication. |
| Language | TypeScript 6, strict mode | Keeps renderer logic and application state strongly typed for long-term maintenance. |
| UI Layer | Vanilla DOM, CSS, inline SVG, Lucide icon assets | Does not require a hosted frontend runtime, making it suitable for offline packaging and local deployment. |
| Main Process | Electron Main Process, Node.js APIs | Handles model calls, connector settings, file exports, SQLite queries, and crawler execution. |
| LLM Protocols | OpenAI Responses, OpenAI-compatible Chat, Anthropic Messages, Gemini generateContent, MiniMax ChatCompletion v2 | Cloud models and local OpenAI-compatible models share the same desktop command path. |
| Local Data | SQLite, CSV, XLS, JSON, JSONL | Supports local-first data input, query, transformation, and output workflows. |
| Comment and Collection Tooling | Python comment crawler | Enables config-driven comment collection, import, search, archive, and export. |
| Packaging | Electron Builder, unpacked folder packaging | Supports Windows desktop builds and local runnable folders. |
| Continuous Integration | GitHub Actions | Runs dependency installation, type checks, and project verification on pushes and pull requests. |

## Architecture

```mermaid
flowchart LR
  User["User"] --> UI["OpsDeputy Desktop UI"]
  UI --> Command["LLM Command Bar"]
  UI --> Workflow["Workflow Canvas"]
  UI --> Settings["Connector and Skills Settings"]
  Command --> ModelAdapters["Model Adapters"]
  ModelAdapters --> CloudLLM["Cloud LLM APIs"]
  ModelAdapters --> LocalLLM["Local Model Runtimes"]
  Settings --> DataConnectors["Data Connectors"]
  Settings --> SkillRegistry["Skill Registry"]
  DataConnectors --> Dashboard["Dashboard and Exports"]
  Workflow --> Dashboard
  SkillRegistry --> Workflow
  UI --> Crawler["Comment Collection and Search Tool"]
  Crawler --> Dashboard
```

OpsDeputy does not ship a remote backend by default. Connector settings, model endpoints, local databases, and export files are handled on the user's machine by the desktop app. Teams can connect external APIs as needed or stay fully local with local files, local models, and SQLite.

## Practical Examples

### Daily ROI and Budget Review

1. Connect an ad platform API, import a CSV file, or query a SQL source.
2. Review ROI, spend, budget pacing, conversions, and risk cards on the home dashboard.
3. Ask the command bar: `Summarize today's budget risks and suggest the next three actions.`
4. Export the current rows as CSV or XLS for a standup, review, or client update.

Use case: Paid media teams can bring platform spend, revenue, conversion rate, and budget limits into one dashboard instead of switching between ad consoles and spreadsheets.

### Sentiment Risk Queue

1. Select a local comment database or import a comment file.
2. Set keywords such as `refund`, `shipping`, `price`, or `quality`.
3. Filter by date range, platform, rating band, and matched term.
4. Run the bundled comment search, turn matches into a risk queue, and export the result.

Use case: Support, brand, and operations teams can quickly identify recurring negative themes and assign records that need human follow-up.

### Offline Model Workstation

1. Start Ollama, LM Studio, LocalAI, or another OpenAI-compatible local model runtime.
2. Add the local endpoint, model name, and call parameters in model settings.
3. Use the same top command bar to analyze local CSV, SQLite, and manually imported data.
4. Draft internal summaries and reports without sending prompts to a cloud model.

Use case: When operating data, customer material, or internal documents are sensitive, teams can prioritize local models and local files.

### Skill-Based Automation Workflow

1. Add a Skill from a GitHub repository or enable a bundled Skill.
2. Select the Skills that should be active in the current client workspace.
3. Combine data nodes, knowledge nodes, LLM nodes, condition nodes, approval nodes, and output nodes on the canvas.
4. Run the workflow and keep high-risk actions behind human approval.

Use case: Operations teams can turn repeated work such as data collection, anomaly checks, model summaries, approvals, and file outputs into reusable workflows.

### Office Collaboration Resource Preparation

1. Add an office software connector.
2. Prepare resources for documents, tables, tasks, approvals, and slide outputs.
3. Use CSV, XLS, or workflow results as collaboration material.
4. Organize operating insights into documents or tables that teammates can continue editing.

Use case: Project managers can consolidate campaign reviews, sentiment risks, budget changes, and client reporting material into a unified resource list.

### Platform Campaign Data Check

1. Configure authorized platform APIs or import official export files.
2. Review delivery count, spend, clicks, conversions, cost, and abnormal states on the platform data page.
3. Compare same-day performance across platforms with charts.
4. Ask the model to generate investigation suggestions for anomalies, then route them into approvals or exports.

Use case: Multi-platform campaign teams can detect fast budget burn, conversion anomalies, creative fatigue, or missing platform data during daily checks.

## Example Prompts

```text
Summarize the latest ROI movement and explain which budget line needs attention.
```

```text
Search recent comments about refund and delivery issues, then group the risks by severity.
```

```text
Use the current dashboard data to draft a client-ready budget adjustment recommendation.
```

## Quick Start

```powershell
npm install
npm run check
npm start
```

## Build a Windows Desktop App

```powershell
npm run build:renderer
npm run pack:folder
```

The unpacked desktop app is generated under `release/`. Release output is intentionally ignored by Git.

## Repository Layout

```text
electron/                 Electron main process and local IPC bridge
src/renderer/              TypeScript renderer application
resources/skills/          Bundled comment crawler Skill
scripts/                   Build and verification scripts
vendor/                    Offline frontend assets
assets/                    Public README visuals
```

## Safety and Compliance Notes

- Do not commit API keys, access tokens, exported connector files, customer data, or local databases.
- Prefer official APIs, OAuth, authorized exports, and local user-provided files.
- Public web collection must respect authorization, platform terms, robots rules, rate limits, and audit logging.
- The project does not include login, CAPTCHA, signature, anti-bot, or access-control bypass capabilities.

## License

MIT
