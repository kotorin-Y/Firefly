﻿export interface RequirementCoverage {
  id: string;
  requirement: string;
  pageOrModule: string;
  interfaceAnchor: string;
  evidenceFiles: string[];
  status: "covered" | "interface_ready" | "needs_credentials";
}

export const requirementCoverage: RequirementCoverage[] = [
  {
    id: "REQ-001",
    requirement: "首页包含 ROI 监控图、预算管理、风险建议、数据分析",
    pageOrModule: "首页",
    interfaceAnchor: "/api/dashboard/overview",
    evidenceFiles: ["src/renderer/app.ts", "src/architecture/apiContracts.ts"],
    status: "covered",
  },
  {
    id: "REQ-002",
    requirement: "顶部预留大模型对话栏，一级菜单即可使用 LLM 产出",
    pageOrModule: "首页 / Agent Chat",
    interfaceAnchor: "/api/agent/chat",
    evidenceFiles: ["index.html", "src/renderer/app.ts", "src/architecture/contracts.ts"],
    status: "covered",
  },
  {
    id: "REQ-003",
    requirement: "支持多 LLM 接入、路由、成本控制和工具调用",
    pageOrModule: "模型 / Skill 管理",
    interfaceAnchor: "LlmProviderConnector",
    evidenceFiles: ["src/renderer/app.ts", "src/architecture/contracts.ts"],
    status: "interface_ready",
  },
  {
    id: "REQ-004",
    requirement: "支持 Skill 管理、权限、输入输出 Schema、审计",
    pageOrModule: "模型 / Skill 管理",
    interfaceAnchor: "SkillDefinition",
    evidenceFiles: ["src/renderer/app.ts", "src/architecture/contracts.ts"],
    status: "interface_ready",
  },
  {
    id: "REQ-005",
    requirement: "参考 Dify 的工作流自动化，支持自由拖拽、右键菜单和节点编排",
    pageOrModule: "工作流自动化",
    interfaceAnchor: "WorkflowDefinition",
    evidenceFiles: ["src/renderer/app.ts", "src/architecture/contracts.ts"],
    status: "covered",
  },
  {
    id: "REQ-006",
    requirement: "接入 GitHub、Issue、PR、Webhook、Repo 配置版本化",
    pageOrModule: "接口与 GitHub",
    interfaceAnchor: "GithubConnector",
    evidenceFiles: ["src/renderer/app.ts", "src/architecture/contracts.ts", "src/architecture/apiContracts.ts"],
    status: "interface_ready",
  },
  {
    id: "REQ-007",
    requirement: "接入知识库与办公协同软件",
    pageOrModule: "知识库 / 办公协同",
    interfaceAnchor: "KnowledgeBaseConnector / CollaborationConnector",
    evidenceFiles: ["src/renderer/app.ts", "src/architecture/contracts.ts"],
    status: "interface_ready",
  },
  {
    id: "REQ-008",
    requirement: "内置平台投放采集，覆盖 TikTok、小红书等今日投放数目与看板",
    pageOrModule: "平台投放采集",
    interfaceAnchor: "AdsPlatformConnector / /api/crawlers/ad-platforms/run",
    evidenceFiles: ["src/renderer/app.ts", "src/architecture/contracts.ts", "src/architecture/apiContracts.ts"],
    status: "needs_credentials",
  },
  {
    id: "REQ-009",
    requirement: "包装旧评论爬取工具，内置舆论风险监控",
    pageOrModule: "舆情风险",
    interfaceAnchor: "CommentCrawlerConnector / /api/crawlers/comments/run",
    evidenceFiles: ["src/renderer/app.ts", "src/architecture/contracts.ts", "../comment_crawler.py"],
    status: "covered",
  },
  {
    id: "REQ-010",
    requirement: "在线协同处理并生成文档、报告、任务",
    pageOrModule: "办公协同 / 工作流输出节点",
    interfaceAnchor: "/api/collaboration/tasks / /api/reports",
    evidenceFiles: ["src/renderer/app.ts", "src/architecture/apiContracts.ts"],
    status: "interface_ready",
  },
  {
    id: "REQ-011",
    requirement: "客户公司和产品 24h 监控，输出实时分析建议",
    pageOrModule: "首页内置监控事件",
    interfaceAnchor: "/api/monitor/events",
    evidenceFiles: ["src/renderer/app.ts", "src/architecture/apiContracts.ts"],
    status: "covered",
  },
  {
    id: "REQ-012",
    requirement: "任何机器快速上手，具备泛用性，支持 SQL 与 XLS/CSV 输出",
    pageOrModule: "Electron 桌面 / 接口设置 / 数据导出",
    interfaceAnchor: "DeploymentProfile",
    evidenceFiles: ["src/renderer/app.ts", "src/architecture/contracts.ts", "docs/SOFTWARE_BLUEPRINT.md"],
    status: "covered",
  },
];

