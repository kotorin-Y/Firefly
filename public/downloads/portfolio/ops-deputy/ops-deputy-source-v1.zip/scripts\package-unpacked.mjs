import fs from "node:fs/promises";
import path from "node:path";

const root = process.cwd();
const electronDist = path.join(root, "node_modules", "electron", "dist");
const releaseRoot = path.join(root, "release");
const outDir = path.join(releaseRoot, "OpsDeputy-win32-x64");
const appDir = path.join(outDir, "resources", "app");

const appFiles = [
  "index.html",
  "styles.css",
  "dist/renderer",
  "vendor",
  "electron",
  "resources",
  "src",
  "README.md",
  "LICENSE",
  "SECURITY.md",
  "CONTRIBUTING.md",
];

async function exists(target) {
  try {
    await fs.access(target);
    return true;
  } catch {
    return false;
  }
}

if (!(await exists(path.join(electronDist, "electron.exe")))) {
  throw new Error("Electron runtime is missing. Run npm install first.");
}

await fs.rm(outDir, { recursive: true, force: true });
await fs.mkdir(releaseRoot, { recursive: true });
await fs.cp(electronDist, outDir, { recursive: true });
await fs.mkdir(appDir, { recursive: true });

for (const item of appFiles) {
  const source = path.join(root, item);
  if (await exists(source)) {
    await fs.cp(source, path.join(appDir, item), { recursive: true });
  }
}

await fs.writeFile(
  path.join(appDir, "package.json"),
  JSON.stringify(
    {
      name: "opsdeputy-desktop",
      version: "1.0.0",
      main: "electron/main.cjs",
      type: "commonjs",
    },
    null,
    2,
  ),
  "utf8",
);

const electronExe = path.join(outDir, "electron.exe");
const appExe = path.join(outDir, "OpsDeputy.exe");
await fs.rm(appExe, { force: true });
await fs.rename(electronExe, appExe);

console.log(`Packaged desktop app: ${appExe}`);
