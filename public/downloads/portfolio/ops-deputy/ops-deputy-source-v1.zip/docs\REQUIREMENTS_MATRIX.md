﻿# 需求覆盖矩阵

| ID | 需求 | 页面 / 模块 | 接口 / 类型 | 当前状态 |
| --- | --- | --- | --- | --- |
| REQ-001 | 首页显示 ROI、预算、风险建议、数据分析 | 首页 | `/api/dashboard/overview` | 已覆盖 |
| REQ-002 | 一级菜单顶部 LLM 对话栏 | 首页 | `/api/agent/chat` | 已覆盖 |
| REQ-003 | 多 LLM 接入与路由 | 模型 / Skill 管理 | `LlmProviderConnector` | 接口就绪 |
| REQ-004 | Skill 管理与权限审计 | 模型 / Skill 管理 | `SkillDefinition` | 接口就绪 |
| REQ-005 | Dify 式工作流自动化 | 工作流自动化 | `WorkflowDefinition` | 已覆盖 |
| REQ-006 | GitHub 接入 | 接口与 GitHub | `GithubConnector` | 接口就绪 |
| REQ-007 | 知识库与办公协同 | 知识库 / 协同 | `KnowledgeBaseConnector`、`CollaborationConnector` | 接口就绪 |
| REQ-008 | TikTok、小红书等今日投放采集 | 平台投放采集 | `AdsPlatformConnector`、`/api/crawlers/ad-platforms/run` | 需授权凭证 |
| REQ-009 | 旧评论抓取工具内置舆情监控 | 舆情风险 | `CommentCrawlerConnector`、`/api/crawlers/comments/run` | 已覆盖 |
| REQ-010 | 在线协同处理并生成文档 | 办公协同、工作流输出节点 | `/api/collaboration/tasks`、`/api/reports` | 接口就绪 |
| REQ-011 | 客户/产品 24h 实时分析建议 | 首页内置监控事件 | `/api/monitor/events` | 已覆盖 |
| REQ-012 | 脱机 EXE 与泛用部署能力 | 原生桌面应用 | `DeploymentProfile` | 已覆盖 |
| REQ-013 | Dify 式可新建节点工作流，支持右键删除、复制、重命名和排序 | 工作流自动化 | `WorkflowDefinition` | 已覆盖 |
| REQ-014 | 飞书多维表格办公协同资源页 | 办公协同 | `CollaborationConnector` | 已覆盖 |
| REQ-015 | 办公软件接口弹窗配置、测试连接、读取资源 | 办公协同 | `CollaborationConnector` | 已覆盖 |
| REQ-016 | 平台 API 可保存、测试、读取，并驱动可视化 | 平台数据采集 | `AdsPlatformConnector` | 已覆盖 |
| REQ-017 | 使用说明收进右上角问号入口，页面不暴露设计方案 | 全局 Shell | 本地 UI | 已覆盖 |
| REQ-018 | 首页看板读取导入或 API 结果，而非图片展示 | 首页 | `/api/dashboard/overview` | 已覆盖 |
| REQ-019 | 删除独立报告中心模块 | 左侧导航 / 页面体系 | 本地 UI | 已覆盖 |
| REQ-020 | 所有可视化数据下方支持 XLS / CSV 输出 | 首页、平台数据、舆情、协同、SQL 结果 | `opsdeputy:export-data` | 已覆盖 |
| REQ-021 | 数据文件可接入 SQL 并提供调用窗口 | 全局 SQL 入口、数据页、工作流 SQL 节点 | `opsdeputy:run-sql` | 已覆盖 |
| REQ-022 | 工作流自由拖拽编辑与玻璃右键菜单 | 工作流自动化 | `WorkflowDefinition` | 已覆盖 |

说明：平台级真实数据采集需要客户授权、API Key、广告账户权限或平台导出文件。当前软件已经提供页面、配置、测试、读取预览、导入和数据契约落点。

