export interface ApiEndpoint {
  method: "GET" | "POST" | "PATCH" | "DELETE";
  path: string;
  summary: string;
  requestSchema?: string;
  responseSchema: string;
  authRequired: boolean;
}

export const apiEndpoints: ApiEndpoint[] = [
  {
    method: "POST",
    path: "/api/agent/chat",
    summary: "Top-level LLM command bar for strategy generation and skill orchestration.",
    requestSchema: "AgentRequest",
    responseSchema: "AgentResponse",
    authRequired: true,
  },
  {
    method: "GET",
    path: "/api/dashboard/overview",
    summary: "ROI, budget, risk recommendations, and data analysis home dashboard.",
    responseSchema: "DashboardOverview",
    authRequired: true,
  },
  {
    method: "POST",
    path: "/api/connectors",
    summary: "Create LLM, GitHub, knowledge base, office collaboration, ads, finance, CRM, BI, or crawler connectors.",
    requestSchema: "ConnectorBase",
    responseSchema: "ConnectorBase",
    authRequired: true,
  },
  {
    method: "POST",
    path: "/api/workflows/run",
    summary: "Run Dify-style workflow nodes with tool calls, LLM reasoning, conditions, approvals, and report outputs.",
    requestSchema: "WorkflowRunRequest",
    responseSchema: "WorkflowRunResult",
    authRequired: true,
  },
  {
    method: "POST",
    path: "/api/crawlers/ad-platforms/run",
    summary: "Collect today's campaign, ad, creative, spend, and performance metrics from authorized ad platforms.",
    requestSchema: "AdPlatformCollectionRequest",
    responseSchema: "AdPlatformCollectionResult",
    authRequired: true,
  },
  {
    method: "POST",
    path: "/api/crawlers/comments/run",
    summary: "Run the packaged comment_crawler.py sentiment-risk skill with configured HTML, JSON, auto-extract, or JSONL import mode.",
    requestSchema: "CommentCrawlerRunRequest",
    responseSchema: "CommentCrawlerRunResult",
    authRequired: true,
  },
  {
    method: "POST",
    path: "/api/knowledge/sync",
    summary: "Sync enterprise knowledge bases and office documents into a permission-aware RAG index.",
    requestSchema: "KnowledgeSyncRequest",
    responseSchema: "KnowledgeSyncResult",
    authRequired: true,
  },
  {
    method: "POST",
    path: "/api/collaboration/tasks",
    summary: "Create approval, comment, document, or task handoff in Slack, Teams, Feishu, WeChat Work, DingTalk, or email.",
    requestSchema: "CollaborationTaskRequest",
    responseSchema: "CollaborationTask",
    authRequired: true,
  },
  {
    method: "POST",
    path: "/api/reports",
    summary: "Generate daily ops, ad collection, sentiment risk, board brief, client strategy, or weekly review reports.",
    requestSchema: "ReportGenerationRequest",
    responseSchema: "ReportArtifact",
    authRequired: true,
  },
  {
    method: "GET",
    path: "/api/monitor/events",
    summary: "Fetch 24h rolling monitoring events across market, competitors, ads, budget, finance, GitHub, and sentiment.",
    responseSchema: "MonitoringEvent[]",
    authRequired: true,
  },
];
