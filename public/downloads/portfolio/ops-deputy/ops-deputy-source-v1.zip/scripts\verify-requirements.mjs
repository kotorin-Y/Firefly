import fs from "node:fs";
import path from "node:path";

const root = process.cwd();

const requiredFiles = [
  "index.html",
  "styles.css",
  "src/renderer/app.ts",
  "tsconfig.json",
  "tsconfig.renderer.json",
  "vendor/lucide.min.js",
  "electron/main.cjs",
  "electron/preload.cjs",
  "resources/skills/comment_crawler.py",
  "scripts/package-unpacked.mjs",
  "README.md",
  "LICENSE",
  "SECURITY.md",
  "CONTRIBUTING.md",
];

const requiredTerms = [
  ["src/renderer/app.ts", "OpsDeputy"],
  ["src/renderer/app.ts", "核心数据看板"],
  ["src/renderer/app.ts", "runAgentChat"],
  ["src/renderer/app.ts", "openSkillModal"],
  ["src/renderer/app.ts", "toggleSkill"],
  ["src/renderer/app.ts", "crawlerSettingsForm"],
  ["src/renderer/app.ts", "Ollama Local"],
  ["src/renderer/app.ts", "LM Studio Local"],
  ["electron/main.cjs", "opsdeputy:chat"],
  ["electron/main.cjs", "opsdeputy:run-comment-crawler"],
  ["electron/main.cjs", "isLocalEndpoint"],
  ["electron/preload.cjs", "opsdeputy"],
  ["resources/skills/comment_crawler.py", "Config-driven comment crawler"],
];

const blockedTerms = [];

const errors = [];

for (const file of requiredFiles) {
  if (!fs.existsSync(path.join(root, file))) {
    errors.push(`Missing file: ${file}`);
  }
}

for (const [file, term] of requiredTerms) {
  const fullPath = path.join(root, file);
  const content = fs.existsSync(fullPath) ? fs.readFileSync(fullPath, "utf8") : "";
  if (!content.includes(term)) {
    errors.push(`Missing term "${term}" in ${file}`);
  }
}

const scannedFiles = [
  "README.md",
  "SECURITY.md",
  "CONTRIBUTING.md",
  "package.json",
  "scripts/package-unpacked.mjs",
  "src/renderer/app.ts",
  "electron/main.cjs",
  "electron/preload.cjs",
];

for (const file of scannedFiles) {
  const fullPath = path.join(root, file);
  const content = fs.existsSync(fullPath) ? fs.readFileSync(fullPath, "utf8") : "";
  for (const term of blockedTerms) {
    if (content.includes(term)) {
      errors.push(`Blocked term "${term}" found in ${file}`);
    }
  }
}

const html = fs.readFileSync(path.join(root, "index.html"), "utf8");
if (html.includes("https://unpkg.com") || html.includes("http://localhost")) {
  errors.push("index.html must not depend on an external CDN or localhost.");
}

if (errors.length > 0) {
  console.error(errors.join("\n"));
  process.exit(1);
}

console.log("Open-source package verification passed.");
