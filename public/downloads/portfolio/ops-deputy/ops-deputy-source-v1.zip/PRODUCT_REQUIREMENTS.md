﻿# OpsDeputy 产品需求整合

## 产品目标

构建一个在任意 Windows 机器上可快速上手的商业化运营 Agent 工具。它应能脱机打开桌面 EXE，并在用户授权后接入真实 LLM、GitHub、知识库、办公协同软件、广告平台、社媒平台、CRM、BI、财报股价和评论舆情数据。

## 必须满足的能力

1. 一级菜单顶部提供 LLM 对话栏，可直接让用户生成策略、预算建议、风险总结和报告草稿。
2. 首页必须展示 ROI 监控图、预算管理、风险建议、数据分析四项内容。
3. 支持多 LLM Provider 接入，包括 OpenAI、Anthropic、Google、Qwen、本地模型和私有模型。
4. 支持 Skill 管理，包括权限、输入输出 Schema、成本、审计和人审配置。
5. 支持 Dify 式工作流自动化，包括输入、工具、知识检索、LLM、判断、人审、协同、报告节点。
6. 支持 GitHub 接入，包括 GitHub App、Repo、Issue、PR、Webhook、Actions 和配置版本化。
7. 支持知识库接入，包括 Notion、Confluence、飞书知识库、语雀、SharePoint、Google Drive、OneDrive、本地文件夹。
8. 支持办公协同软件接入，包括 Slack、Teams、飞书、企业微信、钉钉、邮件。
9. 支持平台投放采集，包括 TikTok、小红书、抖音、Meta、Google Ads 等平台今日投放数目、素材数量、预算、曝光、点击、转化和异常变化。
10. 内置旧评论爬取工具，将 `comment_crawler.py` 包装为舆情风险 Skill，支持评论归档、检索、导出、负面主题和证据 URL 留存。
11. 支持在线协同处理，能将异常、建议和报告推送到协同软件或生成 GitHub Issue。
12. 删除独立报告中心模块；所有可视化数据下方提供 XLS 与 CSV 输出，报告类产出通过工作流节点或办公协同生成。
13. 24h 监控能力必须内置于主页看板，不作为独立产品模块。
14. 工作流必须支持类似 Dify 的自定义节点流程图、新建节点、右键编辑、删除节点、复制节点、调整节点顺序、保存流程模板。
15. 办公协同模块必须参考飞书多维表格模式，接入办公软件后读取文档库、表格、任务、素材等资源。
16. 平台与办公接口必须提供配置弹窗、保存、测试连接、读取数据预览，不能仅作为静态展示。
17. 页面必须现代、简洁、扁平化；产品内不展示大段说明，使用说明统一收进右上角问号入口。
18. 支持脱机打开，不依赖外部 Web 页面或 CDN。
19. 支持开源发布，具备 README、LICENSE、SECURITY、CONTRIBUTING、接口契约和需求覆盖校验。

## 技术选择

主实现选择 Electron + TypeScript，保留 Python 评论爬虫作为 Skill Runtime。原因：

- TypeScript 负责渲染层、Connector、Skill、Workflow、Report、Evidence 等核心边界，方便后续升级 Node API 或 Docker 服务。
- Electron 能同时提供现代 UI、真实本机文件导出、SQL 调用、凭证配置和离线桌面运行能力。
- 旧 Python 评论爬虫可作为独立 Skill Runtime 打包进桌面应用资源。

## 合规原则

- 官方 API、OAuth、授权看板导出优先。
- 无 API 场景支持 CSV/XLSX/JSON 人工导入。
- 公共页面采集默认关闭，只允许在授权、限速、robots 检查和可溯源条件下运行。
- 不提供绕过登录、验证码、签名、风控或平台访问限制的能力。

## 当前达成状态

当前仓库已提供：

- Electron + TypeScript 桌面应用入口。
- 可打包 Windows 便携 EXE 的 Electron Builder 配置。
- 蓝白现代简约 UI、圆角窗口、半透明按钮、圆角输入框、居中毛玻璃弹窗。
- API / 社媒账号 Connector 配置表单。
- Dify 式工作流画布，支持自由拖拽、右键毛玻璃菜单、节点删除、复制、重命名和层级调整。
- 飞书多维表格协同资源页，办公软件接口可弹窗配置、测试并读取资源预览。
- 平台数据采集可配置API、测试连接、读取数据并驱动看板。
- 首页 ROI、预算、风险、数据分析可通过导入或读取数据更新。
- 所有可视化数据支持 XLS / CSV 输出。
- SQL 调用窗口支持 SQLite 文件与 HTTP SQL 网关。
- 本机凭证保存、连接测试和数据读取链路。
- Python 评论爬虫打包资源。
- TypeScript 接口契约。
- 需求覆盖矩阵和自动校验脚本。

