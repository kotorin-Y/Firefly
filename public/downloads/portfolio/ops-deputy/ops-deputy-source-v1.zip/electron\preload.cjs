const { contextBridge, ipcRenderer } = require("electron");

contextBridge.exposeInMainWorld("opsdeputy", {
  runtime: () => ipcRenderer.invoke("opsdeputy:runtime"),
  windowAction: (action) => ipcRenderer.invoke("opsdeputy:window-action", action),
  getConnectors: () => ipcRenderer.invoke("opsdeputy:get-connectors"),
  saveConnector: (connector) => ipcRenderer.invoke("opsdeputy:save-connector", connector),
  testConnector: (connector) => ipcRenderer.invoke("opsdeputy:test-connector", connector),
  readConnector: (connector) => ipcRenderer.invoke("opsdeputy:read-connector", connector),
  chat: (payload) => ipcRenderer.invoke("opsdeputy:chat", payload),
  exportData: (payload) => ipcRenderer.invoke("opsdeputy:export-data", payload),
  selectSqliteDb: () => ipcRenderer.invoke("opsdeputy:select-sqlite-db"),
  selectFile: (payload) => ipcRenderer.invoke("opsdeputy:select-file", payload),
  runSql: (payload) => ipcRenderer.invoke("opsdeputy:run-sql", payload),
  runCommentCrawler: (payload) => ipcRenderer.invoke("opsdeputy:run-comment-crawler", payload),
});
