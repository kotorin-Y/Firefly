export type DeploymentMode =
  | "desktop"
  | "pwa"
  | "docker"
  | "local-lightweight"
  | "enterprise-private";

export type ConnectorKind =
  | "llm"
  | "knowledge_base"
  | "collaboration"
  | "github"
  | "ads_platform"
  | "social_platform"
  | "comment_crawler"
  | "finance_market"
  | "crm"
  | "bi"
  | "local_file"
  | "webhook";

export type ConnectorStatus = "not_configured" | "authorized" | "syncing" | "healthy" | "degraded" | "blocked";
export type RiskLevel = "low" | "medium" | "high" | "critical";

export interface EvidenceRef {
  sourceId: string;
  sourceType: ConnectorKind;
  title: string;
  url?: string;
  localPath?: string;
  capturedAt: string;
  retrievalMethod: "official_api" | "manual_import" | "authorized_export" | "public_web" | "local_file";
  checksum?: string;
}

export interface ConnectorBase {
  id: string;
  name: string;
  kind: ConnectorKind;
  status: ConnectorStatus;
  authMode: "api_key" | "oauth" | "github_app" | "service_account" | "local_file" | "manual";
  scopes: string[];
  ownerTeam: string;
  lastSyncAt?: string;
  evidenceRequired: boolean;
}

export interface LlmProviderConnector extends ConnectorBase {
  kind: "llm";
  provider: "openai" | "anthropic" | "google" | "qwen" | "local" | "custom";
  baseUrl?: string;
  defaultModel: string;
  supportsTools: boolean;
  supportsJsonMode: boolean;
  maxContextTokens?: number;
  costControl: {
    dailyTokenLimit?: number;
    monthlyBudgetCny?: number;
    requireApprovalAboveCny?: number;
  };
}

export interface KnowledgeBaseConnector extends ConnectorBase {
  kind: "knowledge_base" | "local_file";
  provider: "notion" | "confluence" | "feishu" | "yuque" | "sharepoint" | "google_drive" | "onedrive" | "local_folder" | "custom";
  indexMode: "rag" | "metadata_only" | "manual_attach";
  syncPolicy: "manual" | "hourly" | "daily" | "webhook";
  allowedFileTypes: Array<"pdf" | "docx" | "pptx" | "xlsx" | "csv" | "md" | "html" | "txt">;
}

export interface CollaborationConnector extends ConnectorBase {
  kind: "collaboration";
  provider: "slack" | "teams" | "feishu" | "wechat_work" | "dingtalk" | "email" | "custom";
  capabilities: Array<"message" | "approval" | "document_create" | "comment" | "task_assign" | "meeting_summary">;
}

export interface GithubConnector extends ConnectorBase {
  kind: "github";
  installationId?: string;
  repositories: string[];
  capabilities: Array<"issues" | "pull_requests" | "webhooks" | "repo_files" | "releases" | "actions">;
}

export interface AdsPlatformConnector extends ConnectorBase {
  kind: "ads_platform" | "social_platform";
  provider: "tiktok" | "xiaohongshu" | "douyin" | "meta" | "google_ads" | "amazon_ads" | "tencent_ads" | "custom";
  collectionModes: Array<"official_api" | "authorized_dashboard_export" | "manual_import" | "public_web_limited">;
  metrics: Array<"campaign_count" | "ad_count" | "creative_count" | "spend" | "impressions" | "clicks" | "conversions" | "cpa" | "roas">;
  compliance: {
    requiresAuthorization: true;
    respectsRobotsTxt: boolean;
    rateLimitPerMinute?: number;
    forbidBypassLoginCaptchaSignature: true;
  };
}

export interface CommentCrawlerConnector extends ConnectorBase {
  kind: "comment_crawler";
  runtime: "python";
  entrypoint: "comment_crawler.py";
  storage: "sqlite";
  supportedModes: Array<"html_config" | "json_config" | "auto_extract" | "jsonl_import">;
  exports: Array<"csv" | "json" | "jsonl" | "html" | "xlsx">;
  riskSignals: Array<"rating_band" | "negative_keyword" | "volume_spike" | "sentiment" | "source_velocity" | "evidence_url">;
}

export interface SkillDefinition<Input = unknown, Output = unknown> {
  id: string;
  name: string;
  category: "strategy" | "budget" | "market" | "competitor" | "crawler" | "sentiment" | "finance" | "report" | "collaboration";
  description: string;
  inputSchemaName: string;
  outputSchemaName: string;
  requiredConnectors: ConnectorKind[];
  permissions: Array<"read" | "write" | "notify" | "create_report" | "create_issue" | "run_crawler">;
  requiresHumanApproval: boolean;
  run(input: Input): Promise<Output>;
}

export type WorkflowNodeType = "input" | "tool" | "llm" | "knowledge_retrieval" | "condition" | "human_approval" | "collaboration" | "report";

export interface WorkflowNode {
  id: string;
  type: WorkflowNodeType;
  label: string;
  config: Record<string, unknown>;
  next: string[];
}

export interface WorkflowDefinition {
  id: string;
  name: string;
  trigger: "manual" | "schedule" | "webhook" | "metric_anomaly" | "risk_event";
  nodes: WorkflowNode[];
  version: string;
  enabled: boolean;
}

export interface AgentRequest {
  tenantId: string;
  clientId: string;
  userId: string;
  prompt: string;
  preferredModel?: string;
  allowedSkills: string[];
  evidencePolicy: "required" | "best_effort" | "none";
}

export interface AgentRecommendation {
  id: string;
  title: string;
  summary: string;
  riskLevel: RiskLevel;
  suggestedActions: string[];
  expectedImpact: {
    metric: "roas" | "cpa" | "revenue" | "retention" | "sentiment_risk" | "budget_efficiency";
    direction: "increase" | "decrease" | "stabilize";
    estimate: string;
  };
  evidence: EvidenceRef[];
  approvalRequired: boolean;
}

export interface AgentResponse {
  requestId: string;
  generatedAt: string;
  modelUsed: string;
  skillsUsed: string[];
  recommendations: AgentRecommendation[];
  reportDraftId?: string;
}

export interface ReportDefinition {
  id: string;
  name: string;
  type: "daily_ops" | "weekly_review" | "ad_collection" | "sentiment_risk" | "board_brief" | "client_strategy";
  outputFormats: Array<"docx" | "pdf" | "pptx" | "markdown" | "online_doc">;
  evidenceRequired: boolean;
  collaborationTargets: string[];
}

export interface DeploymentProfile {
  mode: DeploymentMode;
  label: string;
  minimumRequirements: string[];
  recommendedFor: string[];
  packaging: "static_pwa" | "electron" | "docker_compose" | "kubernetes" | "single_binary_plus_runtime";
}
