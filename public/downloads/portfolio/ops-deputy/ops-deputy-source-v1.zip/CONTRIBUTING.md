# Contributing

## Development

```powershell
npm install
npm run check
npm start
```

## Build Windows Desktop App

```powershell
npm run build:renderer
npm run pack:folder
```

## Contribution Rules

- Keep credentials, local databases, connector exports, screenshots with private data, and generated desktop builds out of Git.
- Add external integrations through connector settings and IPC boundaries.
- Keep local/offline usage working when adding cloud-only features.
- Run `npm run check` before opening a pull request.
