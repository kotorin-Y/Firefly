const { app, BrowserWindow, ipcMain, shell, dialog } = require("electron");
const fs = require("node:fs/promises");
const path = require("node:path");
const { spawn } = require("node:child_process");

const isDev = !app.isPackaged;

function resolveAppPath(...segments) {
  return path.join(__dirname, "..", ...segments);
}

function resolveResourcePath(...segments) {
  return isDev
    ? path.join(__dirname, "..", ...segments)
    : path.join(process.resourcesPath, ...segments);
}

function getConfigPath() {
  return path.join(app.getPath("userData"), "connectors.json");
}

async function readConnectors() {
  try {
    const raw = await fs.readFile(getConfigPath(), "utf8");
    return JSON.parse(raw);
  } catch {
    return [];
  }
}

async function writeConnectors(connectors) {
  await fs.mkdir(app.getPath("userData"), { recursive: true });
  await fs.writeFile(getConfigPath(), JSON.stringify(connectors, null, 2), "utf8");
}

function sanitizeConnector(connector) {
  return {
    id: connector.id || `connector_${Date.now()}`,
    name: String(connector.name || "").trim(),
    kind: String(connector.kind || "llm"),
    provider: String(connector.provider || "custom"),
    developer: String(connector.developer || connector.provider || "").trim(),
    modelName: String(connector.modelName || "").trim(),
    protocol: String(connector.protocol || "").trim(),
    apiPath: String(connector.apiPath || "").trim(),
    authMode: String(connector.authMode || "api_key"),
    baseUrl: String(connector.baseUrl || "").trim(),
    accountId: String(connector.accountId || "").trim(),
    accessToken: String(connector.accessToken || "").trim(),
    apiKey: String(connector.apiKey || "").trim(),
    status: "authorized",
    updatedAt: new Date().toISOString(),
  };
}

function maskConnector(connector) {
  return {
    ...connector,
    accessToken: connector.accessToken ? "********" : "",
    apiKey: connector.apiKey ? "********" : "",
  };
}

function createWindow() {
  const win = new BrowserWindow({
    width: 1480,
    height: 940,
    minWidth: 1100,
    minHeight: 720,
    title: "OpsDeputy",
    frame: false,
    transparent: true,
    backgroundColor: "#00000000",
    roundedCorners: true,
    webPreferences: {
      preload: path.join(__dirname, "preload.cjs"),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false,
    },
  });

  win.removeMenu();
  win.loadFile(resolveAppPath("index.html"));

  win.webContents.setWindowOpenHandler(({ url }) => {
    shell.openExternal(url);
    return { action: "deny" };
  });
}

app.whenReady().then(createWindow);

app.on("window-all-closed", () => {
  if (process.platform !== "darwin") app.quit();
});

app.on("activate", () => {
  if (BrowserWindow.getAllWindows().length === 0) createWindow();
});

ipcMain.handle("opsdeputy:runtime", async () => ({
  packaged: app.isPackaged,
  userData: app.getPath("userData"),
  commentCrawlerPath: resolveResourcePath("resources", "skills", "comment_crawler.py"),
}));

ipcMain.handle("opsdeputy:get-connectors", async () => {
  const connectors = await readConnectors();
  return connectors.map(maskConnector);
});

ipcMain.handle("opsdeputy:save-connector", async (_event, connectorInput) => {
  const connector = sanitizeConnector(connectorInput);
  if (!connector.name) throw new Error("Connector name is required.");
  const connectors = await readConnectors();
  const index = connectors.findIndex((item) => item.id === connector.id);
  if (index >= 0) connectors[index] = { ...connectors[index], ...connector };
  else connectors.push(connector);
  await writeConnectors(connectors);
  return maskConnector(connector);
});

ipcMain.handle("opsdeputy:test-connector", async (_event, connectorInput) => {
  const connector = sanitizeConnector(connectorInput);
  if (!connector.baseUrl || !/^https?:\/\//i.test(connector.baseUrl)) {
    return { ok: false, status: "invalid_url", message: "请输入可访问的 HTTPS/HTTP API 地址。" };
  }

  if (connector.kind === "llm" && connector.protocol === "minimax-chat") {
    const result = await callMiniMax(connector, "ping");
    return { ok: result.ok, status: result.ok ? 200 : "api_error", message: result.ok ? "连接成功。" : result.message };
  }

  const headers = connectorHeaders(connector);
  const url = testUrlForConnector(connector);

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 10000);
  try {
    const response = await fetch(url, {
      method: "GET",
      headers,
      signal: controller.signal,
    });
    return {
      ok: response.ok,
      status: response.status,
      message: response.ok ? "连接成功。" : `接口返回 ${response.status}。`,
    };
  } catch (error) {
    return { ok: false, status: "network_error", message: error.message };
  } finally {
    clearTimeout(timeout);
  }
});

ipcMain.handle("opsdeputy:read-connector", async (_event, connectorInput) => {
  const connector = sanitizeConnector(connectorInput);
  if (!connector.baseUrl || !/^https?:\/\//i.test(connector.baseUrl)) {
    return { ok: false, status: "invalid_url", message: "请输入可访问的 HTTPS/HTTP API 地址。", preview: "" };
  }

  const headers = { Accept: "application/json, text/plain, */*", ...connectorHeaders(connector) };

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 15000);
  try {
    const response = await fetch(connector.baseUrl, { method: "GET", headers, signal: controller.signal });
    const text = await response.text();
    const preview = text.slice(0, 1800);
    const target = path.join(app.getPath("userData"), `last_read_${connector.provider || "custom"}.txt`);
    await fs.mkdir(app.getPath("userData"), { recursive: true });
    await fs.writeFile(target, text, "utf8");
    return {
      ok: response.ok,
      status: response.status,
      message: response.ok ? `读取完成，已保存 ${path.basename(target)}。` : `接口返回 ${response.status}。`,
      preview,
    };
  } catch (error) {
    return { ok: false, status: "network_error", message: error.message, preview: "" };
  } finally {
    clearTimeout(timeout);
  }
});

ipcMain.handle("opsdeputy:window-action", (event, action) => {
  const win = BrowserWindow.fromWebContents(event.sender);
  if (!win) return;
  if (action === "minimize") win.minimize();
  if (action === "maximize") {
    if (win.isMaximized()) win.unmaximize();
    else win.maximize();
  }
  if (action === "close") win.close();
});

ipcMain.handle("opsdeputy:chat", async (_event, payload) => {
  const connectorId = String(payload?.connectorId || "");
  const prompt = String(payload?.prompt || "").trim();
  if (!connectorId) return { ok: false, message: "未选择大模型连接。" };
  if (!prompt) return { ok: false, message: "请输入对话内容。" };

  const connectors = await readConnectors();
  const connector = connectors.find((item) => item.id === connectorId);
  if (!connector) return { ok: false, message: "未找到对应的大模型连接。" };
  if (connector.kind !== "llm") return { ok: false, message: "当前连接不是大模型类型。" };
  if (!connector.baseUrl || !/^https?:\/\//i.test(connector.baseUrl)) {
    return { ok: false, message: "大模型 API 地址无效。" };
  }
  if (!connector.apiKey && !connector.accessToken && !isLocalEndpoint(connector.baseUrl)) {
    return { ok: false, message: "大模型连接缺少 API Key 或 Access Token。" };
  }

  return callLlm(connector, prompt);
});

ipcMain.handle("opsdeputy:export-data", async (_event, payload) => {
  const rows = Array.isArray(payload?.rows) ? payload.rows : [];
  const format = payload?.format === "xls" ? "xls" : "csv";
  const safeName = String(payload?.name || "opsdeputy-data").replace(/[\\/:*?"<>|]/g, "-");
  const defaultPath = path.join(app.getPath("documents"), `${safeName}.${format}`);
  const result = await dialog.showSaveDialog({
    title: format === "xls" ? "输出 XLS 文件" : "输出 CSV 文件",
    defaultPath,
    filters: [{ name: format.toUpperCase(), extensions: [format] }],
  });
  if (result.canceled || !result.filePath) {
    return { ok: false, message: "已取消导出。" };
  }
  const content = format === "xls" ? rowsToXls(rows) : rowsToCsv(rows);
  await fs.writeFile(result.filePath, content, "utf8");
  return { ok: true, filePath: result.filePath, message: `已输出：${result.filePath}` };
});

ipcMain.handle("opsdeputy:select-sqlite-db", async () => {
  const result = await dialog.showOpenDialog({
    title: "选择 SQLite 数据库",
    properties: ["openFile"],
    filters: [{ name: "SQLite", extensions: ["db", "sqlite", "sqlite3"] }, { name: "All files", extensions: ["*"] }],
  });
  return { canceled: result.canceled, filePath: result.filePaths[0] };
});

ipcMain.handle("opsdeputy:select-file", async (_event, payload) => {
  const extensions = Array.isArray(payload?.extensions) && payload.extensions.length ? payload.extensions : ["*"];
  const result = await dialog.showOpenDialog({
    title: String(payload?.title || "选择文件"),
    properties: ["openFile"],
    filters: [{ name: extensions.includes("*") ? "All files" : extensions.join(", "), extensions }],
  });
  return { canceled: result.canceled, filePath: result.filePaths[0] };
});

ipcMain.handle("opsdeputy:run-sql", async (_event, payload) => {
  const mode = payload?.mode === "http" ? "http" : "sqlite";
  const query = String(payload?.query || "").trim();
  if (!query) return { ok: false, message: "SQL 不能为空。" };
  if (mode === "http") return runHttpSql(payload, query);
  return runSqlite(payload?.dbPath, query);
});

ipcMain.handle("opsdeputy:run-comment-crawler", async (_event, payload) => {
  return runCommentCrawler(payload);
});

function isLocalEndpoint(url) {
  try {
    const parsed = new URL(String(url || ""));
    return ["127.0.0.1", "localhost", "::1"].includes(parsed.hostname);
  } catch {
    return false;
  }
}

function connectorSecret(connector) {
  return connector.apiKey || connector.accessToken || "";
}

function connectorHeaders(connector) {
  const headers = { Accept: "application/json" };
  const key = connectorSecret(connector);
  if (connector.kind === "llm") {
    if (connector.protocol === "anthropic") {
      headers["x-api-key"] = key;
      headers["anthropic-version"] = "2023-06-01";
      return headers;
    }
    if (connector.protocol === "gemini") return headers;
    if (key) headers.Authorization = `Bearer ${key}`;
    return headers;
  }
  if (connector.accessToken) headers.Authorization = `Bearer ${connector.accessToken}`;
  if (connector.apiKey) headers["X-API-Key"] = connector.apiKey;
  return headers;
}

function joinUrl(baseUrl, suffix) {
  const base = String(baseUrl || "").replace(/\/+$/, "");
  const pathPart = String(suffix || "").replace(/^\/+/, "");
  return `${base}/${pathPart}`;
}

function endpointUrl(connector, suffix) {
  const explicitPath = String(connector.apiPath || "").trim();
  if (explicitPath) return joinUrl(connector.baseUrl, explicitPath);
  const normalizedBase = String(connector.baseUrl || "").replace(/\/+$/, "");
  const normalizedSuffix = String(suffix || "").replace(/^\/+/, "");
  if (!normalizedSuffix) return normalizedBase;
  if (normalizedBase.endsWith(normalizedSuffix)) return normalizedBase;
  return joinUrl(normalizedBase, normalizedSuffix);
}

function testUrlForConnector(connector) {
  if (connector.kind !== "llm") return connector.baseUrl;
  if (connector.protocol === "minimax-chat") return connector.baseUrl;
  if (connector.protocol === "gemini") {
    const key = encodeURIComponent(connectorSecret(connector));
    return `${endpointUrl(connector, "models")}?key=${key}`;
  }
  if (connector.protocol === "anthropic") return endpointUrl(connector, "v1/models");
  return endpointUrl(connector, "models");
}

async function callLlm(connector, prompt) {
  const protocol = connector.protocol || "openai-chat";
  try {
    if (protocol === "anthropic") return callAnthropic(connector, prompt);
    if (protocol === "gemini") return callGemini(connector, prompt);
    if (protocol === "minimax-chat") return callMiniMax(connector, prompt);
    if (protocol === "openai-responses") return callOpenAiResponses(connector, prompt);
    return callOpenAiChat(connector, prompt);
  } catch (error) {
    return { ok: false, message: error.message || String(error), model: connector.modelName };
  }
}

async function callOpenAiResponses(connector, prompt) {
  const response = await fetch(endpointUrl(connector, "responses"), {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      ...connectorHeaders(connector),
    },
    body: JSON.stringify({
      model: connector.modelName,
      input: prompt,
    }),
  });
  const data = await response.json().catch(async () => ({ error: await response.text() }));
  if (!response.ok) return apiError(response, data, connector.modelName);
  const answer = data.output_text
    || data.output?.flatMap((item) => item.content || []).map((item) => item.text || item.output_text || "").join("\n").trim()
    || JSON.stringify(data);
  return { ok: true, message: "调用完成。", answer, model: connector.modelName };
}

async function callOpenAiChat(connector, prompt) {
  const response = await fetch(endpointUrl(connector, "chat/completions"), {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      ...connectorHeaders(connector),
    },
    body: JSON.stringify({
      model: connector.modelName,
      messages: [{ role: "user", content: prompt }],
      temperature: 0.4,
    }),
  });
  const data = await response.json().catch(async () => ({ error: await response.text() }));
  if (!response.ok) return apiError(response, data, connector.modelName);
  const answer = data.choices?.[0]?.message?.content || data.choices?.[0]?.text || JSON.stringify(data);
  return { ok: true, message: "调用完成。", answer, model: connector.modelName };
}

async function callAnthropic(connector, prompt) {
  const response = await fetch(endpointUrl(connector, "v1/messages"), {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      ...connectorHeaders(connector),
    },
    body: JSON.stringify({
      model: connector.modelName,
      max_tokens: 1200,
      messages: [{ role: "user", content: prompt }],
    }),
  });
  const data = await response.json().catch(async () => ({ error: await response.text() }));
  if (!response.ok) return apiError(response, data, connector.modelName);
  const answer = data.content?.map((part) => part.text || "").join("\n").trim() || JSON.stringify(data);
  return { ok: true, message: "调用完成。", answer, model: connector.modelName };
}

async function callGemini(connector, prompt) {
  const key = encodeURIComponent(connectorSecret(connector));
  const model = encodeURIComponent(connector.modelName);
  const response = await fetch(`${endpointUrl(connector, `models/${model}:generateContent`)}?key=${key}`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      ...connectorHeaders(connector),
    },
    body: JSON.stringify({
      contents: [{ parts: [{ text: prompt }] }],
    }),
  });
  const data = await response.json().catch(async () => ({ error: await response.text() }));
  if (!response.ok) return apiError(response, data, connector.modelName);
  const answer = data.candidates?.[0]?.content?.parts?.map((part) => part.text || "").join("\n").trim() || JSON.stringify(data);
  return { ok: true, message: "调用完成。", answer, model: connector.modelName };
}

async function callMiniMax(connector, prompt) {
  const response = await fetch(endpointUrl(connector, ""), {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      ...connectorHeaders(connector),
    },
    body: JSON.stringify({
      model: connector.modelName,
      messages: [{ role: "user", content: prompt }],
    }),
  });
  const data = await response.json().catch(async () => ({ error: await response.text() }));
  if (!response.ok) return apiError(response, data, connector.modelName);
  const answer = data.choices?.[0]?.message?.content || data.reply || data.text || JSON.stringify(data);
  return { ok: true, message: "调用完成。", answer, model: connector.modelName };
}

function apiError(response, data, model) {
  const detail = data?.error?.message || data?.message || data?.error || JSON.stringify(data).slice(0, 600);
  return { ok: false, message: `接口返回 ${response.status}：${detail}`, model };
}

async function runCommentCrawler(payload) {
  const action = payload?.action === "crawl" ? "crawl" : "search";
  const dbPath = String(payload?.dbPath || "").trim();
  if (!dbPath) return { ok: false, message: "请先选择评论 SQLite 数据库。" };
  const crawlerPath = resolveResourcePath("resources", "skills", "comment_crawler.py");
  const args = [crawlerPath, "--db", dbPath];
  const snapshotDir = path.join(app.getPath("userData"), "comment_snapshots");
  let exportPath = "";

  if (action === "crawl") {
    const configPath = String(payload?.configPath || "").trim();
    if (!configPath) return { ok: false, message: "执行抓取需要选择抓取配置 JSON。" };
    args.push("crawl", "--config", configPath);
    if (payload?.maxPages) args.push("--max-pages", String(payload.maxPages));
    if (payload?.saveSnapshots) args.push("--snapshot-dir", snapshotDir);
  } else {
    exportPath = path.join(app.getPath("userData"), `comment_search_${Date.now()}.json`);
    args.push("search", "--limit", String(payload?.limit || 50), "--export", exportPath);
    for (const keyword of splitList(payload?.keyword)) args.push("--keyword", keyword);
    for (const platform of splitList(payload?.platform)) args.push("--platform", platform);
    if (payload?.startDate) args.push("--start-date", String(payload.startDate));
    if (payload?.endDate) args.push("--end-date", String(payload.endDate));
  }

  const result = await runPython(args);
  if (!result.ok) return result;
  if (action === "crawl") return { ok: true, message: result.output || "抓取完成。", output: result.output };
  try {
    const raw = await fs.readFile(exportPath, "utf8");
    const rows = JSON.parse(raw);
    return { ok: true, message: `检索完成：${Array.isArray(rows) ? rows.length : 0} 条。`, rows: Array.isArray(rows) ? rows : [], output: result.output };
  } catch {
    return { ok: true, message: result.output || "检索完成。", rows: [], output: result.output };
  }
}

function splitList(value) {
  return String(value || "")
    .split(/[,\n，]/)
    .map((item) => item.trim())
    .filter(Boolean);
}

function runPython(args) {
  return new Promise((resolve) => {
    const child = spawn("python", args, { windowsHide: true });
    let stdout = "";
    let stderr = "";
    child.stdout.on("data", (chunk) => { stdout += chunk.toString(); });
    child.stderr.on("data", (chunk) => { stderr += chunk.toString(); });
    child.on("close", (code) => {
      if (code !== 0) {
        resolve({ ok: false, message: stderr || stdout || `Python 进程退出：${code}`, output: stdout });
        return;
      }
      resolve({ ok: true, message: stdout || "执行完成。", output: stdout });
    });
  });
}

function rowsToCsv(rows) {
  const headers = Object.keys(rows[0] || {});
  const escape = (value) => `"${String(value ?? "").replaceAll('"', '""')}"`;
  return [headers.join(","), ...rows.map((row) => headers.map((key) => escape(row[key])).join(","))].join("\n");
}

function rowsToXls(rows) {
  const headers = Object.keys(rows[0] || {});
  return `<!doctype html><html><head><meta charset="utf-8"></head><body><table><thead><tr>${headers.map((key) => `<th>${escapeHtml(key)}</th>`).join("")}</tr></thead><tbody>${rows.map((row) => `<tr>${headers.map((key) => `<td>${escapeHtml(row[key])}</td>`).join("")}</tr>`).join("")}</tbody></table></body></html>`;
}

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;");
}

async function runHttpSql(payload, query) {
  const endpoint = String(payload?.endpoint || "").trim();
  if (!/^https?:\/\//i.test(endpoint)) {
    return { ok: false, message: "HTTP SQL 网关地址无效。" };
  }
  const headers = { "Content-Type": "application/json", Accept: "application/json" };
  if (payload?.token) headers.Authorization = `Bearer ${payload.token}`;
  try {
    const response = await fetch(endpoint, { method: "POST", headers, body: JSON.stringify({ query }) });
    const data = await response.json().catch(async () => ({ text: await response.text() }));
    const rows = Array.isArray(data) ? data : Array.isArray(data.rows) ? data.rows : [data];
    return { ok: response.ok, message: response.ok ? "SQL 网关调用完成。" : `SQL 网关返回 ${response.status}。`, rows };
  } catch (error) {
    return { ok: false, message: error.message };
  }
}

async function runSqlite(dbPath, query) {
  const target = String(dbPath || "").trim();
  if (!target) return { ok: false, message: "请选择 SQLite 数据库文件。" };
  const script = [
    "import json, sqlite3, sys",
    "db, query = sys.argv[1], sys.argv[2]",
    "conn = sqlite3.connect(db)",
    "conn.row_factory = sqlite3.Row",
    "cur = conn.execute(query)",
    "rows = [dict(row) for row in cur.fetchmany(500)]",
    "print(json.dumps(rows, ensure_ascii=False))",
  ].join("\n");
  return new Promise((resolve) => {
    const child = spawn("python", ["-c", script, target, query], { windowsHide: true });
    let stdout = "";
    let stderr = "";
    child.stdout.on("data", (chunk) => { stdout += chunk.toString(); });
    child.stderr.on("data", (chunk) => { stderr += chunk.toString(); });
    child.on("close", (code) => {
      if (code !== 0) {
        resolve({ ok: false, message: stderr || `SQLite 查询失败：${code}` });
        return;
      }
      try {
        resolve({ ok: true, message: "SQLite 查询完成。", rows: JSON.parse(stdout || "[]") });
      } catch (error) {
        resolve({ ok: false, message: error.message });
      }
    });
  });
}
