﻿# Open Source Release Checklist

## Required Before Publishing

- Run `npm run check`.
- Run `npm run dist` and confirm the portable EXE launches.
- Confirm `index.html` does not reference CDN or localhost.
- Confirm `resources/skills/comment_crawler.py` is included.
- Confirm no credentials, account exports, `.env` files, or customer data are committed.
- Confirm platform collection docs clearly state official API / authorized export first.

## Recommended GitHub Repository Settings

- Add repository description: `Offline desktop-ready commercial operations Agent`.
- Enable issues and discussions.
- Add topics: `agent`, `llm`, `electron`, `typescript`, `marketing-operations`, `workflow`, `dashboard`.
- Add branch protection after first stable release.
- Publish EXE under GitHub Releases, not directly in source history if file size becomes large.

## First Release Assets

- `OpsDeputy-Agent-1.0.0-portable.exe`
- Source zip from GitHub
- README screenshots
- Requirement matrix
- API design document

