export {};

type ViewKey = "dashboard" | "workflow" | "models" | "data" | "sentiment" | "collaboration" | "integrations";
type ExportFormat = "csv" | "xls";

interface DatasetRow {
  [key: string]: string | number | boolean | undefined;
}

interface WorkflowNode {
  id: string;
  type: string;
  title: string;
  desc: string;
  x: number;
  y: number;
  z: number;
}

interface WorkflowDefinition {
  id: string;
  name: string;
  nodes: WorkflowNode[];
}

interface ConnectorPayload {
  id?: string;
  name: string;
  kind: string;
  provider: string;
  developer?: string;
  modelName?: string;
  protocol?: string;
  apiPath?: string;
  baseUrl: string;
  accountId: string;
  accessToken: string;
  apiKey: string;
}

interface SkillPayload {
  id: string;
  name: string;
  category: string;
  githubUrl: string;
  entrypoint: string;
  permissions: string;
  enabled: boolean;
  source: "builtin" | "github";
}

interface CrawlerConfig {
  keyword: string;
  platform: string;
  startDate: string;
  endDate: string;
  dbPath: string;
  configPath: string;
  maxPages: number;
  limit: number;
  saveSnapshots: boolean;
}

interface ChatMessage {
  role: "user" | "assistant";
  content: string;
  at: string;
  model?: string;
}

interface OpsDeputyBridge {
  runtime: () => Promise<{ packaged: boolean; userData: string; commentCrawlerPath: string }>;
  windowAction: (action: "minimize" | "maximize" | "close") => Promise<void>;
  getConnectors: () => Promise<ConnectorPayload[]>;
  saveConnector: (connector: ConnectorPayload) => Promise<ConnectorPayload>;
  testConnector: (connector: ConnectorPayload) => Promise<{ ok: boolean; status: string | number; message: string }>;
  readConnector: (connector: ConnectorPayload) => Promise<{ ok: boolean; status: string | number; message: string; preview: string }>;
  chat: (payload: { connectorId: string; prompt: string }) => Promise<{ ok: boolean; message: string; answer?: string; model?: string }>;
  exportData: (payload: { name: string; format: ExportFormat; rows: DatasetRow[] }) => Promise<{ ok: boolean; filePath?: string; message: string }>;
  selectSqliteDb: () => Promise<{ canceled: boolean; filePath?: string }>;
  selectFile: (payload: { title: string; extensions: string[] }) => Promise<{ canceled: boolean; filePath?: string }>;
  runSql: (payload: { mode: "sqlite" | "http"; dbPath?: string; endpoint?: string; token?: string; query: string }) => Promise<{ ok: boolean; message: string; rows?: DatasetRow[] }>;
  runCommentCrawler: (payload: { action: "crawl" | "search"; dbPath?: string; configPath?: string; keyword?: string; platform?: string; startDate?: string; endDate?: string; maxPages?: number; limit?: number; saveSnapshots?: boolean }) => Promise<{ ok: boolean; message: string; rows?: DatasetRow[]; output?: string }>;
}

declare global {
  interface Window {
    opsdeputy?: OpsDeputyBridge;
    lucide?: { createIcons: () => void };
  }
}

const navItems: Array<[ViewKey, string, string]> = [
  ["dashboard", "layout-dashboard", "首页"],
  ["workflow", "workflow", "工作流自动化"],
  ["models", "brain-circuit", "模型 / Skill"],
  ["data", "database-zap", "平台数据"],
  ["sentiment", "message-square-warning", "舆情监控"],
  ["collaboration", "messages-square", "办公协同"],
  ["integrations", "plug-zap", "接口设置"],
];

const viewMeta: Record<ViewKey, { title: string; subtitle: string }> = {
  dashboard: { title: "核心数据看板", subtitle: "基于已捕获数据展示 ROI、预算、风险与运营分析，监控事件汇总在首页。" },
  workflow: { title: "工作流自动化", subtitle: "可自由编辑工作流并自由启停执行。" },
  models: { title: "模型 / Skill 管理", subtitle: "集中管理已接入模型、Skill 权限、调用状态和成本边界。" },
  data: { title: "平台数据", subtitle: "展示已接入平台的投放、预算、转化和 ROI 数据，并支持文件输出。" },
  sentiment: { title: "舆情监控", subtitle: "基于评论抓取与导入数据监控负面主题、风险等级和证据留存。" },
  collaboration: { title: "办公协同", subtitle: "接入办公软件后读取文档库、表格、审批、任务和素材资源。" },
  integrations: { title: "接口设置", subtitle: "配置 API、社媒账号、GitHub、SQL、CRM、BI、办公软件和大模型。" },
};

const modelCatalog = [
  { developer: "OpenAI", modelName: "gpt-5.5", protocol: "openai-responses", baseUrl: "https://api.openai.com/v1", note: "OpenAI API 最新旗舰模型" },
  { developer: "OpenAI", modelName: "gpt-5.5-pro", protocol: "openai-responses", baseUrl: "https://api.openai.com/v1", note: "OpenAI API 高精度旗舰模型" },
  { developer: "OpenAI", modelName: "gpt-5.4", protocol: "openai-responses", baseUrl: "https://api.openai.com/v1", note: "OpenAI API 通用专业模型" },
  { developer: "OpenAI", modelName: "gpt-5.4-mini", protocol: "openai-responses", baseUrl: "https://api.openai.com/v1", note: "低延迟与成本敏感任务" },
  { developer: "OpenAI", modelName: "gpt-5.4-nano", protocol: "openai-responses", baseUrl: "https://api.openai.com/v1", note: "高并发轻量任务" },
  { developer: "Google", modelName: "gemini-3.1-pro-preview", protocol: "gemini", baseUrl: "https://generativelanguage.googleapis.com/v1beta", note: "Gemini 3.1 Pro 预览模型" },
  { developer: "Google", modelName: "gemini-3.5-flash", protocol: "gemini", baseUrl: "https://generativelanguage.googleapis.com/v1beta", note: "Gemini 3.5 Flash 稳定模型" },
  { developer: "Google", modelName: "gemini-3-flash-preview", protocol: "gemini", baseUrl: "https://generativelanguage.googleapis.com/v1beta", note: "Gemini 3 Flash 预览模型" },
  { developer: "Google", modelName: "gemini-3.1-flash-lite", protocol: "gemini", baseUrl: "https://generativelanguage.googleapis.com/v1beta", note: "Gemini 3.1 Flash-Lite 轻量模型" },
  { developer: "Google", modelName: "gemini-2.5-pro", protocol: "gemini", baseUrl: "https://generativelanguage.googleapis.com/v1beta", note: "Gemini 稳定版复杂任务模型" },
  { developer: "Anthropic", modelName: "claude-fable-5", protocol: "anthropic", baseUrl: "https://api.anthropic.com", note: "最高能力工作负载" },
  { developer: "Anthropic", modelName: "claude-opus-4-8", protocol: "anthropic", baseUrl: "https://api.anthropic.com", note: "复杂推理与长周期 Agent" },
  { developer: "Anthropic", modelName: "claude-sonnet-4-6", protocol: "anthropic", baseUrl: "https://api.anthropic.com", note: "综合任务与编码" },
  { developer: "Anthropic", modelName: "claude-haiku-4-5-20251001", protocol: "anthropic", baseUrl: "https://api.anthropic.com", note: "轻量快速任务" },
  { developer: "DeepSeek", modelName: "deepseek-v4-pro", protocol: "openai-chat", baseUrl: "https://api.deepseek.com", note: "DeepSeek V4 高能力模型" },
  { developer: "DeepSeek", modelName: "deepseek-v4-flash", protocol: "openai-chat", baseUrl: "https://api.deepseek.com", note: "DeepSeek V4 快速模型" },
  { developer: "Alibaba Cloud Qwen", modelName: "qwen3-max", protocol: "openai-chat", baseUrl: "https://dashscope.aliyuncs.com/compatible-mode/v1", note: "Qwen 旗舰模型" },
  { developer: "Alibaba Cloud Qwen", modelName: "qwen-plus-latest", protocol: "openai-chat", baseUrl: "https://dashscope.aliyuncs.com/compatible-mode/v1", note: "Qwen 通用模型" },
  { developer: "Alibaba Cloud Qwen", modelName: "qwen3-coder-plus", protocol: "openai-chat", baseUrl: "https://dashscope.aliyuncs.com/compatible-mode/v1", note: "代码与 Agent 工作流" },
  { developer: "Moonshot AI", modelName: "kimi-k2.7-code", protocol: "openai-chat", baseUrl: "https://api.moonshot.cn/v1", note: "Kimi K2.7 Code 模型" },
  { developer: "Moonshot AI", modelName: "kimi-k2.6", protocol: "openai-chat", baseUrl: "https://api.moonshot.cn/v1", note: "Kimi K2.6 多模态模型" },
  { developer: "Z.ai / 智谱", modelName: "glm-5.1", protocol: "openai-chat", baseUrl: "https://open.bigmodel.cn/api/paas/v4", note: "GLM 最新旗舰基座模型" },
  { developer: "Z.ai / 智谱", modelName: "glm-4.7", protocol: "openai-chat", baseUrl: "https://open.bigmodel.cn/api/paas/v4", note: "GLM Agentic Coding 模型" },
  { developer: "MiniMax", modelName: "MiniMax-M3", protocol: "minimax-chat", baseUrl: "https://api.minimaxi.com/v1/text/chatcompletion_v2", note: "MiniMax M3 长上下文 Agent 模型" },
  { developer: "Ollama Local", modelName: "qwen3:latest", protocol: "openai-chat", baseUrl: "http://127.0.0.1:11434/v1", note: "本机 Ollama OpenAI 兼容接口，离线可用，可不填 API Key" },
  { developer: "LM Studio Local", modelName: "local-model", protocol: "openai-chat", baseUrl: "http://127.0.0.1:1234/v1", note: "本机 LM Studio OpenAI 兼容接口，离线可用，可不填 API Key" },
  { developer: "LocalAI", modelName: "local-model", protocol: "openai-chat", baseUrl: "http://127.0.0.1:8080/v1", note: "本地 LocalAI / 私有化兼容接口" },
];

const nodeTypes = [
  ["Start", "play", "开始", "接收触发变量和输入"],
  ["LLM", "brain-circuit", "大模型", "调用已接入模型生成结构化结果"],
  ["KnowledgeRetrieval", "library-big", "知识检索", "检索知识库、文档库和历史报告"],
  ["Http", "globe-2", "HTTP 请求", "调用外部 API 或 Webhook"],
  ["Code", "code-2", "代码 / SQL", "执行脚本、SQL 或数据处理"],
  ["IfElse", "split", "条件分支", "按预算、舆情、风险阈值判断"],
  ["HumanInLoop", "user-check", "人工审批", "高风险动作进入审批"],
  ["End", "flag", "输出", "生成文档、CSV/XLS 或协同任务"],
];

const datasets: Record<string, DatasetRow[]> = loadDatasetStore();
let skills: SkillPayload[] = loadSkillStore();
let featureFlags: Record<string, boolean> = loadFeatureFlags();
let crawlerConfig: CrawlerConfig = loadCrawlerConfig();
let connectors: ConnectorPayload[] = [];
let currentView: ViewKey = "dashboard";
let selectedNodeId = "start";
let editingNodeId = "";
let zCounter = 20;
let workflowSequence = 1;
let activeWorkflowId = "workflow_1";
let activeCollabIndex = 0;
let chatMessages: ChatMessage[] = [];

let workflows: WorkflowDefinition[] = [
  {
    id: "workflow_1",
    name: "工作流-1",
    nodes: [
      { id: "start", type: "Start", title: "开始", desc: "手动 / 定时 / Webhook 触发", x: 120, y: 120, z: 1 },
      { id: "knowledge", type: "KnowledgeRetrieval", title: "读取知识库", desc: "客户资料、行业情报、历史报告", x: 390, y: 95, z: 2 },
      { id: "platform", type: "Http", title: "平台数据采集", desc: "已接入平台数据读取", x: 390, y: 255, z: 3 },
      { id: "llm", type: "LLM", title: "策略推理", desc: "预算、ROI、舆情交叉分析", x: 680, y: 170, z: 4 },
      { id: "risk", type: "IfElse", title: "风险判断", desc: "预算变化或风险等级超过阈值", x: 960, y: 170, z: 5 },
      { id: "approval", type: "HumanInLoop", title: "人工审批", desc: "推送办公协同审批", x: 1240, y: 95, z: 6 },
      { id: "end", type: "End", title: "输出结果", desc: "生成文档、CSV/XLS、协同任务", x: 1240, y: 255, z: 7 },
    ],
  },
];

const edges: Array<[string, string]> = [
  ["start", "knowledge"],
  ["start", "platform"],
  ["knowledge", "llm"],
  ["platform", "llm"],
  ["llm", "risk"],
  ["risk", "approval"],
  ["risk", "end"],
];

const appElement = document.getElementById("app");
if (!appElement)
  throw new Error("Missing app root");
const appRoot = appElement as HTMLElement;

function icon(name: string): string {
  return `<i data-lucide="${name}"></i>`;
}

function activeWorkflow(): WorkflowDefinition {
  return workflows.find((workflow) => workflow.id === activeWorkflowId) ?? workflows[0];
}

function workflowNodes(): WorkflowNode[] {
  return activeWorkflow().nodes;
}

function init(): void {
  appRoot.innerHTML = `
    <div class="app-frame">
      <div class="app-shell">
        <header class="titlebar">
          <div class="titlebar-left"><span class="logo-small">${logoSvg()}</span><span>OpsDeputy</span></div>
          <div class="window-controls">
            <button data-window-action="minimize" aria-label="最小化">${icon("minus")}</button>
            <button data-window-action="maximize" aria-label="最大化">${icon("square")}</button>
            <button data-window-action="close" aria-label="关闭">${icon("x")}</button>
          </div>
        </header>
        <div class="app-body">
          <aside class="sidebar">
            <div class="brand">
              <div class="brand-mark">${logoSvg()}</div>
              <div><strong>OpsDeputy</strong></div>
            </div>
            <nav class="nav">${navItems.map(([key, iconName, label]) => `<button class="nav-item" data-view="${key}">${icon(iconName)}<span>${label}</span></button>`).join("")}</nav>
            <div class="sidebar-status">
              <div class="status-row"><span>数据源</span><strong id="sourceCount">0</strong></div>
              <div class="status-row"><span>模型</span><strong id="modelCount">0</strong></div>
              <div class="status-row"><span>SQL</span><strong>可调用</strong></div>
              <div class="status-row"><span>工作流</span><strong id="workflowCount">${workflows.length}</strong></div>
            </div>
          </aside>
          <main class="workspace">
            <section class="topbar">
              <div class="client-strip">
                <label class="field-inline">客户公司<select><option>Example Retail | 新零售</option><option>Example Studio | 内容业务</option><option>Example SaaS | B2B 软件</option></select></label>
                <label class="field-inline">产品线<input value="示例产品线" /></label>
                <button class="btn compact" id="saveClient">${icon("save")}保存</button>
              </div>
              <div class="top-actions">
                <button class="btn compact" id="openSql">${icon("database")}SQL</button>
                <button class="btn compact" id="openHelp">${icon("circle-help")}使用说明</button>
              </div>
            </section>
            <section class="command-bar">
              <div class="command-model">${icon("sparkles")}<select id="modelSelect"></select></div>
              <input id="agentInput" value="请根据已捕获的 ROI、预算、平台投放和舆情风险，生成今天的运营动作。" />
              <button class="btn primary" id="runAgent">${icon("send")}运行</button>
            </section>
            <section id="chatReply" class="chat-reply hidden"></section>
            <section class="view-scroll"><div id="viewRoot"></div></section>
          </main>
        </div>
      </div>
    </div>
    <div id="modal" class="modal-backdrop"></div>
    <div id="contextMenu" class="context-menu"></div>
  `;
  bindShell();
  void loadConnectors();
  render("dashboard");
}

function logoSvg(): string {
  return `<svg class="logo-glyph" viewBox="0 0 48 48" aria-hidden="true">
    <defs><linearGradient id="opsDeputyGradient" x1="7" y1="6" x2="41" y2="43"><stop offset="0%" stop-color="#2563EB"/><stop offset="52%" stop-color="#7C3AED"/><stop offset="100%" stop-color="#60A5FA"/></linearGradient></defs>
    <path d="M24 4 40 10 44 27 33 43 15 40 5 25 10 10Z" fill="url(#opsDeputyGradient)"/>
    <path d="M17 16 30 12 34 24 27 34 16 31 14 21Z" fill="rgba(255,255,255,.36)"/>
  </svg>`;
}

function bindShell(): void {
  document.querySelectorAll<HTMLButtonElement>(".nav-item").forEach((button) => button.addEventListener("click", () => render(button.dataset.view as ViewKey)));
  document.querySelectorAll<HTMLButtonElement>("[data-window-action]").forEach((button) => button.addEventListener("click", () => window.opsdeputy?.windowAction(button.dataset.windowAction as "minimize" | "maximize" | "close")));
  document.getElementById("openHelp")?.addEventListener("click", openHelp);
  document.getElementById("openSql")?.addEventListener("click", openSqlModal);
  document.getElementById("saveClient")?.addEventListener("click", () => openActionModal("客户配置", "客户公司与产品线已保存在当前工作区。"));
  document.getElementById("runAgent")?.addEventListener("click", () => void runAgentChat());
  window.lucide?.createIcons();
}

async function loadConnectors(): Promise<void> {
  connectors = window.opsdeputy ? await window.opsdeputy.getConnectors() : readLocalConnectors();
  updateModelSelect();
  updateShellCounts();
  render(currentView);
}

function readLocalConnectors(): ConnectorPayload[] {
  try {
    return JSON.parse(localStorage.getItem("opsdeputy.connectors") || "[]") as ConnectorPayload[];
  } catch {
    return [];
  }
}

function writeLocalConnector(connector: ConnectorPayload): void {
  const all = readLocalConnectors();
  const saved = { ...connector, id: connector.id || `connector_${Date.now()}` };
  const index = all.findIndex((item) => item.id === saved.id);
  if (index >= 0) all[index] = saved;
  else all.push(saved);
  localStorage.setItem("opsdeputy.connectors", JSON.stringify(all));
  connectors = all;
}

function updateShellCounts(): void {
  setText("sourceCount", String(connectors.length));
  setText("modelCount", String(llmConnectors().length));
  setText("workflowCount", String(workflows.length));
}

function updateModelSelect(): void {
  const select = document.getElementById("modelSelect") as HTMLSelectElement | null;
  if (!select)
    return;
  const models = llmConnectors();
  select.innerHTML = models.length
    ? models.map((model) => `<option value="${model.id}">${model.developer || model.provider} · ${model.modelName || model.name}</option>`).join("")
    : `<option value="">——</option>`;
}

function llmConnectors(): ConnectorPayload[] {
  return connectors.filter((connector) => connector.kind === "llm");
}

function platformConnectors(): ConnectorPayload[] {
  return connectors.filter((connector) => ["ads_platform", "social_platform"].includes(connector.kind));
}

function collaborationConnectors(): ConnectorPayload[] {
  return connectors.filter((connector) => connector.kind === "collaboration");
}

function render(view: ViewKey): void {
  currentView = view;
  const root = document.getElementById("viewRoot");
  if (!root)
    return;
  const map: Record<ViewKey, () => string> = {
    dashboard: dashboardView,
    workflow: workflowView,
    models: modelsView,
    data: dataView,
    sentiment: sentimentView,
    collaboration: collaborationView,
    integrations: integrationsView,
  };
  root.innerHTML = map[view]();
  document.querySelectorAll<HTMLButtonElement>(".nav-item").forEach((item) => item.classList.toggle("active", item.dataset.view === view));
  bindView();
  window.lucide?.createIcons();
}

function titleBlock(key: ViewKey, action = ""): string {
  const meta = viewMeta[key];
  return `<div class="page-title"><div><h1>${meta.title}</h1><p>${meta.subtitle}</p></div>${action}</div>`;
}

function dashboardView(): string {
  const roiRows = rows("roi");
  const riskRows = rows("risks");
  const pendingHigh = riskRows.filter((row) => row.level === "高" && row.status !== "approved").length;
  return `<section class="view">
    ${titleBlock("dashboard", `<button class="btn" id="refreshDashboard">${icon("refresh-cw")}刷新</button>`)}
    <div class="metric-strip">
      ${metric("今日 ROAS", currentRoas(roiRows), roiRows.length ? "来自已捕获数据" : "暂无已捕获 ROI", roiRows.length ? "good" : "")}
      ${metric("预算剩余", "¥184k", "来自预算数据源", "")}
      ${metric("需审批风险", String(pendingHigh), pendingHigh ? "点击批量审批可处理" : "无高优先级审批", pendingHigh ? "danger" : "good")}
      ${metric("接入源", String(connectors.length), "本机已配置", "")}
    </div>
    <div class="dashboard-grid">
      <div class="panel"><div class="panel-header"><div class="icon-title">${icon("line-chart")}<h2>ROI 监控图</h2></div><span class="pill">捕获数据</span></div>${roiRows.length ? `<div class="canvas-wrap"><canvas id="roiChart" width="980" height="320"></canvas></div>` : emptyState("暂无已捕获 ROI 数据", "请通过平台 API、CSV 导入或 SQL 查询写入 ROI 数据。")}${exportButtons("roi", roiRows)}</div>
      <div class="panel"><div class="panel-header"><div class="icon-title">${icon("shield-alert")}<h2>风险建议</h2></div><button class="btn compact" id="approveRisks" ${pendingHigh ? "" : "disabled"}>${icon("check-check")}批量审批</button></div>${riskRows.map((row) => riskRow(row)).join("")}${exportButtons("risks", riskRows)}</div>
    </div>
    <div class="dashboard-grid">
      <div class="panel"><div class="panel-header"><div class="icon-title">${icon("wallet-cards")}<h2>预算管理</h2></div><button class="btn compact" data-open-sql>${icon("database")}接入 SQL</button></div>${rows("budget").map((row) => budgetRow(row)).join("")}${exportButtons("budget", rows("budget"))}</div>
      <div class="panel"><div class="panel-header"><div class="icon-title">${icon("database-zap")}<h2>数据分析</h2></div><button class="btn compact" id="generateInsight">${icon("bot")}生成洞察</button></div>${analysisRows()}${exportButtons("analysis", rows("analysis"))}</div>
    </div>
  </section>`;
}

function workflowView(): string {
  const workflow = activeWorkflow();
  const selected = workflow.nodes.find((node) => node.id === selectedNodeId) ?? workflow.nodes[0];
  return `<section class="view">
    ${titleBlock("workflow", `<button class="btn primary" id="runWorkflow">${icon("play")}执行当前工作流</button>`)}
    <div class="workflow-layout">
      <div class="panel workflow-list"><div class="panel-header"><div class="icon-title">${icon("list-tree")}<h2>工作流列表</h2></div><button class="btn compact" id="newWorkflow">${icon("plus")}新建</button></div>${workflows.map((item) => workflowListItem(item)).join("")}</div>
      <div class="panel node-palette"><div class="panel-header"><div class="icon-title">${icon("blocks")}<h2>节点库</h2></div></div><div class="palette-group">${nodeTypes.map((node) => paletteNode(node)).join("")}</div></div>
      <div id="workflowBoard" class="workflow-board"><div id="workflowCanvas" class="workflow-canvas-inner">
        <div class="workflow-toolbar"><button class="btn compact" id="autoLayout">${icon("align-center-horizontal")}自动整理</button><button class="btn compact" id="addLlm">${icon("plus")}大模型</button><button class="btn compact" id="openSqlNode">${icon("database")}SQL</button></div>
        <svg id="edgeLayer" class="edge-layer"></svg>
        ${workflow.nodes.map((node) => workflowNode(node)).join("")}
      </div></div>
      <div class="panel node-settings"><div class="panel-header"><div class="icon-title">${icon("sliders-horizontal")}<h2>节点设置</h2></div></div>${nodeSettings(selected)}</div>
    </div>
  </section>`;
}

function modelsView(): string {
  const models = llmConnectors();
  return `<section class="view">
    ${titleBlock("models", `<button class="btn primary" id="goModelApi">${icon("plug-zap")}配置 API</button>`)}
    <div class="dashboard-grid">
      <div class="panel"><div class="panel-header"><div class="icon-title">${icon("brain-circuit")}<h2>已接入模型</h2></div></div>${models.length ? `<div class="settings-list">${models.map((model) => modelRow(model)).join("")}</div>` : emptyState("尚未接入大模型", "请点击“配置 API”添加开发商、模型名称和 API 地址。")}${exportButtons("llm-models", models.map((model) => ({ name: model.name, developer: model.developer || model.provider, model: model.modelName || "", baseUrl: model.baseUrl })))}</div>
      <div class="panel"><div class="panel-header"><div class="icon-title">${icon("boxes")}<h2>Skill 管理</h2></div><button class="btn compact" id="addSkill">${icon("plus")}添加 Skill</button></div><div class="settings-list">${skills.map((skill) => skillRow(skill)).join("")}</div>${exportButtons("skills", skills.map((skill) => ({ name: skill.name, category: skill.category, enabled: skill.enabled, source: skill.source, githubUrl: skill.githubUrl })))}</div>
    </div>
  </section>`;
}

function dataView(): string {
  const platforms = platformConnectors();
  return `<section class="view">
    ${titleBlock("data", `<button class="btn primary" id="goPlatformApi">${icon("plug-zap")}配置平台 API</button>`)}
    <div class="panel"><div class="panel-header"><div class="icon-title">${icon("bar-chart-3")}<h2>已接入平台</h2></div><button class="btn compact" data-open-sql>${icon("database")}SQL 调用</button></div>${platforms.length ? `<div class="data-grid">${platforms.map((connector) => platformCard(connector)).join("")}</div>` : emptyState("尚未接入平台", "请点击右上角“配置平台 API”添加平台账号或 API。")}${exportButtons("platforms", platformRowsForExport(platforms))}</div>
    <div class="dashboard-grid"><div class="panel"><div class="panel-header"><div class="icon-title">${icon("shield-check")}<h2>采集方式</h2></div></div>${toggleLine("platform.officialApi", "官方 API 优先", "平台账号授权后读取投放、预算、素材和转化数据。")}${toggleLine("platform.authorizedExport", "授权导出兜底", "支持平台 CSV/XLS/JSON 报表导入后参与看板计算。")}${toggleLine("platform.publicCollection", "公开采集", "仅在授权、限速和合规前提下采集公开信息。")}</div><div class="panel"><div class="panel-header"><div class="icon-title">${icon("file-check-2")}<h2>数据输出</h2></div></div>${exportButtons("ad-collection-report", platformRowsForExport(platforms))}</div></div>
  </section>`;
}

function sentimentView(): string {
  const sentimentRows = rows("sentiment");
  return `<section class="view">${titleBlock("sentiment", `<button class="btn primary" id="runCrawlerSearch">${icon("play")}检索评论</button>`)}<div class="metric-strip">${metric("今日评论", String(totalComments(sentimentRows)), "来自评论库", "")}${metric("负面占比", "8.7%", "较上一周期 +2.1%", "danger")}${metric("高危主题", String(sentimentRows.filter((row) => row.level === "高").length), "需协同处理", "")}${metric("证据留存", featureFlags["sentiment.evidenceArchive"] ? "开启" : "关闭", "URL 与快照", "")}</div><div class="dashboard-grid"><div class="panel"><div class="panel-header"><div class="icon-title">${icon("message-square-warning")}<h2>舆情风险队列</h2></div></div><div class="settings-list">${sentimentRows.map((row) => riskRow({ level: row.level, title: row.topic, detail: `${row.count} 条 · ${row.source}` })).join("")}</div>${exportButtons("sentiment", sentimentRows)}</div><div class="panel"><div class="panel-header"><div class="icon-title">${icon("sliders-horizontal")}<h2>抓取设置</h2></div></div>${crawlerSettingsForm()}${toggleLine("sentiment.configCrawler", "配置驱动抓取", "支持 HTML、JSON、自动提取和 JSONL 导入。")}${toggleLine("sentiment.evidenceArchive", "证据归档", "保留 URL、抓取时间、平台、评分和原始片段。")}${toggleLine("sentiment.autoRisk", "风险自动分级", "根据关键词、评分段和数量变化生成风险队列。")}</div></div></section>`;
}

function collaborationView(): string {
  const collabs = collaborationConnectors();
  return `<section class="view">
    ${titleBlock("collaboration")}
    <div class="dashboard-grid">
      <div class="panel"><div class="panel-header"><div class="icon-title">${icon("messages-square")}<h2>办公软件接口</h2></div></div><div class="settings-list">${officeOptions().map((row) => `<div class="resource-row"><div class="row-head"><strong>${row.name}</strong><button class="btn compact" data-provider="${row.provider}" data-open-office>${icon("settings")}配置</button></div><p class="subtext">${row.desc}</p></div>`).join("")}</div>${exportButtons("collaboration-connectors", collabs.map((item) => ({ name: item.name, provider: item.provider, baseUrl: item.baseUrl })))}</div>
      <div class="panel"><div class="panel-header"><div class="icon-title">${icon("table-properties")}<h2>资源列表</h2></div>${collabs.length ? carouselDots(collabs.length) : ""}</div>${collabs.length ? collaborationCarousel(collabs) : `<div class="empty-center">请接入办公软件</div>`}</div>
    </div>
  </section>`;
}

function integrationsView(): string {
  return `<section class="view">
    ${titleBlock("integrations", `<div class="toolbar-row"><button class="btn primary" id="addModelApi">${icon("brain-circuit")}大模型接入</button><button class="btn" id="addGenericApi">${icon("plus")}新增 API</button></div>`)}
    <div class="dashboard-grid">
      <div class="panel"><div class="panel-header"><div class="icon-title">${icon("key-round")}<h2>API 接入</h2></div></div><div class="settings-list">${integrationRows().map((row) => `<div class="integration-row"><div class="row-head"><strong>${row.name}</strong><span class="pill">${row.status}</span></div><p class="subtext">${row.desc}</p><div class="toolbar-row"><button class="btn compact" data-integration="${row.id}">${icon(row.icon)}${row.action}</button></div></div>`).join("")}</div></div>
      <div class="panel"><div class="panel-header"><div class="icon-title">${icon("brain-circuit")}<h2>大模型接入</h2></div><button class="btn compact" id="addModelApiInline">${icon("plus")}添加</button></div>${llmConnectors().length ? llmConnectors().map((model) => `<div class="integration-row"><div class="row-head"><strong>${model.developer || model.provider} · ${model.modelName || model.name}</strong><span class="pill">${model.protocol || "api"}</span></div><p class="subtext">${model.baseUrl}</p></div>`).join("") : emptyState("尚未接入大模型", "添加后会同步出现在顶部模型选择和“模型 / Skill 管理”模块。")}</div>
    </div>
  </section>`;
}

function bindView(): void {
  document.querySelectorAll<HTMLButtonElement>("[data-export]").forEach((button) => button.addEventListener("click", () => void exportDataset(button.dataset.export ?? "", button.dataset.format as ExportFormat)));
  document.querySelectorAll<HTMLElement>("[data-open-sql]").forEach((item) => item.addEventListener("click", openSqlModal));
  document.getElementById("openSqlNode")?.addEventListener("click", openSqlModal);
  document.getElementById("refreshDashboard")?.addEventListener("click", () => openActionModal("刷新看板", "已重新读取本机已捕获数据。外部 API 数据请在对应接口中执行读取。"));
  document.getElementById("generateInsight")?.addEventListener("click", () => void runAgentChat());
  document.getElementById("approveRisks")?.addEventListener("click", approvePendingRisks);
  document.getElementById("goPlatformApi")?.addEventListener("click", () => render("integrations"));
  document.getElementById("goModelApi")?.addEventListener("click", () => render("integrations"));
  document.getElementById("addSkill")?.addEventListener("click", () => openSkillModal());
  document.querySelectorAll<HTMLElement>("[data-skill-toggle]").forEach((item) => item.addEventListener("click", () => toggleSkill(item.dataset.skillToggle ?? "")));
  document.querySelectorAll<HTMLElement>("[data-skill-edit]").forEach((item) => item.addEventListener("click", () => openSkillModal(item.dataset.skillEdit ?? "")));
  document.querySelectorAll<HTMLElement>("[data-skill-delete]").forEach((item) => item.addEventListener("click", () => deleteSkill(item.dataset.skillDelete ?? "")));
  document.querySelectorAll<HTMLElement>("[data-toggle]").forEach((item) => item.addEventListener("click", () => toggleFeature(item.dataset.toggle ?? "")));
  document.querySelectorAll<HTMLElement>("[data-integration]").forEach((item) => item.addEventListener("click", () => openIntegration(item.dataset.integration ?? "")));
  document.getElementById("saveCrawlerSettings")?.addEventListener("click", saveCrawlerSettings);
  document.getElementById("chooseCrawlerDb")?.addEventListener("click", () => void chooseCrawlerFile("db"));
  document.getElementById("chooseCrawlerConfig")?.addEventListener("click", () => void chooseCrawlerFile("config"));
  document.getElementById("toggleCrawlerSnapshot")?.addEventListener("click", (event) => {
    const button = event.currentTarget as HTMLButtonElement;
    button.classList.toggle("on");
    button.setAttribute("aria-pressed", button.classList.contains("on") ? "true" : "false");
  });
  document.getElementById("runCrawlerSearch")?.addEventListener("click", () => void runCrawler("search"));
  document.getElementById("runCrawlerCrawl")?.addEventListener("click", () => void runCrawler("crawl"));
  document.getElementById("addGenericApi")?.addEventListener("click", () => openConnectorModal("API 接入", "ads_platform", "custom"));
  document.getElementById("addModelApi")?.addEventListener("click", openModelConnectorModal);
  document.getElementById("addModelApiInline")?.addEventListener("click", openModelConnectorModal);
  document.querySelectorAll<HTMLElement>("[data-open-office]").forEach((item) => item.addEventListener("click", () => openConnectorModal("办公协同", "collaboration", item.dataset.provider ?? "feishu")));
  document.querySelectorAll<HTMLElement>("[data-deploy-resource]").forEach((item) => item.addEventListener("click", () => deployCollaborationResource(item.dataset.deployResource ?? "")));
  document.querySelectorAll<HTMLElement>("[data-collab-dot]").forEach((item) => item.addEventListener("click", () => { activeCollabIndex = Number(item.dataset.collabDot || "0"); render("collaboration"); }));
  if (currentView === "dashboard" && rows("roi").length) drawRoiChart();
  if (currentView === "workflow") bindWorkflow();
  window.lucide?.createIcons();
}

function bindWorkflow(): void {
  document.querySelectorAll<HTMLButtonElement>("[data-add-node]").forEach((button) => button.addEventListener("click", () => addNode(button.dataset.addNode ?? "LLM")));
  document.querySelectorAll<HTMLButtonElement>("[data-workflow-id]").forEach((button) => button.addEventListener("click", () => { activeWorkflowId = button.dataset.workflowId || activeWorkflowId; selectedNodeId = workflowNodes()[0]?.id || ""; render("workflow"); }));
  document.querySelectorAll<HTMLInputElement>("[data-workflow-name]").forEach((input) => input.addEventListener("change", () => renameWorkflow(input.dataset.workflowName || "", input.value)));
  document.getElementById("newWorkflow")?.addEventListener("click", createWorkflow);
  document.getElementById("addLlm")?.addEventListener("click", () => addNode("LLM"));
  document.getElementById("autoLayout")?.addEventListener("click", autoLayout);
  document.getElementById("runWorkflow")?.addEventListener("click", () => openActionModal("工作流执行", "已启动当前工作流。执行记录会写入本机日志，涉及预算调整或外部推送的动作需要审批。"));
  document.getElementById("saveNodeTitle")?.addEventListener("click", saveSelectedNode);
  document.querySelectorAll<HTMLInputElement>("[data-node-title-input]").forEach((input) => {
    input.addEventListener("keydown", (event) => {
      if (event.key === "Enter") commitInlineNodeRename(input);
      if (event.key === "Escape") { editingNodeId = ""; render("workflow"); }
    });
    input.addEventListener("blur", () => commitInlineNodeRename(input));
    input.focus();
    input.select();
  });
  bindNodeDragging();
  drawEdges();
}

function runAgentChat(): Promise<void> {
  const select = document.getElementById("modelSelect") as HTMLSelectElement | null;
  const input = document.getElementById("agentInput") as HTMLInputElement | null;
  const connectorId = select?.value || "";
  const prompt = input?.value.trim() || "";
  if (!connectorId) {
    setChatReply("请先在“接口设置”中接入大模型。", "system");
    return Promise.resolve();
  }
  if (!prompt) {
    setChatReply("请输入需要调度的问题。", "system");
    return Promise.resolve();
  }
  chatMessages.push({ role: "user", content: prompt, at: new Date().toLocaleTimeString() });
  setChatReply("正在调用大模型 API...", "loading");
  return (window.opsdeputy ? window.opsdeputy.chat({ connectorId, prompt }) : Promise.resolve({ ok: true, message: "静态模式", answer: "当前为静态预览；在 Electron 成品中会调用已配置的大模型 API。", model: "静态预览" })).then((result) => {
    const answer = result.ok ? (result.answer || result.message) : `调用失败：${result.message}`;
    chatMessages.push({ role: "assistant", content: answer, at: new Date().toLocaleTimeString(), model: result.model });
    setChatReply(answer, result.ok ? "answer" : "error");
  });
}

function setChatReply(message: string, type: string): void {
  const panel = document.getElementById("chatReply");
  if (!panel) return;
  const transient = ["loading", "system", "error"].includes(type)
    ? `<div class="chat-message ${type}"><span>${type === "loading" ? "系统" : "状态"}</span><p>${escapeHtml(message)}</p></div>`
    : "";
  panel.classList.remove("hidden");
  panel.innerHTML = `<div class="chat-reply-head"><strong>${type === "answer" ? "模型回复" : "对话状态"}</strong><button class="btn compact" id="closeChatReply">${icon("chevron-up")}收起</button></div><div class="chat-messages">${chatMessages.map((item) => `<div class="chat-message ${item.role}"><span>${item.role === "user" ? "我" : item.model || "模型"}</span><p>${escapeHtml(String(item.content))}</p></div>`).join("")}${transient}</div>`;
  document.getElementById("closeChatReply")?.addEventListener("click", () => panel.classList.add("hidden"));
  window.lucide?.createIcons();
}

function approvePendingRisks(): void {
  datasets.risks = rows("risks").map((row) => row.level === "高" && row.status !== "approved" ? { ...row, status: "approved", detail: `${row.detail}（已审批）` } : row);
  saveDatasetStore();
  render("dashboard");
}

function createWorkflow(): void {
  workflowSequence += 1;
  const id = `workflow_${Date.now()}`;
  workflows.push({ id, name: `工作流-${workflowSequence}`, nodes: [{ id: `start_${Date.now()}`, type: "Start", title: "开始", desc: "新的工作流入口", x: 120, y: 120, z: ++zCounter }] });
  activeWorkflowId = id;
  selectedNodeId = workflows[workflows.length - 1].nodes[0].id;
  render("workflow");
}

function renameWorkflow(id: string, name: string): void {
  const workflow = workflows.find((item) => item.id === id);
  if (workflow) workflow.name = name.trim() || workflow.name;
  updateShellCounts();
}

function workflowListItem(workflow: WorkflowDefinition): string {
  const active = workflow.id === activeWorkflowId ? " active" : "";
  return `<div class="workflow-list-item${active}"><button class="btn compact" data-workflow-id="${workflow.id}">${icon("workflow")}</button><input data-workflow-name="${workflow.id}" value="${workflow.name}" /><span class="pill">${workflow.nodes.length}</span></div>`;
}

function modelRow(model: ConnectorPayload): string {
  return `<div class="setting-line"><div><strong>${model.modelName || model.name}</strong><p class="subtext">${model.developer || model.provider} · ${model.baseUrl}</p></div><span class="pill">${model.protocol || "api"}</span></div>`;
}

function skillRow(skill: SkillPayload): string {
  return `<div class="setting-line"><div><strong>${skill.name}</strong><p class="subtext">${skill.category} · ${skill.githubUrl || skill.entrypoint || "内置 Skill"}</p></div><div class="row-actions"><button class="toggle ${skill.enabled ? "on" : ""}" data-skill-toggle="${skill.id}" aria-pressed="${skill.enabled}" title="${skill.enabled ? "关闭" : "开启"}"></button><button class="btn compact" data-skill-edit="${skill.id}">${icon("settings")}配置</button><button class="btn compact danger-outline" data-skill-delete="${skill.id}" ${skill.source === "builtin" ? "disabled" : ""}>${icon("trash-2")}删除</button></div></div>`;
}

function toggleSkill(id: string): void {
  const skill = skills.find((item) => item.id === id);
  if (!skill) return;
  skill.enabled = !skill.enabled;
  saveSkillStore();
  render("models");
}

function deleteSkill(id: string): void {
  const skill = skills.find((item) => item.id === id);
  if (!skill || skill.source === "builtin") return;
  skills = skills.filter((item) => item.id !== id);
  saveSkillStore();
  render("models");
}

function toggleLine(id: string, title: string, desc: string): string {
  const on = Boolean(featureFlags[id]);
  return `<div class="setting-line"><div><strong>${title}</strong><p class="subtext">${desc}</p></div><button class="toggle ${on ? "on" : ""}" data-toggle="${id}" aria-pressed="${on}" title="${on ? "关闭" : "开启"}"></button></div>`;
}

function toggleFeature(id: string): void {
  featureFlags[id] = !featureFlags[id];
  saveFeatureFlags();
  render(currentView);
}

function paletteNode(node: string[]): string {
  const [type, iconName, title, desc] = node;
  return `<button class="palette-node" data-add-node="${type}"><span class="node-icon">${icon(iconName)}</span><span><strong>${title}</strong><p class="subtext">${desc}</p></span></button>`;
}

function workflowNode(node: WorkflowNode): string {
  const selected = node.id === selectedNodeId ? " selected" : "";
  const iconName = nodeTypes.find(([type]) => type === node.type)?.[1] ?? "box";
  const title = editingNodeId === node.id ? `<input class="node-title-input" data-node-title-input="${node.id}" value="${escapeHtml(node.title)}" />` : `<strong>${node.title}</strong>`;
  return `<div class="node-card${selected}" data-node-id="${node.id}" style="left:${node.x}px;top:${node.y}px;z-index:${node.z}"><span class="node-port in"></span><span class="node-port out"></span><div class="node-title"><span class="node-icon">${icon(iconName)}</span>${title}</div><p class="subtext">${node.desc}</p><span class="pill">${node.type}</span></div>`;
}

function nodeSettings(node: WorkflowNode | undefined): string {
  if (!node) return emptyState("请选择节点", "选择或新建节点后可编辑参数。");
  return `<div class="form-grid"><div class="field"><label>节点名称</label><input id="nodeTitleInput" value="${escapeHtml(node.title)}" /></div><div class="field"><label>节点类型</label><input value="${node.type}" readonly /></div><div class="field"><label>配置说明</label><textarea>${escapeHtml(node.desc)}</textarea></div><button class="btn primary" id="saveNodeTitle">${icon("save")}保存节点</button></div>`;
}

function bindNodeDragging(): void {
  const board = document.getElementById("workflowCanvas");
  if (!board) return;
  board.querySelectorAll<HTMLElement>(".node-card").forEach((card) => {
    card.addEventListener("pointerdown", (event) => {
      if (event.button !== 0 || (event.target as HTMLElement).tagName === "INPUT") return;
      const id = card.dataset.nodeId ?? "";
      selectedNodeId = id;
      const node = workflowNodes().find((item) => item.id === id);
      if (!node) return;
      node.z = ++zCounter;
      card.classList.add("dragging");
      const startX = event.clientX;
      const startY = event.clientY;
      const originX = node.x;
      const originY = node.y;
      const move = (moveEvent: PointerEvent) => {
        node.x = Math.max(24, originX + moveEvent.clientX - startX);
        node.y = Math.max(78, originY + moveEvent.clientY - startY);
        card.style.left = `${node.x}px`;
        card.style.top = `${node.y}px`;
        card.style.zIndex = `${node.z}`;
        drawEdges();
      };
      const up = () => {
        card.classList.remove("dragging");
        window.removeEventListener("pointermove", move);
        window.removeEventListener("pointerup", up);
        render("workflow");
      };
      window.addEventListener("pointermove", move);
      window.addEventListener("pointerup", up);
    });
    card.addEventListener("contextmenu", (event) => {
      event.preventDefault();
      selectedNodeId = card.dataset.nodeId ?? selectedNodeId;
      showContextMenu(event.clientX, event.clientY);
    });
  });
}

function showContextMenu(x: number, y: number): void {
  const menu = document.getElementById("contextMenu");
  const node = workflowNodes().find((item) => item.id === selectedNodeId);
  if (!menu || !node) return;
  menu.innerHTML = `
    <button data-node-action="rename">${icon("pencil")}重命名节点</button>
    <button data-node-action="duplicate">${icon("copy")}复制节点</button>
    <button data-node-action="front">${icon("bring-to-front")}置于顶层</button>
    <button data-node-action="back">${icon("send-to-back")}置于底层</button>
    <button data-node-action="delete" class="danger-text">${icon("trash-2")}删除节点</button>`;
  menu.style.left = `${x}px`;
  menu.style.top = `${y}px`;
  menu.classList.add("visible");
  menu.querySelectorAll<HTMLButtonElement>("[data-node-action]").forEach((button) => button.addEventListener("click", () => handleNodeAction(button.dataset.nodeAction ?? "")));
  window.lucide?.createIcons();
  const close = () => {
    menu.classList.remove("visible");
    document.removeEventListener("click", close);
  };
  setTimeout(() => document.addEventListener("click", close), 0);
}

function handleNodeAction(action: string): void {
  const nodes = workflowNodes();
  const node = nodes.find((item) => item.id === selectedNodeId);
  if (!node) return;
  if (action === "delete") {
    activeWorkflow().nodes = nodes.filter((item) => item.id !== node.id);
    selectedNodeId = workflowNodes()[0]?.id ?? "";
  }
  if (action === "duplicate") {
    const clone = { ...node, id: `node_${Date.now()}`, title: `${node.title} 副本`, x: node.x + 34, y: node.y + 34, z: ++zCounter };
    nodes.push(clone);
    selectedNodeId = clone.id;
  }
  if (action === "front") node.z = ++zCounter;
  if (action === "back") node.z = 1;
  if (action === "rename") editingNodeId = node.id;
  render("workflow");
}

function commitInlineNodeRename(input: HTMLInputElement): void {
  const node = workflowNodes().find((item) => item.id === input.dataset.nodeTitleInput);
  if (node) node.title = input.value.trim() || node.title;
  editingNodeId = "";
  render("workflow");
}

function addNode(type: string): void {
  const template = nodeTypes.find(([name]) => name === type) ?? nodeTypes[1];
  const node: WorkflowNode = { id: `node_${Date.now()}`, type, title: template[2], desc: template[3], x: 160 + Math.random() * 420, y: 140 + Math.random() * 260, z: ++zCounter };
  workflowNodes().push(node);
  selectedNodeId = node.id;
  render("workflow");
}

function autoLayout(): void {
  workflowNodes().forEach((node, index) => {
    node.x = 120 + (index % 4) * 280;
    node.y = 120 + Math.floor(index / 4) * 170;
  });
  render("workflow");
}

function saveSelectedNode(): void {
  const node = workflowNodes().find((item) => item.id === selectedNodeId);
  const input = document.getElementById("nodeTitleInput") as HTMLInputElement | null;
  if (node && input) {
    node.title = input.value.trim() || node.title;
    render("workflow");
  }
}

function drawEdges(): void {
  const svg = document.getElementById("edgeLayer") as unknown as SVGSVGElement | null;
  if (!svg) return;
  svg.setAttribute("viewBox", "0 0 1800 980");
  svg.innerHTML = `<defs><marker id="arrow" markerWidth="10" markerHeight="10" refX="8" refY="3" orient="auto"><path d="M0,0 L0,6 L9,3 z" fill="#60a5fa"/></marker></defs>`;
  const byId = new Map(workflowNodes().map((node) => [node.id, node]));
  edges.forEach(([from, to]) => {
    const a = byId.get(from);
    const b = byId.get(to);
    if (!a || !b) return;
    const x1 = a.x + 210;
    const y1 = a.y + 52;
    const x2 = b.x;
    const y2 = b.y + 52;
    const dx = Math.max(80, Math.abs(x2 - x1) / 2);
    const path = document.createElementNS("http://www.w3.org/2000/svg", "path");
    path.setAttribute("d", `M ${x1} ${y1} C ${x1 + dx} ${y1}, ${x2 - dx} ${y2}, ${x2} ${y2}`);
    path.setAttribute("stroke", "#60a5fa");
    path.setAttribute("stroke-width", "2");
    path.setAttribute("fill", "none");
    path.setAttribute("marker-end", "url(#arrow)");
    svg.appendChild(path);
  });
}

function openSkillModal(skillId = ""): void {
  const skill = skills.find((item) => item.id === skillId);
  showModal(`<div class="modal-title"><div><h2>${skill ? "配置 Skill" : "添加 Skill"}</h2><p class="subtext">支持 GitHub 仓库、raw 文件或内置入口，保存后可在 Skill 管理列表启停。</p></div><button class="btn compact" data-close-modal>${icon("x")}关闭</button></div><div class="form-grid"><input id="skillId" type="hidden" value="${skill?.id || ""}" /><div class="field"><label>Skill 名称</label><input id="skillName" value="${escapeHtml(skill?.name || "")}" placeholder="例如：竞品投放分析 Skill" /></div><div class="field"><label>GitHub 地址</label><input id="skillGithub" value="${escapeHtml(skill?.githubUrl || "")}" placeholder="https://github.com/owner/repo 或 raw 文件地址" /></div><div class="field"><label>入口文件 / 目录</label><input id="skillEntrypoint" value="${escapeHtml(skill?.entrypoint || "SKILL.md")}" placeholder="SKILL.md / skills/my-skill/SKILL.md" /></div><div class="field"><label>分类</label><select id="skillCategory"><option>策略</option><option>预算</option><option>平台数据</option><option>舆情</option><option>协同</option><option>报告</option><option>自定义</option></select></div><div class="field"><label>权限说明</label><textarea id="skillPermissions" placeholder="读取数据、生成建议、写入协同任务等">${escapeHtml(skill?.permissions || "读取数据；生成建议；需要人工审批后执行写入动作")}</textarea></div><div class="toolbar-row"><button class="btn primary" id="saveSkill">${icon("save")}保存 Skill</button><button class="btn" id="verifySkill">${icon("github")}验证 GitHub</button></div><pre id="skillResult" class="sql-result">等待操作</pre></div>`, "wide");
  setValue("skillCategory", skill?.category || "自定义");
  document.getElementById("saveSkill")?.addEventListener("click", saveSkillFromForm);
  document.getElementById("verifySkill")?.addEventListener("click", () => void verifySkillFromForm());
}

function skillFromForm(): SkillPayload {
  const id = valueOf("skillId") || `skill_${Date.now()}`;
  return {
    id,
    name: valueOf("skillName") || "未命名 Skill",
    category: valueOf("skillCategory") || "自定义",
    githubUrl: valueOf("skillGithub"),
    entrypoint: valueOf("skillEntrypoint") || "SKILL.md",
    permissions: valueOf("skillPermissions"),
    enabled: skills.find((item) => item.id === id)?.enabled ?? true,
    source: valueOf("skillGithub") ? "github" : "builtin",
  };
}

function saveSkillFromForm(): void {
  const skill = skillFromForm();
  const index = skills.findIndex((item) => item.id === skill.id);
  if (index >= 0) skills[index] = skill;
  else skills.push(skill);
  saveSkillStore();
  closeModal();
  render("models");
}

async function verifySkillFromForm(): Promise<void> {
  const output = document.getElementById("skillResult");
  const url = valueOf("skillGithub");
  if (!url) {
    if (output) output.textContent = "请先填写 GitHub 地址。";
    return;
  }
  const repo = parseGithubRepo(url);
  if (!repo) {
    if (output) output.textContent = "未识别到 GitHub 仓库地址；raw 文件地址仍可保存，但无法用仓库 API 验证。";
    return;
  }
  try {
    const response = await fetch(`https://api.github.com/repos/${repo.owner}/${repo.repo}`);
    const data = await response.json();
    if (output) output.textContent = response.ok ? `验证成功：${data.full_name || `${repo.owner}/${repo.repo}`}` : `验证失败：${data.message || response.status}`;
  } catch (error) {
    if (output) output.textContent = `无法联网验证，仍可保存为离线配置：${error instanceof Error ? error.message : String(error)}`;
  }
}

function parseGithubRepo(url: string): { owner: string; repo: string } | null {
  const match = url.match(/github\.com\/([^/\s]+)\/([^/\s#?]+)/i);
  if (!match) return null;
  return { owner: match[1], repo: match[2].replace(/\.git$/, "") };
}

function openModelConnectorModal(): void {
  showModal(`<div class="modal-title"><div><h2>大模型接入</h2><p class="subtext">添加后会同步出现在顶部模型列表和“模型 / Skill 管理”。</p></div><button class="btn compact" data-close-modal>${icon("x")}关闭</button></div><div class="form-grid"><div class="field"><label>模型候选</label><select id="modelPreset">${modelCatalog.map((item, index) => `<option value="${index}">${item.developer} · ${item.modelName}</option>`).join("")}</select></div><div class="field"><label>开发商</label><input id="connDeveloper" /></div><div class="field"><label>模型名称</label><input id="connModelName" /></div><div class="field"><label>协议</label><select id="connProtocol"><option value="openai-responses">OpenAI Responses</option><option value="openai-chat">OpenAI Compatible Chat</option><option value="anthropic">Anthropic Messages</option><option value="gemini">Gemini generateContent</option><option value="minimax-chat">MiniMax ChatCompletion v2</option></select></div><div class="field"><label>API 地址</label><input id="connUrl" /></div><div class="field"><label>API Key / Access Token</label><input id="connKey" type="password" /></div><div class="toolbar-row"><button class="btn primary" id="saveModelConn">${icon("save")}保存大模型</button><button class="btn" id="testModelConn">${icon("wifi")}测试连接</button></div><pre id="connPreview" class="sql-result">请选择模型候选。</pre></div>`, "wide");
  const applyPreset = () => {
    const preset = modelCatalog[Number(valueOf("modelPreset"))] ?? modelCatalog[0];
    setValue("connDeveloper", preset.developer);
    setValue("connModelName", preset.modelName);
    setValue("connProtocol", preset.protocol);
    setValue("connUrl", preset.baseUrl);
    setText("connPreview", preset.note);
  };
  document.getElementById("modelPreset")?.addEventListener("change", applyPreset);
  document.getElementById("saveModelConn")?.addEventListener("click", () => void saveModelConnector());
  document.getElementById("testModelConn")?.addEventListener("click", () => void connectorAction("test", modelConnectorFromForm()));
  applyPreset();
}

function modelConnectorFromForm(): ConnectorPayload {
  return { name: `${valueOf("connDeveloper")} ${valueOf("connModelName")}`, kind: "llm", provider: valueOf("connDeveloper").toLowerCase(), developer: valueOf("connDeveloper"), modelName: valueOf("connModelName"), protocol: valueOf("connProtocol"), baseUrl: valueOf("connUrl"), accountId: "", accessToken: valueOf("connKey"), apiKey: valueOf("connKey") };
}

async function saveModelConnector(): Promise<void> {
  const connector = modelConnectorFromForm();
  await saveConnector(connector);
  closeModal();
  updateModelSelect();
  render("models");
}

function openConnectorModal(title: string, kind: string, provider: string): void {
  showModal(`<div class="modal-title"><div><h2>${title}</h2><p class="subtext">保存、测试并读取 API 预览。</p></div><button class="btn compact" data-close-modal>${icon("x")}关闭</button></div><div class="form-grid"><div class="field"><label>连接名称</label><input id="connName" value="${provider} connector" /></div><div class="field"><label>类型</label><input id="connKind" value="${kind}" /></div><div class="field"><label>Provider</label><input id="connProvider" value="${provider}" /></div><div class="field"><label>API 地址</label><input id="connUrl" value="${defaultConnectorUrl(provider)}" /></div><div class="field"><label>账号 / App / Repo ID</label><input id="connAccount" /></div><div class="field"><label>Access Token</label><input id="connToken" type="password" /></div><div class="field"><label>API Key</label><input id="connKey" type="password" /></div><div class="toolbar-row"><button class="btn primary" id="saveConn">${icon("save")}保存</button><button class="btn" id="testConn">${icon("wifi")}测试</button><button class="btn" id="readConn">${icon("download-cloud")}读取</button></div><pre id="connPreview" class="sql-result">等待操作</pre></div>`, "wide");
  document.getElementById("saveConn")?.addEventListener("click", () => void connectorAction("save", genericConnectorFromForm()));
  document.getElementById("testConn")?.addEventListener("click", () => void connectorAction("test", genericConnectorFromForm()));
  document.getElementById("readConn")?.addEventListener("click", () => void connectorAction("read", genericConnectorFromForm()));
}

function genericConnectorFromForm(): ConnectorPayload {
  return { name: valueOf("connName"), kind: valueOf("connKind"), provider: valueOf("connProvider"), baseUrl: valueOf("connUrl"), accountId: valueOf("connAccount"), accessToken: valueOf("connToken"), apiKey: valueOf("connKey") };
}

async function connectorAction(action: "save" | "test" | "read", connector: ConnectorPayload): Promise<void> {
  const out = document.getElementById("connPreview");
  if (action === "save") {
    const saved = await saveConnector(connector);
    if (out) out.textContent = JSON.stringify(saved, null, 2);
    return;
  }
  if (!window.opsdeputy) {
    if (out) out.textContent = "当前为静态模式，需在 Electron 中测试连接。";
    return;
  }
  const result = action === "test" ? await window.opsdeputy.testConnector(connector) : await window.opsdeputy.readConnector(connector);
  const preview = action === "read" ? (result as { preview?: string }).preview : "";
  if (preview) captureRowsFromPreview(connector, preview);
  if (out) out.textContent = JSON.stringify(result, null, 2);
}

async function saveConnector(connector: ConnectorPayload): Promise<ConnectorPayload> {
  let saved: ConnectorPayload;
  if (window.opsdeputy) saved = await window.opsdeputy.saveConnector(connector);
  else {
    writeLocalConnector(connector);
    saved = connector;
  }
  await loadConnectors();
  return saved;
}

function captureRowsFromPreview(connector: ConnectorPayload, preview: string): void {
  try {
    const parsed = JSON.parse(preview) as unknown;
    const parsedRecord = isRecord(parsed) ? parsed : {};
    const rawList = Array.isArray(parsed) ? parsed : Array.isArray(parsedRecord.data) ? parsedRecord.data : Array.isArray(parsedRecord.rows) ? parsedRecord.rows : [];
    const list = rawList.filter(isRecord);
    if (connector.kind === "ads_platform" || connector.kind === "social_platform") {
      const normalized = list.map((item) => ({ platform: connector.name, ads: Number(item.ads ?? item.ad_count ?? item.count ?? 0), spend: Number(item.spend ?? item.cost ?? 0), roas: Number(item.roas ?? item.roi ?? 0), source: connector.provider }));
      if (normalized.length) {
        datasets.platforms = normalized;
        datasets.roi = normalized.filter((item) => item.roas).map((item, index) => ({ hour: String(index + 1), roas: item.roas, spend: item.spend }));
        saveDatasetStore();
      }
    }
  } catch {
    // Preview is not JSON; keep raw preview only.
  }
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return Boolean(value && typeof value === "object" && !Array.isArray(value));
}

function platformRowsForExport(platforms: ConnectorPayload[]): DatasetRow[] {
  if (!platforms.length) return [];
  const captured = rows("platforms");
  return platforms.map((connector, index) => {
    const data = captured[index] ?? {};
    return { platform: connector.name, provider: connector.provider, ads: data.ads ?? "待读取", spend: data.spend ?? "待读取", roas: data.roas ?? "待读取", api: connector.baseUrl };
  });
}

function platformCard(connector: ConnectorPayload): string {
  const data = rows("platforms").find((row) => String(row.platform).toLowerCase().includes(connector.provider.toLowerCase())) ?? {};
  return `<div class="data-card"><div class="platform-icon">${platformInitial(connector)}</div><span class="subtext">${connector.provider}</span><strong>${connector.name}</strong><span>投放数 ${data.ads ?? "待读取"} · ROAS ${data.roas ?? "待读取"}</span><span class="pill">${connector.baseUrl ? "已配置 API" : "待配置"}</span></div>`;
}

function platformInitial(connector: ConnectorPayload): string {
  return (connector.name || connector.provider || "?").slice(0, 1).toUpperCase();
}

function collaborationCarousel(collabs: ConnectorPayload[]): string {
  const connector = collabs[Math.min(activeCollabIndex, collabs.length - 1)];
  const features = officeFeatureMap(connector.provider);
  return `<div class="collab-carousel"><div class="collab-slide"><div class="platform-icon">${platformInitial(connector)}</div><h3>${connector.name}</h3><p class="subtext">${connector.baseUrl || "已保存本机配置"}</p><div class="feature-row">${features.map((feature) => `<span class="pill">${feature}</span>`).join("")}</div><button class="btn primary compact" data-deploy-resource="${connector.id}">${icon("upload-cloud")}部署资源</button></div></div>`;
}

function carouselDots(length: number): string {
  return `<div class="carousel-dots">${Array.from({ length }, (_, index) => `<button class="${index === activeCollabIndex ? "active" : ""}" data-collab-dot="${index}" aria-label="切换资源 ${index + 1}"></button>`).join("")}</div>`;
}

function officeFeatureMap(provider: string): string[] {
  if (provider.includes("feishu")) return ["多维表格", "文档库", "审批", "PPT输出", "任务同步"];
  if (provider.includes("microsoft")) return ["SharePoint", "Teams", "PowerPoint 输出", "Planner"];
  if (provider.includes("google")) return ["Drive", "Docs", "Sheets", "Slides 输出"];
  return ["消息同步", "任务分配", "审批", "文档链接"];
}

function deployCollaborationResource(id: string): void {
  const connector = connectors.find((item) => item.id === id);
  if (!connector) return;
  datasets["collaboration-resources"] = [
    { platform: connector.name, resource: "多维表格", status: "已生成部署任务", at: new Date().toLocaleString() },
    { platform: connector.name, resource: "PPT 输出", status: "等待授权确认", at: new Date().toLocaleString() },
  ];
  saveDatasetStore();
  openActionModal("资源部署", `${connector.name} 的资源部署任务已写入本机数据，可在导出文件中查看。`);
}

function officeOptions(): Array<{ name: string; provider: string; desc: string }> {
  return [
    { name: "飞书 / 多维表格", provider: "feishu", desc: "读取多维表格、云文档、审批和任务。" },
    { name: "Microsoft 365 / Teams", provider: "microsoft", desc: "读取 SharePoint、Drive、Teams、Planner。" },
    { name: "Google Workspace", provider: "google", desc: "读取 Drive、Docs、Sheets 和任务。" },
    { name: "企业微信 / 钉钉 / Slack", provider: "im", desc: "消息、审批、任务和文档链接。" },
  ];
}

function integrationRows(): Array<{ id: string; name: string; desc: string; status: string; action: string; icon: string }> {
  return [
    { id: "github", name: "GitHub", desc: "Repo、Issue、PR、Webhook、Actions", status: connectorStatus("github"), action: "配置", icon: "github" },
    { id: "sql", name: "SQL 数据源", desc: "SQLite、本地 DB 文件、HTTP SQL 网关", status: "可调用", action: "打开", icon: "database" },
    { id: "platform", name: "平台与社媒", desc: "TikTok、小红书、抖音、Meta、Google Ads", status: platformConnectors().length ? "已接入" : "可接入", action: "配置", icon: "plug-zap" },
    { id: "office", name: "办公协同", desc: "飞书、Microsoft 365、Google Workspace、企业微信、钉钉", status: collaborationConnectors().length ? "已接入" : "可接入", action: "配置", icon: "messages-square" },
    { id: "crm", name: "CRM / BI", desc: "客户、订单、库存、毛利、经营指标", status: connectorStatus("crm"), action: "配置", icon: "bar-chart-3" },
  ];
}

function connectorStatus(kindOrProvider: string): string {
  return connectors.some((connector) => connector.kind === kindOrProvider || connector.provider === kindOrProvider) ? "已接入" : "可配置";
}

function openIntegration(id: string): void {
  const actions: Record<string, () => void> = {
    github: () => openConnectorModal("GitHub 接入", "github", "github"),
    sql: openSqlModal,
    platform: () => openConnectorModal("平台与社媒接入", "ads_platform", "tiktok"),
    office: () => openConnectorModal("办公协同接入", "collaboration", "feishu"),
    crm: () => openConnectorModal("CRM / BI 接入", "crm", "custom"),
  };
  actions[id]?.();
}

function crawlerSettingsForm(): string {
  return `<div class="crawler-form"><div class="field"><label>关键词</label><input id="crawlerKeyword" value="${escapeHtml(crawlerConfig.keyword)}" placeholder="退款, 价格, 发货" /></div><div class="form-row"><div class="field"><label>开始日期</label><input id="crawlerStart" type="date" value="${crawlerConfig.startDate}" /></div><div class="field"><label>结束日期</label><input id="crawlerEnd" type="date" value="${crawlerConfig.endDate}" /></div></div><div class="form-row"><div class="field"><label>平台</label><input id="crawlerPlatform" value="${escapeHtml(crawlerConfig.platform)}" placeholder="xiaohongshu / tiktok / douyin" /></div><div class="field"><label>检索数量</label><input id="crawlerLimit" type="number" min="1" max="500" value="${crawlerConfig.limit}" /></div></div><div class="field"><label>评论 SQLite 数据库</label><div class="input-action"><input id="crawlerDb" value="${escapeHtml(crawlerConfig.dbPath)}" placeholder="选择 comments.db" /><button class="btn compact" id="chooseCrawlerDb">${icon("folder-open")}选择</button></div></div><div class="field"><label>抓取配置 JSON</label><div class="input-action"><input id="crawlerConfigPath" value="${escapeHtml(crawlerConfig.configPath)}" placeholder="crawl-config.json" /><button class="btn compact" id="chooseCrawlerConfig">${icon("folder-open")}选择</button></div></div><div class="form-row"><div class="field"><label>最大页数</label><input id="crawlerMaxPages" type="number" min="1" max="100" value="${crawlerConfig.maxPages}" /></div><div class="field"><label>快照</label><button class="toggle ${crawlerConfig.saveSnapshots ? "on" : ""}" id="toggleCrawlerSnapshot" aria-pressed="${crawlerConfig.saveSnapshots}"></button></div></div><div class="toolbar-row"><button class="btn primary" id="saveCrawlerSettings">${icon("save")}保存设置</button><button class="btn" id="runCrawlerCrawl">${icon("download-cloud")}执行抓取</button></div></div>`;
}

function totalComments(items: DatasetRow[]): string {
  const total = items.reduce((sum, row) => sum + Number(row.count || 0), 0);
  return total ? String(total) : "0";
}

function saveCrawlerSettings(): void {
  crawlerConfig = crawlerConfigFromForm();
  saveCrawlerConfig();
  openActionModal("抓取设置", "设置已保存到本机配置。");
}

function crawlerConfigFromForm(): CrawlerConfig {
  return {
    keyword: valueOf("crawlerKeyword"),
    platform: valueOf("crawlerPlatform"),
    startDate: valueOf("crawlerStart"),
    endDate: valueOf("crawlerEnd"),
    dbPath: valueOf("crawlerDb"),
    configPath: valueOf("crawlerConfigPath"),
    maxPages: Number(valueOf("crawlerMaxPages") || 3),
    limit: Number(valueOf("crawlerLimit") || 50),
    saveSnapshots: (document.getElementById("toggleCrawlerSnapshot") as HTMLButtonElement | null)?.classList.contains("on") ?? crawlerConfig.saveSnapshots,
  };
}

async function chooseCrawlerFile(target: "db" | "config"): Promise<void> {
  if (!window.opsdeputy) {
    openActionModal("文件选择", "需要在桌面应用中选择本地文件。");
    return;
  }
  const result = await window.opsdeputy.selectFile({ title: target === "db" ? "选择评论 SQLite 数据库" : "选择抓取配置 JSON", extensions: target === "db" ? ["db", "sqlite", "sqlite3"] : ["json"] });
  if (result.filePath) setValue(target === "db" ? "crawlerDb" : "crawlerConfigPath", result.filePath);
}

async function runCrawler(action: "crawl" | "search"): Promise<void> {
  crawlerConfig = crawlerConfigFromForm();
  saveCrawlerConfig();
  if (!window.opsdeputy) {
    openActionModal("舆情监控", "静态模式下不能运行本机抓取工具。");
    return;
  }
  const result = await window.opsdeputy.runCommentCrawler({
    action,
    dbPath: crawlerConfig.dbPath,
    configPath: crawlerConfig.configPath,
    keyword: crawlerConfig.keyword,
    platform: crawlerConfig.platform,
    startDate: crawlerConfig.startDate,
    endDate: crawlerConfig.endDate,
    maxPages: crawlerConfig.maxPages,
    limit: crawlerConfig.limit,
    saveSnapshots: crawlerConfig.saveSnapshots,
  });
  if (result.rows?.length) {
    datasets.sentiment = result.rows.map((row) => ({ topic: row.content ? String(row.content).slice(0, 18) : row.keyword || "评论命中", level: row.rating_band === "low" ? "高" : "中", count: 1, source: row.platform || row.source_name || "comment_crawler" }));
    saveDatasetStore();
  }
  openActionModal(action === "crawl" ? "抓取结果" : "检索结果", result.message || result.output || "操作完成。");
  render("sentiment");
}

function drawRoiChart(): void {
  const canvas = document.getElementById("roiChart") as HTMLCanvasElement | null;
  if (!canvas) return;
  const ctx = canvas.getContext("2d");
  if (!ctx) return;
  const roiRows = rows("roi");
  const values = roiRows.map((row) => Number(row.roas)).filter(Number.isFinite);
  if (!values.length) return;
  const w = canvas.width;
  const h = canvas.height;
  const pad = 42;
  const min = Math.min(...values) - 0.1;
  const max = Math.max(...values) + 0.1;
  ctx.clearRect(0, 0, w, h);
  ctx.strokeStyle = "rgba(148, 163, 184, .24)";
  ctx.lineWidth = 1;
  for (let i = 0; i < 5; i += 1) {
    const y = pad + ((h - pad * 2) / 4) * i;
    ctx.beginPath();
    ctx.moveTo(pad, y);
    ctx.lineTo(w - pad, y);
    ctx.stroke();
  }
  const points = values.map((value, index) => {
    const x = pad + ((w - pad * 2) / Math.max(values.length - 1, 1)) * index;
    const y = h - pad - ((value - min) / (max - min || 1)) * (h - pad * 2);
    return [x, y, value];
  });
  ctx.strokeStyle = "#2563eb";
  ctx.lineWidth = 4;
  ctx.beginPath();
  points.forEach(([x, y], index) => index ? ctx.lineTo(x, y) : ctx.moveTo(x, y));
  ctx.stroke();
  points.forEach(([x, y, value]) => {
    ctx.fillStyle = value >= 3 ? "#16a34a" : "#dc2626";
    ctx.beginPath();
    ctx.arc(x, y, 5, 0, Math.PI * 2);
    ctx.fill();
  });
  ctx.fillStyle = "#64748b";
  ctx.font = "13px Microsoft YaHei";
  ctx.fillText(String(roiRows[0]?.hour ?? ""), pad, h - 12);
  ctx.fillText(String(roiRows[roiRows.length - 1]?.hour ?? ""), w - pad - 42, h - 12);
}

function currentRoas(roiRows: DatasetRow[]): string {
  const last = roiRows[roiRows.length - 1];
  return last?.roas ? String(last.roas) : "--";
}

function rows(name: string): DatasetRow[] {
  return datasets[name] ?? [];
}

function loadDatasetStore(): Record<string, DatasetRow[]> {
  const fallback: Record<string, DatasetRow[]> = {
    roi: [
      { hour: "00:00", roas: 2.72, spend: 21000, source: "captured" },
      { hour: "04:00", roas: 2.94, spend: 34000, source: "captured" },
      { hour: "08:00", roas: 2.87, spend: 61000, source: "captured" },
      { hour: "12:00", roas: 3.12, spend: 86000, source: "captured" },
      { hour: "16:00", roas: 3.21, spend: 119000, source: "captured" },
      { hour: "now", roas: 3.38, spend: 146000, source: "captured" },
    ],
    budget: [
      { channel: "搜索广告", ratio: 42, delta: "+8%", note: "高意图词包继续放量" },
      { channel: "短视频", ratio: 31, delta: "-12%", note: "素材疲劳，CPA 超阈值" },
      { channel: "再营销", ratio: 17, delta: "+4%", note: "高意向回访提升" },
      { channel: "内容种草", ratio: 10, delta: "观察", note: "归因不足，保留观察" },
    ],
    platforms: [],
    risks: [
      { level: "高", title: "竞品价格冲击", detail: "核心 SKU 价格下调 11%，建议暂停低毛利素材。", status: "pending" },
      { level: "中", title: "预算消耗过快", detail: "搜索渠道将在 21:30 前触顶，建议重设日内上限。", status: "pending" },
      { level: "中", title: "评论风险升高", detail: "售后退款相关负面评论 2 小时内增加 73 条。", status: "pending" },
    ],
    sentiment: [
      { topic: "售后退款", level: "高", count: 73, source: "小红书 / TikTok" },
      { topic: "价格争议", level: "中", count: 41, source: "抖音 / 小红书" },
      { topic: "发货延迟", level: "低", count: 18, source: "站内评论" },
    ],
    analysis: [
      { item: "渠道贡献", value: "搜索贡献新增订单 48%，边际 CPA 抬升。" },
      { item: "人群洞察", value: "25-34 岁女性点击率提升 16%。" },
    ],
  };
  try {
    return { ...fallback, ...JSON.parse(localStorage.getItem("opsdeputy.datasets") || "{}") };
  } catch {
    return fallback;
  }
}

function loadSkillStore(): SkillPayload[] {
  const fallback: SkillPayload[] = [
    { id: "skill_market", name: "市场趋势 Skill", category: "策略", githubUrl: "", entrypoint: "builtin://market-trends", permissions: "读取平台与行业数据；生成策略建议", enabled: true, source: "builtin" },
    { id: "skill_budget", name: "预算优化 Skill", category: "预算", githubUrl: "", entrypoint: "builtin://budget-optimizer", permissions: "读取 ROI 与预算数据；生成预算调整建议", enabled: true, source: "builtin" },
    { id: "skill_platform", name: "平台数据采集 Skill", category: "平台数据", githubUrl: "", entrypoint: "builtin://platform-collector", permissions: "读取已授权平台 API；写入捕获数据", enabled: true, source: "builtin" },
    { id: "skill_sentiment", name: "舆情监控 Skill", category: "舆情", githubUrl: "", entrypoint: "resources/skills/comment_crawler.py", permissions: "运行本机评论检索；生成风险队列", enabled: true, source: "builtin" },
    { id: "skill_evidence", name: "证据审计 Skill", category: "报告", githubUrl: "", entrypoint: "builtin://evidence-audit", permissions: "读取证据引用；生成审计摘要", enabled: true, source: "builtin" },
  ];
  try {
    const saved = JSON.parse(localStorage.getItem("opsdeputy.skills") || "[]") as SkillPayload[];
    return saved.length ? saved : fallback;
  } catch {
    return fallback;
  }
}

function saveSkillStore(): void {
  localStorage.setItem("opsdeputy.skills", JSON.stringify(skills));
}

function loadFeatureFlags(): Record<string, boolean> {
  const fallback: Record<string, boolean> = {
    "platform.officialApi": true,
    "platform.authorizedExport": true,
    "platform.publicCollection": false,
    "sentiment.configCrawler": true,
    "sentiment.evidenceArchive": true,
    "sentiment.autoRisk": true,
  };
  try {
    return { ...fallback, ...JSON.parse(localStorage.getItem("opsdeputy.featureFlags") || "{}") };
  } catch {
    return fallback;
  }
}

function saveFeatureFlags(): void {
  localStorage.setItem("opsdeputy.featureFlags", JSON.stringify(featureFlags));
}

function loadCrawlerConfig(): CrawlerConfig {
  const today = new Date().toISOString().slice(0, 10);
  const fallback: CrawlerConfig = {
    keyword: "退款, 价格, 发货",
    platform: "xiaohongshu,tiktok",
    startDate: today,
    endDate: today,
    dbPath: "",
    configPath: "",
    maxPages: 3,
    limit: 50,
    saveSnapshots: true,
  };
  try {
    return { ...fallback, ...JSON.parse(localStorage.getItem("opsdeputy.crawlerConfig") || "{}") };
  } catch {
    return fallback;
  }
}

function saveCrawlerConfig(): void {
  localStorage.setItem("opsdeputy.crawlerConfig", JSON.stringify(crawlerConfig));
}

function saveDatasetStore(): void {
  localStorage.setItem("opsdeputy.datasets", JSON.stringify(datasets));
}

function metric(label: string, value: string, note: string, cls: string): string {
  return `<div class="metric"><span>${label}</span><strong class="${cls}">${value}</strong><small>${note}</small></div>`;
}

function budgetRow(row: DatasetRow): string {
  return `<div class="budget-row"><div class="row-head"><strong>${row.channel}</strong><span>${row.ratio}% · ${row.delta}</span></div><div class="bar-track"><div class="bar-fill" style="width:${row.ratio}%"></div></div><p class="subtext">${row.note}</p></div>`;
}

function riskRow(row: DatasetRow): string {
  const level = String(row.level);
  const cls = level === "高" ? "high" : level === "中" ? "mid" : "low";
  const status = row.status === "approved" ? `<span class="pill">已审批</span>` : `<span class="risk-tag ${cls}">${level}</span>`;
  return `<div class="risk-row"><div class="row-head"><strong>${row.title}</strong>${status}</div><p class="subtext">${row.detail}</p></div>`;
}

function analysisRows(): string {
  return rows("analysis").map((row) => `<div class="analysis-row"><strong>${row.item}</strong><p class="subtext">${row.value}</p></div>`).join("");
}

function emptyState(title: string, desc: string): string {
  return `<div class="empty-state"><strong>${title}</strong><p>${desc}</p></div>`;
}

function exportButtons(name: string, exportRows: DatasetRow[]): string {
  return `<div class="export-row"><span class="subtext">数据行数：${exportRows.length}</span><div><button class="btn compact" data-export="${name}" data-format="xls">${icon("file-spreadsheet")}输出 XLS</button> <button class="btn compact" data-export="${name}" data-format="csv">${icon("file-down")}输出 CSV</button></div></div>`;
}

async function exportDataset(name: string, format: ExportFormat): Promise<void> {
  const exportRows = rows(name);
  if (window.opsdeputy) {
    const result = await window.opsdeputy.exportData({ name, format, rows: exportRows });
    openActionModal("导出结果", result.message);
    return;
  }
  const text = format === "csv" ? rowsToCsv(exportRows) : rowsToXls(exportRows);
  const blob = new Blob([text], { type: format === "csv" ? "text/csv;charset=utf-8" : "application/vnd.ms-excel;charset=utf-8" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = `${name}.${format}`;
  a.click();
  URL.revokeObjectURL(a.href);
}

function rowsToCsv(exportRows: DatasetRow[]): string {
  const headers = Object.keys(exportRows[0] ?? {});
  return [headers.join(","), ...exportRows.map((row) => headers.map((key) => `"${String(row[key] ?? "").replaceAll('"', '""')}"`).join(","))].join("\n");
}

function rowsToXls(exportRows: DatasetRow[]): string {
  const headers = Object.keys(exportRows[0] ?? {});
  return `<table><thead><tr>${headers.map((h) => `<th>${h}</th>`).join("")}</tr></thead><tbody>${exportRows.map((row) => `<tr>${headers.map((h) => `<td>${row[h] ?? ""}</td>`).join("")}</tr>`).join("")}</tbody></table>`;
}

function openSqlModal(): void {
  showModal(`<div class="modal-title"><div><h2>SQL 调用窗口</h2><p class="subtext">支持 SQLite 文件或 HTTP SQL 网关，查询结果可写入看板。</p></div><button class="btn compact" data-close-modal>${icon("x")}关闭</button></div><div class="form-grid"><div class="field"><label>模式</label><select id="sqlMode"><option value="sqlite">SQLite 文件</option><option value="http">HTTP SQL 网关</option></select></div><div class="field"><label>SQLite 文件 / SQL API 地址</label><input id="sqlSource" placeholder="选择 .db/.sqlite 或输入 https://..." /></div><div class="toolbar-row"><button class="btn" id="chooseDb">${icon("folder-open")}选择 DB</button><button class="btn primary" id="runSql">${icon("play")}运行 SQL</button></div><div class="field"><label>SQL</label><textarea id="sqlQuery">select '00:00' as hour, 3.12 as roas, 12000 as spend</textarea></div><pre id="sqlResult" class="sql-result">等待查询</pre><div id="sqlExport"></div></div>`, "wide");
  document.getElementById("chooseDb")?.addEventListener("click", async () => {
    const result = await window.opsdeputy?.selectSqliteDb();
    if (result?.filePath) setValue("sqlSource", result.filePath);
  });
  document.getElementById("runSql")?.addEventListener("click", () => void runSql());
}

async function runSql(): Promise<void> {
  const mode = valueOf("sqlMode") as "sqlite" | "http";
  const source = valueOf("sqlSource");
  const query = valueOf("sqlQuery");
  const resultBox = document.getElementById("sqlResult");
  if (!window.opsdeputy) {
    if (resultBox) resultBox.textContent = "需要在 Electron 中运行 SQL。";
    return;
  }
  const result = await window.opsdeputy.runSql({ mode, dbPath: mode === "sqlite" ? source : undefined, endpoint: mode === "http" ? source : undefined, query });
  if (result.rows?.length) {
    datasets["sql-result"] = result.rows;
    if ("roas" in result.rows[0]) datasets.roi = result.rows;
    saveDatasetStore();
  }
  if (resultBox) resultBox.textContent = JSON.stringify(result.rows ?? result, null, 2);
  const exportRoot = document.getElementById("sqlExport");
  if (exportRoot && result.rows?.length) {
    exportRoot.innerHTML = exportButtons("sql-result", result.rows);
    bindView();
  }
}

function showModal(content: string, widthClass = ""): void {
  const modal = document.getElementById("modal");
  if (!modal) return;
  modal.innerHTML = `<div class="modal-panel ${widthClass}">${content}</div>`;
  modal.classList.add("visible");
  modal.querySelectorAll("[data-close-modal]").forEach((item) => item.addEventListener("click", closeModal));
  modal.addEventListener("click", (event) => {
    if (event.target === modal) closeModal();
  }, { once: true });
  window.lucide?.createIcons();
}

function closeModal(): void {
  const modal = document.getElementById("modal");
  if (modal) {
    modal.classList.remove("visible");
    modal.innerHTML = "";
  }
}

function openHelp(): void {
  showModal(`<div class="modal-title"><div><h2>使用说明</h2><p class="subtext">关键操作路径</p></div><button class="btn compact" data-close-modal>${icon("x")}关闭</button></div><div class="settings-list">${["在接口设置中接入大模型后，顶部模型列表会自动出现对应模型。", "顶部对话框会调用已接入模型 API，并在下拉回复区显示结果。", "工作流可在列表中新建、重命名，并在画布中自由拖拽节点。", "ROI 图表优先使用 API、SQL 或文件导入后的已捕获数据。", "平台、舆情、预算和 SQL 查询结果均可输出 XLS 或 CSV。"].map((text) => `<div class="resource-row">${text}</div>`).join("")}</div>`);
}

function openActionModal(title: string, message: string): void {
  showModal(`<div class="modal-title"><div><h2>${title}</h2><p class="subtext">${message}</p></div><button class="btn compact" data-close-modal>${icon("x")}关闭</button></div>`);
}

function defaultConnectorUrl(provider: string): string {
  const urls: Record<string, string> = {
    tiktok: "https://business-api.tiktok.com/open_api/v1.3/report/integrated/get/",
    feishu: "https://open.feishu.cn/open-apis/bitable/v1/apps/{app_token}/tables/{table_id}/records/search",
    microsoft: "https://graph.microsoft.com/v1.0/me/drive/root/children",
    google: "https://www.googleapis.com/drive/v3/files",
    github: "https://api.github.com/repos/{owner}/{repo}/contents",
  };
  return urls[provider] ?? "https://api.example.com";
}

function setText(id: string, value: string): void {
  const el = document.getElementById(id);
  if (el) el.textContent = value;
}

function setValue(id: string, value: string): void {
  const el = document.getElementById(id) as HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement | null;
  if (el) el.value = value;
}

function valueOf(id: string): string {
  const input = document.getElementById(id) as HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement | null;
  return input?.value.trim() ?? "";
}

function escapeHtml(value: string): string {
  return value.replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll('"', "&quot;");
}

init();
