using UnityEngine;
using System.Collections;

public class SkillSystem : MonoBehaviour
{
    public float qDamage = 30f;

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Q))
        {
            StartCoroutine(AOE());
        }

        if (Input.GetKeyDown(KeyCode.E))
        {
            StartCoroutine(Dash());
        }
    }

    IEnumerator AOE()
    {
        Collider[] hits = Physics.OverlapSphere(transform.position, 5f);

        foreach (var h in hits)
        {
            Damageable d = h.GetComponent<Damageable>();
            if (d != null)
            {
                d.TakeDamage(qDamage);
            }
        }

        yield return null;
    }

    IEnumerator Dash()
    {
        float t = 0f;

        while (t < 0.2f)
        {
            transform.Translate(Vector3.forward * 20f * Time.deltaTime);
            t += Time.deltaTime;
            yield return null;
        }
    }
}