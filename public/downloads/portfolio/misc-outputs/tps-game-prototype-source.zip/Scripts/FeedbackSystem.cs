using UnityEngine;
using System.Collections;

public class FeedbackSystem : MonoBehaviour
{
    public static FeedbackSystem Instance;

    void Awake(){ Instance = this; }

    public void PlayHit(Transform cam)
    {
        StartCoroutine(HitStop());
        if (cam) cam.GetComponent<CameraShake>()?.StartCoroutine(
            cam.GetComponent<CameraShake>().Shake(0.1f,0.1f));
    }

    IEnumerator HitStop()
    {
        Time.timeScale = 0.1f;
        yield return new WaitForSecondsRealtime(0.05f);
        Time.timeScale = 1f;
    }
}