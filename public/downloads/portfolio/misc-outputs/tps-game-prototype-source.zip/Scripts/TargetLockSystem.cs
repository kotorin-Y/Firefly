using UnityEngine;

public class TargetLockSystem : MonoBehaviour
{
    public Transform currentTarget;
    public float range = 20f;

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Tab)) FindTarget();
    }

    void FindTarget()
    {
        GameObject[] enemies = GameObject.FindGameObjectsWithTag("Enemy");
        float min = Mathf.Infinity;

        foreach (var e in enemies)
        {
            float d = Vector3.Distance(transform.position, e.transform.position);
            if (d < min && d <= range)
            {
                min = d;
                currentTarget = e.transform;
            }
        }
    }
}