using UnityEngine;
using System.Collections;

public class CameraShake : MonoBehaviour
{
    Vector3 origin;

    public IEnumerator Shake(float d, float m)
    {
        origin = transform.localPosition;
        float t = 0;

        while (t < d)
        {
            transform.localPosition = origin + Random.insideUnitSphere * m;
            t += Time.deltaTime;
            yield return null;
        }

        transform.localPosition = origin;
    }
}