using UnityEngine;

public class TPSCamera : MonoBehaviour
{
    public Transform target;
    public Vector3 normalOffset = new Vector3(0,2,-3);
    public Vector3 aimOffset = new Vector3(0,1.5f,-2);

    float yaw, pitch;

    void LateUpdate()
    {
        yaw += Input.GetAxis("Mouse X") * 5f;
        pitch -= Input.GetAxis("Mouse Y") * 5f;
        pitch = Mathf.Clamp(pitch, -30f, 60f);

        Vector3 offset = Input.GetMouseButton(1) ? aimOffset : normalOffset;
        Quaternion rot = Quaternion.Euler(pitch, yaw, 0);

        transform.position = target.position + rot * offset;
        transform.LookAt(target.position + Vector3.up * 1.5f);

        target.rotation = Quaternion.Euler(0, yaw, 0);
    }
}
