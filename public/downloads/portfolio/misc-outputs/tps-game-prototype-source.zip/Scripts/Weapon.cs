using UnityEngine;

public class Weapon : MonoBehaviour
{
    public float damage = 10f;
    public Camera cam;
    public TargetLockSystem lockSys;
    public AudioSource audioSource;

    public GameObject muzzleFlash;
    public GameObject hitEffect;

    void Update()
    {
        if (Input.GetButtonDown("Fire1")) Shoot();
    }

    void Shoot()
{
    if (audioSource != null)
    {
        audioSource.Play();
    }

    if (muzzleFlash) Instantiate(muzzleFlash, transform.position, transform.rotation);

    if (lockSys && lockSys.currentTarget)
    {
        ApplyDamage(lockSys.currentTarget);
        return;
    }

    RaycastHit hit;
    if (Physics.Raycast(cam.transform.position, cam.transform.forward, out hit))
    {
        if (hitEffect) Instantiate(hitEffect, hit.point, Quaternion.identity);
        ApplyDamage(hit.transform);
    }
}

    void ApplyDamage(Transform t)
    {
        var d = t.GetComponent<Damageable>();
        if (d) d.TakeDamage(damage);
    }
}

