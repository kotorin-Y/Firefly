using UnityEngine;

[RequireComponent(typeof(UnityEngine.AI.NavMeshAgent))]
public class EnemyAI : MonoBehaviour
{
    public Transform player;
    UnityEngine.AI.NavMeshAgent agent;

    void Start(){ agent = GetComponent<UnityEngine.AI.NavMeshAgent>(); }

    void Update()
    {
        if (player) agent.SetDestination(player.position);
    }
}