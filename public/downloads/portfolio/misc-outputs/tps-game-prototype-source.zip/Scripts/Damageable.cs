using UnityEngine;

public class Damageable : MonoBehaviour
{
    public float health = 100f;
    public Transform cam;

    public void TakeDamage(float dmg)
    {
        health -= dmg;

        FeedbackSystem.Instance?.PlayHit(cam);

        if (health <= 0)
        {
            Destroy(gameObject);
        }
    }
}