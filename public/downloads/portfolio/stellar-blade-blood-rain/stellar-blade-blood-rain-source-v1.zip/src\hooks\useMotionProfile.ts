import { useEffect, useState } from 'react';
import { getMotionProfile, type MotionProfile } from '../motion';

type NavigatorWithConnection = Navigator & {
  connection?: {
    saveData?: boolean;
    addEventListener?: (type: string, listener: () => void) => void;
    removeEventListener?: (type: string, listener: () => void) => void;
  };
};

function readMotionProfile(): MotionProfile {
  if (typeof window === 'undefined') return 'lite';
  if (typeof window.matchMedia !== 'function') return 'lite';

  return getMotionProfile({
    reducedMotion: window.matchMedia('(prefers-reduced-motion: reduce)').matches,
    coarsePointer: window.matchMedia('(pointer: coarse)').matches,
    saveData: Boolean((window.navigator as NavigatorWithConnection).connection?.saveData),
    viewportWidth: window.innerWidth,
  });
}

export function useMotionProfile() {
  const [profile, setProfile] = useState<MotionProfile>(() => readMotionProfile());

  useEffect(() => {
    if (typeof window.matchMedia !== 'function') {
      setProfile('lite');
      return;
    }

    const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
    const coarsePointer = window.matchMedia('(pointer: coarse)');
    const connection = (window.navigator as NavigatorWithConnection).connection;
    const update = () => setProfile(readMotionProfile());

    window.addEventListener('resize', update);
    reducedMotion.addEventListener?.('change', update);
    coarsePointer.addEventListener?.('change', update);
    connection?.addEventListener?.('change', update);

    return () => {
      window.removeEventListener('resize', update);
      reducedMotion.removeEventListener?.('change', update);
      coarsePointer.removeEventListener?.('change', update);
      connection?.removeEventListener?.('change', update);
    };
  }, []);

  useEffect(() => {
    document.documentElement.dataset.motion = profile;
    return () => {
      delete document.documentElement.dataset.motion;
    };
  }, [profile]);

  return profile;
}
