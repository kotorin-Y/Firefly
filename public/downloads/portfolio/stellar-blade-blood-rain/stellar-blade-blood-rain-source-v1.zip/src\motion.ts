export type MotionProfile = 'full' | 'balanced' | 'lite';

export type MotionEnvironment = {
  reducedMotion: boolean;
  saveData: boolean;
  coarsePointer: boolean;
  viewportWidth: number;
};

export const transitionDuration: Record<MotionProfile, number> = {
  full: 520,
  balanced: 360,
  lite: 0,
};

export function getMotionProfile({
  reducedMotion,
  saveData,
  coarsePointer,
  viewportWidth,
}: MotionEnvironment): MotionProfile {
  if (reducedMotion || saveData || viewportWidth < 560) return 'lite';
  if (coarsePointer || viewportWidth < 1100) return 'balanced';
  return 'full';
}
