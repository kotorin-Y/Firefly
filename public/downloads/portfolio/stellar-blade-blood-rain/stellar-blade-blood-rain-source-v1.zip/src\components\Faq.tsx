import { Minus, Plus } from 'lucide-react';
import { useState } from 'react';
import type { Messages } from '../types';

export function Faq({ messages }: { messages: Messages }) {
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  return (
    <div className="faq-list">
      {messages.faq.items.map((item, index) => {
        const open = openIndex === index;
        return (
          <article className={`faq-item ${open ? 'is-open' : ''}`} key={item.question}>
            <h3>
              <button
                type="button"
                aria-label={item.question}
                aria-expanded={open}
                onClick={() => setOpenIndex(open ? null : index)}
              >
                <span>{String(index + 1).padStart(2, '0')}</span>
                <strong>{item.question}</strong>
                {open ? <Minus aria-hidden="true" /> : <Plus aria-hidden="true" />}
              </button>
            </h3>
            {open && <p>{item.answer}</p>}
          </article>
        );
      })}
    </div>
  );
}
