import type { MotionProfile } from '../motion';
import { OfficialLogo } from './OfficialLogo';

export type TransitionState = {
  kind: 'section' | 'language';
  label: string;
} | null;

type TransitionOverlayProps = {
  state: TransitionState;
  profile: MotionProfile;
};

export function TransitionOverlay({ state, profile }: TransitionOverlayProps) {
  if (!state || profile === 'lite') return null;

  return (
    <div
      className={`transition-overlay is-${state.kind} is-${profile}`}
      role="status"
      aria-label={`Loading ${state.label}`}
      aria-live="polite"
    >
      <div className="transition-noise" aria-hidden="true" />
      <div className="transition-scan" aria-hidden="true" />
      <div className="transition-copy">
        <OfficialLogo className="transition-logo" decorative />
        <span>{state.kind === 'language' ? 'LOCALIZATION PACKAGE' : 'MISSION SECTOR'}</span>
        <strong>{state.label}</strong>
        <small>{state.kind === 'language' ? 'LOADED' : 'COORDINATES LOCKED'}</small>
      </div>
    </div>
  );
}
