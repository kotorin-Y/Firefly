import { ExternalLink, X } from 'lucide-react';
import { sourceLinks } from '../content';
import type { Messages } from '../types';
import { useEscapeClose } from './useEscapeClose';

type VideoModalProps = {
  open: boolean;
  messages: Messages;
  onClose: () => void;
};

export function VideoModal({ open, messages, onClose }: VideoModalProps) {
  useEscapeClose(open, onClose);
  if (!open) return null;

  return (
    <div className="modal-backdrop" onMouseDown={(event) => event.target === event.currentTarget && onClose()}>
      <section
        className="video-modal"
        role="dialog"
        aria-modal="true"
        aria-label={messages.hero.playTrailer}
      >
        <div className="modal-header">
          <div>
            <span className="section-code">OFFICIAL REVEAL // 03:30</span>
            <strong>{messages.hero.playTrailer}</strong>
          </div>
          <button className="icon-button" type="button" onClick={onClose} aria-label={messages.common.close}>
            <X aria-hidden="true" />
          </button>
        </div>
        <div className="video-frame">
          <iframe
            title={messages.common.trailerFrame}
            src="https://www.youtube-nocookie.com/embed/zhdh_LspRHk?rel=0"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowFullScreen
          />
        </div>
        <a
          className="text-link"
          href={sourceLinks.announcementTrailer}
          target="_blank"
          rel="noopener noreferrer"
        >
          {messages.common.watchOnYoutube}
          <ExternalLink size={14} aria-hidden="true" />
        </a>
      </section>
    </div>
  );
}
