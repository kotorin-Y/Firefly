import { ArrowUpRight, Crosshair, Eye, ScanLine } from 'lucide-react';
import { assetUrl } from '../assetUrl';
import { sourceLinks } from '../content';
import type { Messages } from '../types';
import { Faq } from './Faq';
import { Gallery } from './Gallery';

type SectionsProps = {
  messages: Messages;
  onOpenProfile: () => void;
  galleryOpen: boolean;
  onOpenGallery: () => void;
  onCloseGallery: () => void;
};

export function Sections({
  messages,
  onOpenProfile,
  galleryOpen,
  onOpenGallery,
  onCloseGallery,
}: SectionsProps) {
  const facts = [
    [messages.reveal.dateLabel, messages.reveal.dateValue],
    [messages.reveal.stageLabel, messages.reveal.stageValue],
    [messages.reveal.protagonistLabel, messages.reveal.protagonistValue],
    [messages.reveal.publisherLabel, messages.reveal.publisherValue],
  ];

  const intel = [
    [messages.intel.platformLabel, messages.intel.platformValue, 'unknown'],
    [messages.intel.releaseLabel, messages.intel.releaseValue, 'unknown'],
    [messages.intel.preorderLabel, messages.intel.preorderValue, 'unknown'],
    [messages.intel.developerLabel, messages.intel.developerValue, 'confirmed'],
    [messages.intel.publisherLabel, messages.intel.publisherValue, 'confirmed'],
    [messages.intel.updatedLabel, messages.intel.updatedValue, 'date'],
  ];

  return (
    <main>
      <section className="section reveal-section" id="reveal" aria-labelledby="reveal-title" data-reveal>
        <div className="section-heading">
          <p className="section-code">{messages.reveal.overline}</p>
          <span className="status-chip">{messages.common.official}</span>
        </div>
        <div className="reveal-layout">
          <div>
            <h2 id="reveal-title">{messages.reveal.title}</h2>
            <p className="section-lead">{messages.reveal.body}</p>
            <a
              className="text-link"
              href={sourceLinks.shiftUpNews}
              target="_blank"
              rel="noopener noreferrer"
            >
              {messages.reveal.openNews}
              <ArrowUpRight size={15} aria-hidden="true" />
            </a>
          </div>
          <dl className="fact-grid">
            {facts.map(([label, value], index) => (
              <div key={label}>
                <dt>{String(index + 1).padStart(2, '0')} / {label}</dt>
                <dd>{value}</dd>
              </div>
            ))}
          </dl>
        </div>
      </section>

      <section className="section evie-section" id="evie" aria-labelledby="evie-title" data-reveal>
        <div className="evie-visual">
          <img
            src={assetUrl('reveal-evie.jpg')}
            alt={messages.media.items[1].alt}
            loading="lazy"
            decoding="async"
          />
          <div className="target-ring" aria-hidden="true" />
          <span className="visual-label">SUBJECT // EVIE</span>
        </div>
        <div className="evie-copy">
          <p className="section-code">{messages.evie.overline}</p>
          <h2 id="evie-title">{messages.evie.title}</h2>
          <p className="section-lead">{messages.evie.lead}</p>
          <button className="button button-primary" type="button" onClick={onOpenProfile}>
            <ScanLine size={17} aria-hidden="true" />
            {messages.evie.openProfile}
          </button>
        </div>
      </section>

      <section className="section world-section" id="world" aria-labelledby="world-title" data-reveal>
        <div className="world-image" aria-hidden="true" />
        <div className="world-copy">
          <p className="section-code">{messages.world.overline}</p>
          <h2 id="world-title">{messages.world.title}</h2>
          <p>{messages.world.body}</p>
          <blockquote>{messages.world.quote}</blockquote>
          <div className="editorial-note">
            <Eye size={16} aria-hidden="true" />
            <div>
              <strong>{messages.common.editorial}</strong>
              <span>{messages.world.note}</span>
            </div>
          </div>
        </div>
      </section>

      <section className="section combat-section" id="combat" aria-labelledby="combat-title" data-reveal>
        <div className="section-heading wide-heading">
          <div>
            <p className="section-code">{messages.combat.overline}</p>
            <h2 id="combat-title">{messages.combat.title}</h2>
          </div>
          <p>{messages.combat.body}</p>
        </div>
        <div className="combat-grid">
          {messages.combat.cards.map((card, index) => (
            <article key={card.title}>
              <div className="combat-card-image" data-image={index + 1}>
                <span>{card.tag}</span>
                <Crosshair aria-hidden="true" />
              </div>
              <small>0{index + 1} / COMBAT OBSERVATION</small>
              <h3>{card.title}</h3>
              <p>{card.body}</p>
            </article>
          ))}
        </div>
      </section>

      <section className="section media-section" id="media" aria-labelledby="media-title" data-reveal>
        <div className="section-heading wide-heading">
          <div>
            <p className="section-code">{messages.media.overline}</p>
            <h2 id="media-title">{messages.media.title}</h2>
          </div>
          <p>{messages.media.body}</p>
        </div>
        <Gallery
          messages={messages}
          open={galleryOpen}
          onOpen={onOpenGallery}
          onClose={onCloseGallery}
        />
      </section>

      <section className="section intel-section" id="intel" aria-labelledby="intel-title" data-reveal>
        <div className="intel-intro">
          <p className="section-code">{messages.intel.overline}</p>
          <h2 id="intel-title">{messages.intel.title}</h2>
          <p>{messages.intel.body}</p>
        </div>
        <dl className="intel-board">
          {intel.map(([label, value, status]) => (
            <div key={label}>
              <dt>{label}</dt>
              <dd>
                <span className={`intel-dot is-${status}`} aria-hidden="true" />
                {value}
              </dd>
            </div>
          ))}
        </dl>
      </section>

      <section className="section faq-section" id="faq" aria-labelledby="faq-title" data-reveal>
        <div className="faq-heading">
          <p className="section-code">{messages.faq.overline}</p>
          <h2 id="faq-title">{messages.faq.title}</h2>
        </div>
        <Faq messages={messages} />
      </section>
    </main>
  );
}
