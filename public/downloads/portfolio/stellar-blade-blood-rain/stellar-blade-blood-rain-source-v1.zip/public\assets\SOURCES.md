# Visual asset sources

All assets in this folder are used only in this non-commercial portfolio concept.

| Local file | Source | Notes |
|---|---|---|
| `hero-concept.jpg` | OpenAI built-in image generation, 2026-06-22 | Original concept visual; no text or official character identity. Prompt requested an original rain-soaked industrial megacity, a short-haired operative from behind on the right third, and dark negative space for web copy. |
| `reveal-hero.jpg` | https://img.youtube.com/vi/zhdh_LspRHk/maxresdefault.jpg | Official YouTube announcement trailer thumbnail |
| `official-title-lockup.jpg` | Cropped from `reveal-hero.jpg` | Official title treatment visible in the announcement trailer thumbnail; crop contains no generated lettering. |
| `reveal-evie.jpg` | https://shiftup.co.kr/admin/data/bbs/news/M2606090513526_1.jpg | Image embedded in SHIFT UP's official announcement |
| `media-frame-1.jpg` | https://img.youtube.com/vi/zhdh_LspRHk/maxresdefault.jpg | Official YouTube thumbnail |
| `media-frame-2.jpg` | https://img.youtube.com/vi/zhdh_LspRHk/0.jpg | Official YouTube video thumbnail |
| `media-frame-3.jpg` | https://img.youtube.com/vi/zhdh_LspRHk/hq1.jpg | Official YouTube generated video frame thumbnail |
| `media-frame-4.jpg` | https://img.youtube.com/vi/zhdh_LspRHk/hq2.jpg | Official YouTube generated video frame thumbnail |

Retrieved on 2026-06-22.

Stellar Blade and related marks and imagery belong to their respective rights holders.
