import { describe, expect, it } from 'vitest';
import { getMotionProfile, transitionDuration } from './motion';

describe('motion performance profile', () => {
  it('uses lite motion for reduced-motion and save-data users', () => {
    expect(
      getMotionProfile({
        reducedMotion: true,
        saveData: false,
        coarsePointer: false,
        viewportWidth: 1440,
      }),
    ).toBe('lite');

    expect(
      getMotionProfile({
        reducedMotion: false,
        saveData: true,
        coarsePointer: false,
        viewportWidth: 1440,
      }),
    ).toBe('lite');
  });

  it('uses lite motion on small phones and balanced motion on touch tablets', () => {
    expect(
      getMotionProfile({
        reducedMotion: false,
        saveData: false,
        coarsePointer: true,
        viewportWidth: 375,
      }),
    ).toBe('lite');

    expect(
      getMotionProfile({
        reducedMotion: false,
        saveData: false,
        coarsePointer: true,
        viewportWidth: 768,
      }),
    ).toBe('balanced');
  });

  it('uses full motion only for larger fine-pointer screens', () => {
    expect(
      getMotionProfile({
        reducedMotion: false,
        saveData: false,
        coarsePointer: false,
        viewportWidth: 1440,
      }),
    ).toBe('full');
  });

  it('keeps transition feedback short and disables delay for lite mode', () => {
    expect(transitionDuration.full).toBeLessThanOrEqual(600);
    expect(transitionDuration.balanced).toBeLessThan(transitionDuration.full);
    expect(transitionDuration.lite).toBe(0);
  });
});
