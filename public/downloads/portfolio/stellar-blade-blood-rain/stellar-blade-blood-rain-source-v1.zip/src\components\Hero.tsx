import { ArrowDown, Play } from 'lucide-react';
import type { Messages } from '../types';
import { OfficialLogo } from './OfficialLogo';

type HeroProps = {
  messages: Messages;
  onPlay: () => void;
};

export function Hero({ messages, onPlay }: HeroProps) {
  return (
    <section className="hero" id="overview" aria-labelledby="hero-title" data-reveal>
      <div className="hero-media" aria-hidden="true">
        <div className="hero-video-fallback" />
        <div className="rain-layer rain-layer-one" />
        <div className="rain-layer rain-layer-two" />
        <div className="signal-grid" />
      </div>
      <div className="hero-shade" aria-hidden="true" />

      <div className="hero-content">
        <div className="hero-status">
          <span className="status-pulse" />
          {messages.hero.status}
        </div>
        <OfficialLogo className="hero-official-logo" decorative />
        <p className="section-code">{messages.hero.overline}</p>
        <h1 id="hero-title">
          <span>BLOOD</span>
          <em>RAIN</em>
        </h1>
        <p className="hero-lead">{messages.hero.lead}</p>
        <div className="hero-actions">
          <button className="button button-primary" type="button" onClick={onPlay}>
            <Play size={17} fill="currentColor" aria-hidden="true" />
            {messages.hero.playTrailer}
          </button>
          <a className="button button-secondary" href="#intel">
            {messages.hero.openIntel}
          </a>
        </div>
      </div>

      <a className="scroll-cue" href="#reveal" aria-label={messages.hero.scroll}>
        <span>{messages.hero.scroll}</span>
        <ArrowDown size={16} aria-hidden="true" />
      </a>
      <div className="hero-coordinate" aria-hidden="true">
        <span>37°33′59″N</span>
        <span>126°58′41″E</span>
      </div>
    </section>
  );
}
