import { fireEvent, render, screen } from '@testing-library/react';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import App from '../App';

describe('skip link regressions', () => {
  beforeEach(() => {
    window.localStorage.clear();
    Object.defineProperty(window, 'matchMedia', {
      configurable: true,
      value: vi.fn().mockImplementation((query: string) => ({
        matches: query.includes('pointer: fine'),
        media: query,
        addEventListener: vi.fn(),
        removeEventListener: vi.fn(),
      })),
    });
    Object.defineProperty(window, 'innerWidth', { configurable: true, value: 1440 });
  });

  it('bypasses the cinematic overlay for immediate keyboard navigation', () => {
    render(<App />);

    fireEvent.click(screen.getByRole('link', { name: 'Skip to content' }));

    expect(screen.queryByRole('status')).not.toBeInTheDocument();
  });
});
