type OfficialLogoProps = {
  className?: string;
  decorative?: boolean;
};

export function OfficialLogo({
  className = '',
  decorative = false,
}: OfficialLogoProps) {
  return (
    <img
      className={`official-logo ${className}`.trim()}
      src={assetUrl('official-title-lockup.jpg')}
      alt={decorative ? '' : 'Stellar Blade: Blood Rain'}
      aria-hidden={decorative || undefined}
      decoding="async"
    />
  );
}
import { assetUrl } from '../assetUrl';
