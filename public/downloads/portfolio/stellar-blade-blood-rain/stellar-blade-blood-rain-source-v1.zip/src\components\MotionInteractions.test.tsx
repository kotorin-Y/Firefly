import { act, fireEvent, render, screen } from '@testing-library/react';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import App from '../App';

describe('mission transition interactions', () => {
  beforeEach(() => {
    window.localStorage.clear();
    Object.defineProperty(window, 'matchMedia', {
      configurable: true,
      value: vi.fn().mockImplementation((query: string) => ({
        matches: query.includes('prefers-reduced-motion') ? false : query.includes('pointer: fine'),
        media: query,
        addEventListener: vi.fn(),
        removeEventListener: vi.fn(),
      })),
    });
    Object.defineProperty(window, 'innerWidth', { configurable: true, value: 1440 });
    Element.prototype.scrollIntoView = vi.fn();
  });

  it('shows a mission transition before navigating to a section', async () => {
    vi.useFakeTimers();
    render(<App />);

    fireEvent.click(screen.getByRole('link', { name: 'Combat' }));

    expect(screen.getByRole('status', { name: 'Loading Combat' })).toBeInTheDocument();
    expect(document.documentElement.dataset.motion).toBe('full');

    await act(async () => {
      vi.runAllTimers();
    });

    expect(Element.prototype.scrollIntoView).toHaveBeenCalled();
    expect(screen.queryByRole('status', { name: 'Loading Combat' })).not.toBeInTheDocument();
    vi.useRealTimers();
  });

  it('shows a localization transition and switches language', async () => {
    vi.useFakeTimers();
    render(<App />);

    fireEvent.click(screen.getByRole('button', { name: 'English' }));
    fireEvent.click(screen.getByRole('menuitem', { name: '简体中文' }));

    expect(screen.getByRole('status', { name: 'Loading 简体中文' })).toBeInTheDocument();

    await act(async () => {
      vi.runAllTimers();
    });

    expect(
      screen.getByRole('heading', { name: '下一篇章，正式进入任务序列。' }),
    ).toBeInTheDocument();
    expect(window.localStorage.getItem('blood-rain-language')).toBe('zh-CN');
    vi.useRealTimers();
  });
});
