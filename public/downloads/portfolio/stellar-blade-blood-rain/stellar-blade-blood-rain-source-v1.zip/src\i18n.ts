import { content } from './content';
import { languageCodes, type Language } from './types';

export const supportedLanguages: Language[] = [...languageCodes];

export function resolveLanguage(input?: string | null): Language {
  if (!input) return 'en';
  const normalized = input.toLowerCase();

  if (normalized.startsWith('zh-hk') || normalized.startsWith('zh-tw') || normalized.startsWith('zh-mo')) {
    return 'zh-TW';
  }
  if (normalized.startsWith('zh')) return 'zh-CN';

  const exact = supportedLanguages.find((language) => language.toLowerCase() === normalized);
  if (exact) return exact;

  const base = normalized.split('-')[0];
  return supportedLanguages.find((language) => language.toLowerCase() === base) ?? 'en';
}

export function getMessages(language: Language) {
  return content[language] ?? content.en;
}

export function readPreferredLanguage(): Language {
  if (typeof window === 'undefined') return 'en';
  const stored = window.localStorage.getItem('blood-rain-language');
  return resolveLanguage(stored || window.navigator.language);
}

export function persistLanguage(language: Language) {
  if (typeof window === 'undefined') return;
  window.localStorage.setItem('blood-rain-language', language);
  document.documentElement.lang = language;
}
