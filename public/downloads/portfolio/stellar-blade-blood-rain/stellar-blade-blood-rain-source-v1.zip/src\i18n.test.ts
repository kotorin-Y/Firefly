import { describe, expect, it } from 'vitest';
import { content, officialFacts, sourceLinks } from './content';
import { getMessages, resolveLanguage, supportedLanguages } from './i18n';

describe('multilingual content', () => {
  it('supports all seven requested languages', () => {
    expect(supportedLanguages).toEqual([
      'en',
      'fr',
      'zh-CN',
      'zh-TW',
      'ja',
      'ko',
      'es',
    ]);
  });

  it('falls back unsupported browser languages to English', () => {
    expect(resolveLanguage('de-DE')).toBe('en');
    expect(resolveLanguage('fr-CA')).toBe('fr');
    expect(resolveLanguage('zh-HK')).toBe('zh-TW');
    expect(resolveLanguage('zh-SG')).toBe('zh-CN');
  });

  it.each(supportedLanguages)('%s has complete navigation and critical actions', (language) => {
    const messages = getMessages(language);

    expect(Object.keys(messages.nav)).toEqual([
      'overview',
      'evie',
      'world',
      'combat',
      'media',
      'intel',
      'faq',
    ]);
    expect(messages.hero.playTrailer.length).toBeGreaterThan(1);
    expect(messages.hero.openIntel.length).toBeGreaterThan(1);
    expect(messages.common.close.length).toBeGreaterThan(0);
    expect(messages.faq.items.length).toBeGreaterThanOrEqual(5);
  });

  it('keeps unannounced release details explicitly unknown', () => {
    expect(officialFacts.platforms).toBe('unannounced');
    expect(officialFacts.releaseDate).toBe('unannounced');
    expect(officialFacts.preorder).toBe('unavailable');
    expect(content.en.intel.platformValue).toMatch(/not announced/i);
    expect(content['zh-CN'].intel.releaseValue).toContain('尚未公布');
  });

  it('uses official source links for the announcement and original game', () => {
    expect(sourceLinks.shiftUpNews).toContain('shiftup.co.kr');
    expect(sourceLinks.announcementTrailer).toContain('youtube.com');
    expect(sourceLinks.stellarBlade).toContain('playstation.com');
  });
});
