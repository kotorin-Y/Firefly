import { ArrowLeft, ArrowRight, Maximize2, X } from 'lucide-react';
import { useState } from 'react';
import { assetUrl } from '../assetUrl';
import type { Messages } from '../types';
import { useEscapeClose } from './useEscapeClose';

const images = [
  assetUrl('media-frame-1.jpg'),
  assetUrl('media-frame-2.jpg'),
  assetUrl('media-frame-3.jpg'),
  assetUrl('media-frame-4.jpg'),
];

type GalleryProps = {
  messages: Messages;
  open: boolean;
  onOpen: () => void;
  onClose: () => void;
};

export function Gallery({ messages, open, onOpen, onClose }: GalleryProps) {
  const [activeIndex, setActiveIndex] = useState(0);
  useEscapeClose(open, onClose);

  const showPrevious = () => setActiveIndex((index) => (index - 1 + images.length) % images.length);
  const showNext = () => setActiveIndex((index) => (index + 1) % images.length);
  const activeCopy = messages.media.items[activeIndex];

  return (
    <>
      <div className="gallery-grid">
        {images.map((image, index) => (
          <button
            className={`gallery-card gallery-card-${index + 1}`}
            key={image}
            type="button"
            onClick={() => {
              setActiveIndex(index);
              onOpen();
            }}
          >
            <img
              src={image}
              alt={messages.media.items[index].alt}
              loading="lazy"
              decoding="async"
            />
            <span>
              <small>{messages.media.items[index].caption}</small>
              <strong>{messages.media.items[index].title}</strong>
            </span>
            <Maximize2 size={18} aria-hidden="true" />
          </button>
        ))}
      </div>
      <button className="button button-secondary gallery-open" type="button" onClick={onOpen}>
        <Maximize2 size={16} aria-hidden="true" />
        {messages.media.openGallery}
      </button>

      {open && (
        <div className="modal-backdrop" onMouseDown={(event) => event.target === event.currentTarget && onClose()}>
          <section
            className="lightbox"
            role="dialog"
            aria-modal="true"
            aria-label={messages.media.title}
          >
            <div className="lightbox-image">
              <img src={images[activeIndex]} alt={activeCopy.alt} />
              <span className="lightbox-counter">
                {String(activeIndex + 1).padStart(2, '0')} / {String(images.length).padStart(2, '0')}
              </span>
            </div>
            <div className="lightbox-copy">
              <button className="icon-button lightbox-close" type="button" onClick={onClose} aria-label={messages.common.close}>
                <X aria-hidden="true" />
              </button>
              <p className="section-code">{activeCopy.caption}</p>
              <h2>{activeCopy.title}</h2>
              <div className="lightbox-controls">
                <button type="button" onClick={showPrevious} aria-label={messages.common.previous}>
                  <ArrowLeft aria-hidden="true" />
                  <span>{messages.common.previous}</span>
                </button>
                <button type="button" onClick={showNext} aria-label={messages.common.next}>
                  <span>{messages.common.next}</span>
                  <ArrowRight aria-hidden="true" />
                </button>
              </div>
            </div>
          </section>
        </div>
      )}
    </>
  );
}
