import { ShieldAlert, X } from 'lucide-react';
import type { Messages } from '../types';
import { useEscapeClose } from './useEscapeClose';

type CharacterDrawerProps = {
  open: boolean;
  messages: Messages;
  onClose: () => void;
};

export function CharacterDrawer({ open, messages, onClose }: CharacterDrawerProps) {
  useEscapeClose(open, onClose);
  if (!open) return null;

  const fields = [
    [messages.evie.roleLabel, messages.evie.roleValue],
    [messages.evie.timelineLabel, messages.evie.timelineValue],
    [messages.evie.combatLabel, messages.evie.combatValue],
    [messages.evie.classifiedLabel, messages.evie.classifiedValue],
  ];

  return (
    <div className="drawer-backdrop" onMouseDown={(event) => event.target === event.currentTarget && onClose()}>
      <aside
        className="character-drawer"
        role="dialog"
        aria-modal="true"
        aria-label={messages.evie.profileTitle}
      >
        <div className="drawer-portrait">
          <div className="portrait-scan" />
          <span>SUBJECT // EVIE</span>
        </div>
        <div className="drawer-content">
          <button className="icon-button drawer-close" type="button" onClick={onClose} aria-label={messages.common.close}>
            <X aria-hidden="true" />
          </button>
          <p className="section-code">{messages.common.official}</p>
          <h2>{messages.evie.profileTitle}</h2>
          <p>{messages.evie.profileBody}</p>
          <dl className="profile-grid">
            {fields.map(([label, value], index) => (
              <div key={label} className={index === fields.length - 1 ? 'is-classified' : ''}>
                <dt>{label}</dt>
                <dd>{value}</dd>
              </div>
            ))}
          </dl>
          <div className="classified-stamp">
            <ShieldAlert size={17} aria-hidden="true" />
            {messages.common.unknown}
          </div>
        </div>
      </aside>
    </div>
  );
}
