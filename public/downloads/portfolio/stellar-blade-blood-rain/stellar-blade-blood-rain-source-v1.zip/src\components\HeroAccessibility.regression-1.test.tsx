import { render, screen } from '@testing-library/react';
import { beforeEach, describe, expect, it } from 'vitest';
import App from '../App';

describe('hero accessibility regressions', () => {
  beforeEach(() => {
    window.localStorage.clear();
  });

  // Regression: ISSUE-003 — the mobile scroll cue lost its accessible name when text was hidden
  // Found by /qa on 2026-06-22
  // Report: .gstack/qa-reports/qa-report-localhost-2026-06-22.md
  it('keeps a localized accessible name on the reveal anchor', () => {
    render(<App />);

    expect(screen.getByRole('link', { name: 'Descend into the rain' })).toHaveAttribute(
      'href',
      '#reveal',
    );
  });
});
