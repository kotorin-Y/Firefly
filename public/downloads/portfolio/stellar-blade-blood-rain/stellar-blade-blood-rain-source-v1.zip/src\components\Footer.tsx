import { ArrowUp, ExternalLink } from 'lucide-react';
import { sourceLinks } from '../content';
import type { Messages } from '../types';
import { OfficialLogo } from './OfficialLogo';

export function Footer({ messages }: { messages: Messages }) {
  const links = [
    [messages.footer.shiftUp, sourceLinks.shiftUpNews],
    [messages.footer.trailer, sourceLinks.announcementTrailer],
    [messages.footer.seriesPage, sourceLinks.stellarBlade],
  ];

  return (
    <footer className="site-footer">
      <div className="footer-mark">
        <OfficialLogo className="footer-official-logo" decorative />
        <small>UNOFFICIAL WEB PRODUCTION CONCEPT</small>
      </div>
      <div className="footer-sources">
        <p className="section-code">{messages.footer.sourcesTitle}</p>
        {links.map(([label, href]) => (
          <a key={href} href={href} target="_blank" rel="noopener noreferrer">
            {label}
            <ExternalLink size={13} aria-hidden="true" />
          </a>
        ))}
      </div>
      <div className="footer-legal">
        <p>{messages.footer.disclaimer}</p>
        <p>{messages.footer.rights}</p>
        <a href="#top">
          {messages.footer.backToTop}
          <ArrowUp size={14} aria-hidden="true" />
        </a>
      </div>
    </footer>
  );
}
