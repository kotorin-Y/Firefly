import { type MouseEvent, useCallback, useEffect, useRef, useState } from 'react';
import { CharacterDrawer } from './components/CharacterDrawer';
import { Footer } from './components/Footer';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { Sections } from './components/Sections';
import { VideoModal } from './components/VideoModal';
import { TransitionOverlay, type TransitionState } from './components/TransitionOverlay';
import { useMotionProfile } from './hooks/useMotionProfile';
import { useSectionReveal } from './hooks/useSectionReveal';
import { getMessages, persistLanguage, readPreferredLanguage } from './i18n';
import { transitionDuration } from './motion';
import type { Language } from './types';

export default function App() {
  const [language, setLanguage] = useState<Language>(() => readPreferredLanguage());
  const [trailerOpen, setTrailerOpen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);
  const [galleryOpen, setGalleryOpen] = useState(false);
  const [transition, setTransition] = useState<TransitionState>(null);
  const transitionTimers = useRef<number[]>([]);
  const motionProfile = useMotionProfile();
  const messages = getMessages(language);
  useSectionReveal(motionProfile);

  useEffect(() => {
    persistLanguage(language);
  }, [language]);

  useEffect(
    () => () => {
      transitionTimers.current.forEach((timer) => window.clearTimeout(timer));
    },
    [],
  );

  const closeTrailer = useCallback(() => setTrailerOpen(false), []);
  const closeProfile = useCallback(() => setProfileOpen(false), []);
  const closeGallery = useCallback(() => setGalleryOpen(false), []);

  const runTransition = useCallback(
    (state: NonNullable<TransitionState>, action: () => void) => {
      transitionTimers.current.forEach((timer) => window.clearTimeout(timer));
      transitionTimers.current = [];

      const duration = transitionDuration[motionProfile];
      if (duration === 0) {
        action();
        setTransition(null);
        return;
      }

      setTransition(state);
      const actionTimer = window.setTimeout(action, Math.round(duration * 0.52));
      const closeTimer = window.setTimeout(() => setTransition(null), duration);
      transitionTimers.current.push(actionTimer, closeTimer);
    },
    [motionProfile],
  );

  const requestLanguageChange = useCallback(
    (nextLanguage: Language, label: string) => {
      runTransition({ kind: 'language', label }, () => setLanguage(nextLanguage));
    },
    [runTransition],
  );

  const handleInternalNavigation = useCallback(
    (event: MouseEvent<HTMLDivElement>) => {
      const target = event.target as HTMLElement;
      const anchor = target.closest<HTMLAnchorElement>('a[href^="#"]');
      if (!anchor) return;
      if (anchor.classList.contains('skip-link')) return;

      const targetId = anchor.getAttribute('href')?.slice(1);
      if (!targetId) return;
      const destination = document.getElementById(targetId);
      if (!destination) return;

      event.preventDefault();
      const label = anchor.textContent?.trim() || targetId.toUpperCase();
      runTransition({ kind: 'section', label }, () => {
        destination.scrollIntoView({
          behavior: motionProfile === 'lite' ? 'auto' : 'smooth',
          block: 'start',
        });
        window.history.replaceState(null, '', `#${targetId}`);
      });
    },
    [motionProfile, runTransition],
  );

  return (
    <div className="app-shell" id="top" onClickCapture={handleInternalNavigation}>
      <a className="skip-link" href="#overview">
        {messages.common.skipToContent}
      </a>
      <Header
        language={language}
        messages={messages}
        onLanguageChange={requestLanguageChange}
      />
      <Hero messages={messages} onPlay={() => setTrailerOpen(true)} />
      <Sections
        messages={messages}
        onOpenProfile={() => setProfileOpen(true)}
        galleryOpen={galleryOpen}
        onOpenGallery={() => setGalleryOpen(true)}
        onCloseGallery={closeGallery}
      />
      <Footer messages={messages} />
      <VideoModal open={trailerOpen} messages={messages} onClose={closeTrailer} />
      <CharacterDrawer open={profileOpen} messages={messages} onClose={closeProfile} />
      <TransitionOverlay state={transition} profile={motionProfile} />
    </div>
  );
}
