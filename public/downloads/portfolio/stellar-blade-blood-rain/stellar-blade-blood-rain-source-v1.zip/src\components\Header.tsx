import { ChevronDown, Menu, X } from 'lucide-react';
import { useState } from 'react';
import { content } from '../content';
import { supportedLanguages } from '../i18n';
import type { Language, Messages } from '../types';
import { OfficialLogo } from './OfficialLogo';

type HeaderProps = {
  language: Language;
  messages: Messages;
  onLanguageChange: (language: Language, label: string) => void;
};

const anchors: Array<keyof Messages['nav']> = [
  'overview',
  'evie',
  'world',
  'combat',
  'media',
  'intel',
  'faq',
];

export function Header({ language, messages, onLanguageChange }: HeaderProps) {
  const [languageOpen, setLanguageOpen] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  const selectLanguage = (nextLanguage: Language) => {
    onLanguageChange(nextLanguage, content[nextLanguage].languageName);
    setLanguageOpen(false);
    setMobileOpen(false);
  };

  return (
    <header className="site-header">
      <a className="wordmark" href="#top" aria-label="Stellar Blade Blood Rain">
        <OfficialLogo />
      </a>

      <nav
        className={`primary-nav ${mobileOpen ? 'is-open' : ''}`}
        aria-label={messages.common.primaryNavigation}
      >
        {anchors.map((anchor) => (
          <a key={anchor} href={`#${anchor}`} onClick={() => setMobileOpen(false)}>
            {messages.nav[anchor]}
          </a>
        ))}
      </nav>

      <div className="header-actions">
        <div className="language-control">
          <button
            className="language-trigger"
            type="button"
            aria-haspopup="menu"
            aria-expanded={languageOpen}
            onClick={() => setLanguageOpen((value) => !value)}
          >
            <span>{content[language].languageName}</span>
            <ChevronDown size={14} aria-hidden="true" />
          </button>
          {languageOpen && (
            <div className="language-menu" role="menu">
              {supportedLanguages.map((code) => (
                <button
                  key={code}
                  type="button"
                  role="menuitem"
                  aria-label={content[code].languageName}
                  aria-current={code === language ? 'true' : undefined}
                  onClick={() => selectLanguage(code)}
                >
                  <span>{content[code].languageName}</span>
                  <small>{code}</small>
                </button>
              ))}
            </div>
          )}
        </div>

        <button
          className="mobile-menu-trigger"
          type="button"
          aria-label={mobileOpen ? messages.common.close : messages.common.openMenu}
          aria-expanded={mobileOpen}
          onClick={() => setMobileOpen((value) => !value)}
        >
          {mobileOpen ? <X aria-hidden="true" /> : <Menu aria-hidden="true" />}
        </button>
      </div>
    </header>
  );
}
