import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { beforeEach, describe, expect, it } from 'vitest';
import App from '../App';

describe('interactive content', () => {
  beforeEach(() => {
    window.localStorage.clear();
  });

  it('opens and closes the announcement trailer dialog', async () => {
    const user = userEvent.setup();
    render(<App />);

    await user.click(screen.getByRole('button', { name: 'Play announcement trailer' }));
    expect(screen.getByRole('dialog', { name: 'Play announcement trailer' })).toBeInTheDocument();
    expect(screen.getByTitle('Stellar Blade: BLOOD RAIN announcement trailer')).toBeInTheDocument();

    await user.click(screen.getByRole('button', { name: 'Close' }));
    expect(screen.queryByRole('dialog')).not.toBeInTheDocument();
  });

  it('opens Evie profile and closes it with Escape', async () => {
    const user = userEvent.setup();
    render(<App />);

    await user.click(screen.getByRole('button', { name: 'Open classified profile' }));
    expect(screen.getByRole('dialog', { name: 'Evie // mission profile' })).toBeInTheDocument();
    expect(screen.getByText('New protagonist')).toBeInTheDocument();

    await user.keyboard('{Escape}');
    expect(screen.queryByRole('dialog', { name: 'Evie // mission profile' })).not.toBeInTheDocument();
  });

  it('opens the media gallery and advances to the next frame', async () => {
    const user = userEvent.setup();
    render(<App />);

    await user.click(screen.getByRole('button', { name: 'Open full gallery' }));
    expect(screen.getByRole('dialog', { name: 'Frames from the downpour.' })).toBeInTheDocument();
    expect(screen.getByRole('heading', { name: 'Crimson signal' })).toBeInTheDocument();

    await user.click(screen.getByRole('button', { name: 'Next' }));
    expect(screen.getByRole('heading', { name: 'Evie enters' })).toBeInTheDocument();
  });

  it('expands an FAQ answer', async () => {
    const user = userEvent.setup();
    render(<App />);

    await user.click(screen.getByRole('button', { name: 'Is BLOOD RAIN a sequel?' }));
    expect(
      screen.getByText(/SHIFT UP describes it as the next chapter/i),
    ).toBeVisible();
  });
});
