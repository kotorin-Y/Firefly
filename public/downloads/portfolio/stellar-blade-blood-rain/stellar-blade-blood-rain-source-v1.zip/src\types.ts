export const languageCodes = ['en', 'fr', 'zh-CN', 'zh-TW', 'ja', 'ko', 'es'] as const;

export type Language = (typeof languageCodes)[number];

export type FaqItem = {
  question: string;
  answer: string;
};

export type CombatCard = {
  title: string;
  body: string;
  tag: string;
};

export type MediaItemCopy = {
  title: string;
  caption: string;
  alt: string;
};

export type Messages = {
  languageName: string;
  nav: {
    overview: string;
    evie: string;
    world: string;
    combat: string;
    media: string;
    intel: string;
    faq: string;
  };
  common: {
    close: string;
    openMenu: string;
    skipToContent: string;
    primaryNavigation: string;
    trailerFrame: string;
    official: string;
    editorial: string;
    source: string;
    unknown: string;
    previous: string;
    next: string;
    copyLink: string;
    copied: string;
    watchOnYoutube: string;
  };
  hero: {
    status: string;
    overline: string;
    lead: string;
    playTrailer: string;
    openIntel: string;
    scroll: string;
  };
  reveal: {
    overline: string;
    title: string;
    body: string;
    dateLabel: string;
    dateValue: string;
    stageLabel: string;
    stageValue: string;
    protagonistLabel: string;
    protagonistValue: string;
    publisherLabel: string;
    publisherValue: string;
    openNews: string;
  };
  evie: {
    overline: string;
    title: string;
    lead: string;
    openProfile: string;
    profileTitle: string;
    profileBody: string;
    roleLabel: string;
    roleValue: string;
    timelineLabel: string;
    timelineValue: string;
    combatLabel: string;
    combatValue: string;
    classifiedLabel: string;
    classifiedValue: string;
  };
  world: {
    overline: string;
    title: string;
    body: string;
    quote: string;
    note: string;
  };
  combat: {
    overline: string;
    title: string;
    body: string;
    cards: CombatCard[];
  };
  media: {
    overline: string;
    title: string;
    body: string;
    openGallery: string;
    items: MediaItemCopy[];
  };
  intel: {
    overline: string;
    title: string;
    body: string;
    platformLabel: string;
    platformValue: string;
    releaseLabel: string;
    releaseValue: string;
    preorderLabel: string;
    preorderValue: string;
    developerLabel: string;
    developerValue: string;
    publisherLabel: string;
    publisherValue: string;
    updatedLabel: string;
    updatedValue: string;
  };
  faq: {
    overline: string;
    title: string;
    items: FaqItem[];
  };
  footer: {
    disclaimer: string;
    rights: string;
    sourcesTitle: string;
    shiftUp: string;
    trailer: string;
    seriesPage: string;
    backToTop: string;
  };
};
