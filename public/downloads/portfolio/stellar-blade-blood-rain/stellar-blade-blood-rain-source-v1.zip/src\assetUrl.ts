export function assetUrl(fileName: string) {
  return `${import.meta.env.BASE_URL}assets/${fileName}`;
}
