import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { beforeEach, describe, expect, it } from 'vitest';
import App from './App';
import { sourceLinks } from './content';

describe('Blood Rain concept website', () => {
  beforeEach(() => {
    window.localStorage.clear();
  });

  it('renders the complete primary navigation and hero actions', () => {
    render(<App />);

    expect(screen.getByRole('img', { name: 'Stellar Blade: Blood Rain' })).toHaveAttribute(
      'src',
      '/assets/official-title-lockup.jpg',
    );

    for (const label of ['Overview', 'Evie', 'World', 'Combat', 'Media', 'Intel', 'FAQ']) {
      expect(screen.getByRole('link', { name: label })).toBeInTheDocument();
    }

    expect(screen.getByRole('button', { name: 'Play announcement trailer' })).toBeInTheDocument();
    expect(screen.getByRole('link', { name: 'Enter mission intel' })).toHaveAttribute('href', '#intel');
  });

  it('renders official external links with safe new-tab behavior', () => {
    render(<App />);

    const announcement = screen.getByRole('link', { name: 'Read the official announcement' });
    expect(announcement).toHaveAttribute('href', sourceLinks.shiftUpNews);
    expect(announcement).toHaveAttribute('target', '_blank');
    expect(announcement).toHaveAttribute('rel', expect.stringContaining('noopener'));
  });

  it('switches all interface content to Simplified Chinese and persists the choice', async () => {
    const user = userEvent.setup();
    render(<App />);

    await user.click(screen.getByRole('button', { name: 'English' }));
    expect(screen.getAllByRole('menuitem')).toHaveLength(7);
    await user.click(screen.getByRole('menuitem', { name: '简体中文' }));

    expect(
      screen.getByRole('heading', { name: '下一篇章，正式进入任务序列。' }),
    ).toBeInTheDocument();
    expect(screen.getByRole('button', { name: '播放公布预告' })).toBeInTheDocument();
    expect(document.documentElement.lang).toBe('zh-CN');
    expect(window.localStorage.getItem('blood-rain-language')).toBe('zh-CN');
  });
});
