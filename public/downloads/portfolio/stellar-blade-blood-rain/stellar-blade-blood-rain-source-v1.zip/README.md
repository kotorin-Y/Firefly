# Stellar Blade: BLOOD RAIN 宣发网页作品

这是一个非官方、非商业的游戏网页运营与制作作品。项目以《Stellar Blade: BLOOD RAIN》首次公布阶段为业务场景，展示从需求梳理、内容分层、页面配置、交互验收到多设备交付的完整能力。

## 项目目标

页面承担三个运营任务：

1. 在首屏快速建立“新主角 Evie、血雨都市、近距离战斗”的认知。
2. 将官方确认、尚未公布和编辑性演绎严格分层，控制玩家预期。
3. 为预告、官方公告、角色档案、媒体画廊和后续情报提供清晰的浏览路径。

这不是产品经理或泛运营方案。作品主体是“游戏宣发网页制作 / Web Producer”：接收活动需求，形成页面信息架构与原型，使用前端或页面搭建工具完成配置，核对素材和文案，推动验收上线，并对最终交付质量负责。

## 核心体验

- 官方标题锁定图、电影化首屏、雨幕与任务终端视觉。
- 区块进入动画、栏目切换过场和语言包加载动画。
- 根据屏幕、指针类型、节省流量设置和减少动态效果偏好自动降级。
- 预告弹窗、Evie 档案抽屉、媒体灯箱、FAQ 和移动端导航。
- 保留英语、法语、简体中文、繁体中文、日语、韩语和西班牙语切换能力。
- 官方事实、编辑性内容和未知信息采用不同视觉状态。
- 所有主要按钮均有可执行结果或有效外链。

## 内容运营规则

- 已确认信息只引用 SHIFT UP 公告和官方公布预告。
- 平台、发售日期、预购和未公开系统不做推测。
- 氛围文案必须标记为“编辑性演绎”。
- 每次官方信息更新时，同步检查任务情报板、FAQ、媒体素材和来源记录。
- 官方素材只用于本非商业作品展示，来源见 `public/assets/SOURCES.md`。

## 本地运行

要求 Node.js 22.12+ 和 npm 10+。项目不依赖在线字体服务，核心页面素材已本地化。

```bash
npm ci
npm run dev
```

在同一局域网内，可使用终端显示的 Network 地址从手机或平板访问。

## 检查与构建

```bash
npm run check
npm run preview
```

`npm run check` 会依次运行组件测试、交互测试、TypeScript 检查和生产构建。构建结果位于 `dist/`，可部署到任意静态 Web 服务器。

## Docker 复现

```bash
docker compose up --build
```

打开 `http://localhost:8080/`。镜像使用 Node 22 构建并由 Nginx 提供静态文件，适合 Windows、macOS 和 Linux 上的统一复现。

## 主要目录

```text
src/content.ts             七语言界面内容与官方事实
src/components/            页面、弹窗、抽屉和交互组件
src/hooks/                 动效档位与区块进入逻辑
src/motion.ts              动效策略和时长
src/styles.css             视觉系统、响应式和动效降级
public/assets/SOURCES.md   素材来源与使用边界
docs/                      需求规格、实现计划和 QA 记录
```

## 官方来源

- [SHIFT UP 官方公告](https://shiftup.co.kr/news/news.php?category=&idx=448&ptype=view)
- [官方公布预告](https://www.youtube.com/watch?v=zhdh_LspRHk)
- [PlayStation《Stellar Blade》页面](https://www.playstation.com/en-us/games/stellar-blade/)

Stellar Blade 及相关商标、图像权利归各自权利方所有。本项目与 SHIFT UP 或 Sony Interactive Entertainment 无隶属或授权关系。
