import type {
  FeedQuery,
  FeedResponse,
  ProviderStatus,
  SearchResponse
} from "../../src/shared/contracts.js";
import { dedupeContent } from "../../src/features/feed/dedupe.js";
import { interleaveProviderItems } from "../../src/features/feed/interleave.js";
import type { ContentProvider } from "./providers/provider.js";
import { createProviders } from "./providers/registry.js";
import { translationService } from "./translation-service.js";

const providers: ContentProvider[] = createProviders();

const cache = new Map<string, { response: FeedResponse; cachedAt: number }>();

export function feedCacheKey(query: FeedQuery): string {
  return JSON.stringify({
    category: query.category ?? "all",
    cursor: query.cursor ?? "1",
    limit: query.limit ?? 20
  });
}

export async function listFeed(query: FeedQuery = {}): Promise<FeedResponse> {
  const key = feedCacheKey(query);
  const cached = cache.get(key);
  if (!query.forceRefresh && cached && Date.now() - cached.cachedAt < 5 * 60_000) {
    return { ...cached.response, fromCache: true };
  }

  const selected = providers.filter((provider) =>
    !query.category ||
    query.category === "all" ||
    provider.categories.includes(query.category)
  );

  const settled = await Promise.all(selected.map(async (provider) => {
    const startedAt = Date.now();
    try {
      const items = await provider.list(query);
      return {
        items,
        status: {
          id: provider.id,
          label: provider.label,
          ok: true,
          itemCount: items.length,
          latencyMs: Date.now() - startedAt
        } satisfies ProviderStatus
      };
    } catch (error) {
      return {
        items: [],
        status: {
          id: provider.id,
          label: provider.label,
          ok: false,
          itemCount: 0,
          latencyMs: Date.now() - startedAt,
          message: error instanceof Error ? error.message : String(error)
        } satisfies ProviderStatus
      };
    }
  }));

  const limit = Math.max(1, query.limit ?? 20);
  const selectedItems = interleaveProviderItems(
    settled.map((entry) => dedupeContent(entry.items)),
    limit
  );
  const response: FeedResponse = {
    items: await translationService.translateItems(dedupeContent(selectedItems)),
    providers: settled.map((entry) => entry.status),
    refreshedAt: new Date().toISOString(),
    nextCursor: String(Number(query.cursor || "1") + 1)
  };
  cache.set(key, { response, cachedAt: Date.now() });
  return response;
}

export async function searchAll(query: string): Promise<SearchResponse> {
  const rawGroups = await Promise.all(providers.map(async (provider) => {
    try {
      return {
        provider: provider.id,
        providerLabel: provider.label,
        items: dedupeContent(await provider.search(query)).slice(0, 8)
      };
    } catch (error) {
      return {
        provider: provider.id,
        providerLabel: provider.label,
        items: [],
        error: error instanceof Error ? error.message : String(error)
      };
    }
  }));
  const flatItems = rawGroups.flatMap((group) => group.items);
  const translated = await translationService.translateItems(flatItems);
  let offset = 0;
  const groups = rawGroups.map((group) => {
    const items = translated.slice(offset, offset + group.items.length);
    offset += group.items.length;
    return { ...group, items };
  });
  return { query, groups, searchedAt: new Date().toISOString() };
}
