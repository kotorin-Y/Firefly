import { describe, expect, it } from "vitest";
import { feedCacheKey } from "./feed-service";

describe("feedCacheKey", () => {
  it("separates category and pagination cursors", () => {
    expect(feedCacheKey({ category: "anime", cursor: "1", limit: 20 }))
      .not.toBe(feedCacheKey({ category: "game", cursor: "1", limit: 20 }));
    expect(feedCacheKey({ category: "anime", cursor: "1", limit: 20 }))
      .not.toBe(feedCacheKey({ category: "anime", cursor: "2", limit: 20 }));
  });
});
