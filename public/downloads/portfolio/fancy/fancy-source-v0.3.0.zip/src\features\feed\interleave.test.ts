import { describe, expect, it } from "vitest";
import type { ContentItem } from "../../shared/contracts";
import { interleaveProviderItems } from "./interleave";

function item(provider: string, id: string): ContentItem {
  return {
    id,
    provider,
    providerLabel: provider,
    kind: "article",
    category: "game",
    title: id,
    summary: id,
    url: `https://example.com/${id}`,
    publishedAt: "2026-06-23T00:00:00.000Z",
    tags: []
  };
}

describe("interleaveProviderItems", () => {
  it("round-robins providers and respects the requested limit", () => {
    const result = interleaveProviderItems([
      [item("a", "a1"), item("a", "a2"), item("a", "a3")],
      [item("b", "b1"), item("b", "b2")],
      [item("c", "c1")]
    ], 5);

    expect(result.map((entry) => entry.id)).toEqual(["a1", "b1", "c1", "a2", "b2"]);
  });

  it("skips empty providers without creating gaps", () => {
    expect(interleaveProviderItems([[], [item("b", "b1")]], 3))
      .toEqual([item("b", "b1")]);
  });
});
