import { describe, expect, it } from "vitest";
import { secureMediaUrl } from "./provider";

describe("secureMediaUrl", () => {
  it("upgrades protocol-relative and http media urls to https", () => {
    expect(secureMediaUrl("//i0.hdslb.com/a.jpg")).toBe("https://i0.hdslb.com/a.jpg");
    expect(secureMediaUrl("http://i0.hdslb.com/a.jpg")).toBe("https://i0.hdslb.com/a.jpg");
  });
});
