import { describe, expect, it, vi } from "vitest";
import { RemoteAuthClient } from "./remote-auth-service";

describe("RemoteAuthClient", () => {
  it("rejects an insecure public authentication endpoint", () => {
    expect(() => new RemoteAuthClient("http://auth.example.com/api"))
      .toThrow("HTTPS");
  });

  it("sends credentials to the configured server and returns a session", async () => {
    const request = vi.fn(async () => new Response(JSON.stringify({
      account: {
        id: "remote-1",
        displayName: "Fancy User",
        email: "user@example.com",
        createdAt: "2026-06-25T00:00:00.000Z"
      },
      accessToken: "token-1"
    }), { status: 200, headers: { "Content-Type": "application/json" } }));
    const client = new RemoteAuthClient("https://auth.example.com/api", request);

    const result = await client.login({ email: "user@example.com", password: "Passw0rd" });

    expect(result.accessToken).toBe("token-1");
    expect(request).toHaveBeenCalledWith(
      "https://auth.example.com/api/login",
      expect.objectContaining({ method: "POST" })
    );
  });

  it("surfaces a server error without silently creating a local account", async () => {
    const client = new RemoteAuthClient(
      "https://auth.example.com/api",
      async () => new Response(JSON.stringify({ message: "验证码无效" }), {
        status: 401,
        headers: { "Content-Type": "application/json" }
      })
    );

    await expect(client.login({ email: "user@example.com", password: "bad" }))
      .rejects.toThrow("验证码无效");
  });
});
