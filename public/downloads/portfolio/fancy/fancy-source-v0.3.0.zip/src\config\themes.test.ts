import { describe, expect, it } from "vitest";
import { DEFAULT_THEME_ID, THEMES } from "./themes";

describe("Fancy themes", () => {
  it("provides four selectable themes and keeps Fancy as default", () => {
    expect(THEMES).toHaveLength(4);
    expect(DEFAULT_THEME_ID).toBe("fancy");
    expect(THEMES[0].id).toBe(DEFAULT_THEME_ID);
  });

  it("uses exactly two declared brand colors per theme", () => {
    for (const theme of THEMES) {
      expect(theme.colors).toHaveLength(2);
      expect(new Set(theme.colors).size).toBe(2);
      expect(theme.colors.every((color) => /^#[0-9A-F]{6}$/i.test(color))).toBe(true);
    }
  });
});
