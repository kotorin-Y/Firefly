import path from "node:path";
import { fileURLToPath } from "node:url";
import {
  app,
  BrowserWindow,
  ipcMain,
  Menu,
  shell,
  WebContentsView
} from "electron";
import type {
  BrowserBounds,
  ContentItem,
  FeedQuery,
  LoginInput,
  RegistrationInput,
  UgcDraft
} from "../src/shared/contracts.js";
import { BRAND } from "../src/config/brand.js";
import { claimCheckin, normalizeCheckin } from "../src/features/checkin/checkin.js";
import { moderateDraft } from "../src/features/ugc/moderation.js";
import { listFeed, searchAll } from "./services/feed-service.js";
import { readArticle } from "./services/article-service.js";
import { localStore, type StoreKey } from "./services/local-store.js";
import {
  getAuthState,
  loginAccount,
  logoutAccount,
  registerAccount
} from "./services/account-service.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
let mainWindow: BrowserWindow | null = null;
let browserView: WebContentsView | null = null;

if (process.env.FANCY_USER_DATA_DIR) {
  app.setPath("userData", path.resolve(process.env.FANCY_USER_DATA_DIR));
}

function isHttpUrl(value: string): boolean {
  try {
    const url = new URL(value);
    return url.protocol === "https:" || url.protocol === "http:";
  } catch {
    return false;
  }
}

function ensureBrowserView(): WebContentsView {
  if (!mainWindow) throw new Error("主窗口尚未创建");
  if (!browserView) {
    browserView = new WebContentsView({
      webPreferences: {
        contextIsolation: true,
        sandbox: true,
        nodeIntegration: false
      }
    });
    browserView.webContents.setWindowOpenHandler(({ url }) => {
      if (isHttpUrl(url)) void browserView?.webContents.loadURL(url);
      return { action: "deny" };
    });
    browserView.webContents.on("will-navigate", (event, url) => {
      if (!isHttpUrl(url)) event.preventDefault();
    });
    mainWindow.contentView.addChildView(browserView);
  }
  return browserView;
}

function closeBrowserView(): void {
  if (!mainWindow || !browserView) return;
  mainWindow.contentView.removeChildView(browserView);
  browserView.webContents.close();
  browserView = null;
}

function createWindow(): void {
  mainWindow = new BrowserWindow({
    width: 1480,
    height: 960,
    minWidth: 1100,
    minHeight: 720,
    backgroundColor: "#FAF8FA",
    title: BRAND.name,
    titleBarStyle: process.platform === "darwin" ? "hiddenInset" : "default",
    webPreferences: {
      preload: path.join(__dirname, "../../electron/preload.cjs"),
      contextIsolation: true,
      sandbox: true,
      nodeIntegration: false
    }
  });

  Menu.setApplicationMenu(null);
  const devUrl = process.env.VITE_DEV_SERVER_URL;
  if (devUrl) {
    void mainWindow.loadURL(devUrl);
  } else {
    void mainWindow.loadFile(path.join(__dirname, "../../dist/index.html"));
  }
  mainWindow.on("closed", () => {
    closeBrowserView();
    mainWindow = null;
  });
}

function registerIpc(): void {
  ipcMain.handle("feed:list", (_event, query: FeedQuery) => listFeed(query));
  ipcMain.handle("feed:search", (_event, query: string) => {
    if (!query || query.trim().length > 120) throw new Error("搜索词无效");
    return searchAll(query.trim());
  });
  ipcMain.handle("article:read", (_event, item: ContentItem) => readArticle(item));
  ipcMain.handle("store:get", (_event, key: StoreKey) => localStore.get(key));
  ipcMain.handle("store:set", (_event, key: StoreKey, value: unknown) => {
    localStore.set(key, value as never);
    return localStore.get(key);
  });
  ipcMain.handle("ugc:list", () => localStore.get("ugc"));
  ipcMain.handle("ugc:create", (_event, draft: UgcDraft) => {
    const moderation = moderateDraft(draft);
    const saved: UgcDraft = {
      ...draft,
      moderation,
      status: moderation.action === "publish" ? "published" : "reviewing",
      updatedAt: new Date().toISOString()
    };
    localStore.set("ugc", [saved, ...localStore.get("ugc")]);
    return saved;
  });
  ipcMain.handle("checkin:status", () => normalizeCheckin(localStore.get("checkin")));
  ipcMain.handle("checkin:claim", () => {
    const state = claimCheckin(localStore.get("checkin"));
    localStore.set("checkin", state);
    return state;
  });
  ipcMain.handle("auth:state", () => getAuthState());
  ipcMain.handle("auth:register", (_event, input: RegistrationInput) => registerAccount(input));
  ipcMain.handle("auth:login", (_event, input: LoginInput) => loginAccount(input));
  ipcMain.handle("auth:logout", () => logoutAccount());
  ipcMain.handle("browser:open", async (_event, url: string, bounds: BrowserBounds) => {
    if (!isHttpUrl(url)) throw new Error("仅支持 http/https 地址");
    const view = ensureBrowserView();
    view.setBounds(bounds);
    await view.webContents.loadURL(url);
    return { url: view.webContents.getURL(), title: view.webContents.getTitle() };
  });
  ipcMain.handle("browser:setBounds", (_event, bounds: BrowserBounds) => {
    browserView?.setBounds(bounds);
  });
  ipcMain.handle("browser:navigate", async (_event, url: string) => {
    if (!isHttpUrl(url)) throw new Error("仅支持 http/https 地址");
    await ensureBrowserView().webContents.loadURL(url);
  });
  ipcMain.handle("browser:back", () => {
    if (browserView?.webContents.canGoBack()) browserView.webContents.goBack();
  });
  ipcMain.handle("browser:forward", () => {
    if (browserView?.webContents.canGoForward()) browserView.webContents.goForward();
  });
  ipcMain.handle("browser:reload", () => browserView?.webContents.reload());
  ipcMain.handle("browser:close", () => closeBrowserView());
  ipcMain.handle("browser:state", () => ({
    isOpen: Boolean(browserView),
    url: browserView?.webContents.getURL() ?? "",
    title: browserView?.webContents.getTitle() ?? "",
    loading: browserView?.webContents.isLoading() ?? false,
    canGoBack: browserView?.webContents.canGoBack() ?? false,
    canGoForward: browserView?.webContents.canGoForward() ?? false
  }));
  ipcMain.handle("shell:openExternal", (_event, url: string) => {
    if (!isHttpUrl(url)) throw new Error("仅支持 http/https 地址");
    return shell.openExternal(url);
  });
  ipcMain.handle("app:info", () => ({
    version: app.getVersion(),
    platform: process.platform
  }));
}

app.whenReady().then(() => {
  registerIpc();
  createWindow();
  app.on("activate", () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on("window-all-closed", () => {
  if (process.platform !== "darwin") app.quit();
});
