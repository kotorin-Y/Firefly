import { describe, expect, it } from "vitest";
import {
  parseHaoyouKuaibao,
  parseHeyboxBanner,
  parseIyingdi,
  portalFallbackItem
} from "./community-provider";

describe("community provider parsers", () => {
  it("parses public Haoyou Kuaibao recommendation cards", () => {
    const html = `
      <a href="//www.3839.com/a/145689.htm">
        <img src="//img.example.com/game.jpg" alt="超阈限空间">
        <div class="name"><em>超阈限空间</em></div>
        <p class="desc">颠覆视角，随地大小变</p>
      </a>`;
    const [result] = parseHaoyouKuaibao(html);
    expect(result.title).toBe("超阈限空间");
    expect(result.url).toBe("https://www.3839.com/a/145689.htm");
    expect(result.imageUrl).toBe("https://img.example.com/game.jpg");
  });

  it("parses public Heybox home banner data", () => {
    const [result] = parseHeyboxBanner({
      result: {
        banner: [{
          linkid: 184065725,
          title: "环世界模组推荐",
          thumb: "https://img.example.com/heybox.png",
          timestamp: 1782196385,
          author: { username: "X飞龙X" },
          topic: { name: "边缘世界" },
          click: 5769
        }]
      }
    });
    expect(result.title).toBe("环世界模组推荐");
    expect(result.url).toContain("184065725");
    expect(result.author).toBe("X飞龙X");
  });

  it("parses Iyingdi public post links and removes duplicate URLs", () => {
    const html = `
      <a href="/tz/post/5670279">【营地炉石标准日报】20260621</a>
      <a href="/tz/post/5670279">【营地炉石标准日报】20260621</a>`;
    const result = parseIyingdi(html);
    expect(result).toHaveLength(1);
    expect(result[0].url).toBe("https://www.iyingdi.com/tz/post/5670279");
  });

  it("creates a readable source portal fallback", () => {
    const result = portalFallbackItem({
      id: "taptap",
      label: "TapTap",
      homepage: "https://www.taptap.cn/moment",
      description: "发现游戏动态"
    });
    expect(result.provider).toBe("taptap");
    expect(result.title).toContain("TapTap");
  });
});
