import { Eye, EyeOff, LogIn, UserPlus } from "lucide-react";
import { FormEvent, useEffect, useState } from "react";
import type { RegistrationInput } from "../shared/contracts";
import { useAppStore } from "../state/useAppStore";
import { Modal } from "./Modal";

type FieldErrors = Partial<Record<keyof RegistrationInput | "form", string>>;

export function AuthModal() {
  const { authModalMode, closeAuthModal, openAuthModal, setAccount } = useAppStore();
  const [displayName, setDisplayName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [acceptedTerms, setAcceptedTerms] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [errors, setErrors] = useState<FieldErrors>({});
  const [submitting, setSubmitting] = useState(false);
  const [authMode, setAuthMode] = useState<"remote" | "local-demo">("local-demo");

  useEffect(() => {
    if (!authModalMode) return;
    void window.fancy.auth.state().then((state) => setAuthMode(state.mode || "local-demo"));
  }, [authModalMode]);

  if (!authModalMode) return null;
  const registering = authModalMode === "register";

  const submit = async (event: FormEvent) => {
    event.preventDefault();
    const nextErrors: FieldErrors = {};
    if (registering && !displayName.trim()) nextErrors.displayName = "请输入昵称";
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
      nextErrors.email = "请输入有效邮箱";
    }
    if (password.length < 8 || !/[A-Za-z]/.test(password) || !/\d/.test(password)) {
      nextErrors.password = "密码至少需要 8 位，并同时包含字母和数字";
    }
    if (registering && confirmPassword !== password) {
      nextErrors.confirmPassword = "两次输入的密码不一致";
    }
    if (registering && !acceptedTerms) {
      nextErrors.acceptedTerms = "请先同意服务条款与隐私说明";
    }
    if (Object.keys(nextErrors).length) {
      setErrors(nextErrors);
      return;
    }

    setSubmitting(true);
    setErrors({});
    try {
      const state = registering
        ? await window.fancy.auth.register({
          displayName,
          email,
          password,
          confirmPassword,
          acceptedTerms
        })
        : await window.fancy.auth.login({ email, password });
      setAccount(state.account);
      closeAuthModal();
    } catch (error) {
      setErrors({ form: error instanceof Error ? error.message : String(error) });
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Modal
      title={registering ? "创建 Fancy! 账户" : "登录 Fancy!"}
      onClose={closeAuthModal}
      focusCloseButton={false}
    >
      <form className="auth-form" onSubmit={submit}>
        <div className="auth-intro">
          <span>{registering ? <UserPlus size={20} /> : <LogIn size={20} />}</span>
          <div>
            <b>{registering ? "保存你的追更、收藏与创作身份" : "继续你的 ACGN 探索记录"}</b>
            <p>
              {authMode === "remote"
                ? "账户将通过已配置的 Fancy! 服务同步，会话令牌仅缓存在本机。"
                : "当前未配置账户服务器，正在使用本机演示模式。"}
            </p>
          </div>
        </div>

        {registering && (
          <label>
            昵称
            <input
              autoFocus
              autoComplete="nickname"
              value={displayName}
              onChange={(event) => setDisplayName(event.target.value)}
              aria-invalid={Boolean(errors.displayName)}
            />
            {errors.displayName && <small role="alert">{errors.displayName}</small>}
          </label>
        )}

        <label>
          邮箱
          <input
            autoFocus={!registering}
            type="email"
            autoComplete="email"
            value={email}
            onChange={(event) => setEmail(event.target.value)}
            aria-invalid={Boolean(errors.email)}
          />
          {errors.email && <small role="alert">{errors.email}</small>}
        </label>

        <label>
          密码
          <div className="password-field">
            <input
              type={showPassword ? "text" : "password"}
              autoComplete={registering ? "new-password" : "current-password"}
              value={password}
              onChange={(event) => setPassword(event.target.value)}
              aria-invalid={Boolean(errors.password)}
            />
            <button
              type="button"
              onClick={() => setShowPassword((value) => !value)}
              aria-label={showPassword ? "隐藏密码" : "显示密码"}
            >
              {showPassword ? <EyeOff size={17} /> : <Eye size={17} />}
            </button>
          </div>
          {errors.password && <small role="alert">{errors.password}</small>}
        </label>

        {registering && (
          <>
            <label>
              确认密码
              <input
                type={showPassword ? "text" : "password"}
                autoComplete="new-password"
                value={confirmPassword}
                onChange={(event) => setConfirmPassword(event.target.value)}
                aria-invalid={Boolean(errors.confirmPassword)}
              />
              {errors.confirmPassword && <small role="alert">{errors.confirmPassword}</small>}
            </label>
            <label className="terms-check">
              <input
                type="checkbox"
                checked={acceptedTerms}
                onChange={(event) => setAcceptedTerms(event.target.checked)}
              />
              <span>我已阅读并同意服务条款与隐私说明。</span>
            </label>
            {errors.acceptedTerms && <small className="field-error" role="alert">{errors.acceptedTerms}</small>}
          </>
        )}

        {errors.form && <div className="auth-error" role="alert">{errors.form}</div>}

        <button className="primary-button auth-submit" disabled={submitting}>
          {submitting ? "正在处理…" : registering ? "注册并登录" : "登录"}
        </button>
        <button
          type="button"
          className="auth-mode-switch"
          onClick={() => {
            setErrors({});
            openAuthModal(registering ? "login" : "register");
          }}
        >
          {registering ? "已有账户？直接登录" : "还没有账户？立即注册"}
        </button>
      </form>
    </Modal>
  );
}
