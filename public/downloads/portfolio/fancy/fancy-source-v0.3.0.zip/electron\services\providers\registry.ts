import type { ContentProvider } from "./provider.js";
import { BilibiliProvider } from "./bilibili-provider.js";
import {
  COMMUNITY_PROVIDER_DEFINITIONS,
  CommunityProvider
} from "./community-provider.js";
import { RssProvider } from "./rss-provider.js";
import type { ContentLanguage } from "../../../src/shared/contracts.js";

export interface ProviderDefinition {
  id: string;
  label: string;
  url: string;
  categories: ConstructorParameters<typeof RssProvider>[3];
  sourceLanguage: ContentLanguage;
}

export const RSS_PROVIDER_DEFINITIONS: ProviderDefinition[] = [
  {
    id: "gcores",
    label: "机核 GCORES",
    url: "https://www.gcores.com/rss",
    categories: ["game", "community"],
    sourceLanguage: "zh-CN"
  },
  {
    id: "4gamer",
    label: "4Gamer",
    url: "https://www.4gamer.net/rss/index.xml",
    categories: ["game"],
    sourceLanguage: "ja"
  },
  {
    id: "playstation",
    label: "PlayStation Blog",
    url: "https://blog.playstation.com/feed/",
    categories: ["game"],
    sourceLanguage: "en"
  },
  {
    id: "automaton",
    label: "AUTOMATON",
    url: "https://automaton-media.com/feed/",
    categories: ["game", "community"],
    sourceLanguage: "ja"
  },
  {
    id: "animeanime",
    label: "Anime! Anime!",
    url: "https://animeanime.jp/rss/index.rdf",
    categories: ["anime", "manga"],
    sourceLanguage: "ja"
  },
  {
    id: "insidegames",
    label: "Inside Games",
    url: "https://www.inside-games.jp/rss/index.rdf",
    categories: ["game", "anime"],
    sourceLanguage: "ja"
  },
  {
    id: "gamewatch",
    label: "GAME Watch",
    url: "https://game.watch.impress.co.jp/data/rss/1.0/gmw/feed.rdf",
    categories: ["game"],
    sourceLanguage: "ja"
  }
];

export function createProviders(): ContentProvider[] {
  return [
    new BilibiliProvider(),
    ...COMMUNITY_PROVIDER_DEFINITIONS.map((definition) => new CommunityProvider(definition)),
    ...RSS_PROVIDER_DEFINITIONS.map((definition) => new RssProvider(
      definition.id,
      definition.label,
      definition.url,
      definition.categories,
      definition.sourceLanguage
    ))
  ];
}
