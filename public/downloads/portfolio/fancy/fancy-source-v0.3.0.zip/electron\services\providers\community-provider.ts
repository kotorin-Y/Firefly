import type {
  ContentCategory,
  ContentItem,
  FeedQuery
} from "../../../src/shared/contracts.js";
import type { ContentProvider } from "./provider.js";
import {
  fetchWithTimeout,
  secureMediaUrl,
  stripHtml
} from "./provider.js";
import { matchesSearchQuery } from "./rss-provider.js";

interface CommunityDefinition {
  id: string;
  label: string;
  homepage: string;
  description: string;
  mode: "portal" | "haoyou" | "heybox" | "iyingdi";
}

interface HeyboxBannerPayload {
  result?: {
    banner?: Array<{
      linkid?: number;
      title?: string;
      thumb?: string;
      timestamp?: number;
      author?: { username?: string };
      topic?: { name?: string };
      click?: number;
    }>;
  };
}

const now = () => new Date().toISOString();

function uniqueByUrl(items: ContentItem[]): ContentItem[] {
  const seen = new Set<string>();
  return items.filter((item) => {
    if (seen.has(item.url)) return false;
    seen.add(item.url);
    return true;
  });
}

function absoluteUrl(value: string, origin: string): string {
  if (value.startsWith("//")) return `https:${value}`;
  return new URL(value, origin).toString();
}

export function portalFallbackItem(
  definition: Pick<CommunityDefinition, "id" | "label" | "homepage" | "description">
): ContentItem {
  return {
    id: `${definition.id}:portal`,
    provider: definition.id,
    providerLabel: definition.label,
    kind: "subject",
    category: "community",
    title: `${definition.label} 社区精选入口`,
    summary: definition.description,
    url: definition.homepage,
    publishedAt: now(),
    tags: ["中国大陆社区", definition.label],
    sourceLanguage: "zh-CN"
  };
}

export function parseHaoyouKuaibao(html: string): ContentItem[] {
  const matches = html.matchAll(
    /<a[^>]+href=["']((?:https?:)?\/\/www\.3839\.com\/a\/\d+\.htm)["'][^>]*>([\s\S]{0,900}?)<\/a>/gi
  );
  const items = Array.from(matches, ([, href, body], index): ContentItem => {
    const image = body.match(/<img[^>]+src=["']([^"']+)["']/i)?.[1];
    const title = stripHtml(
      body.match(/class=["']name["'][^>]*>([\s\S]*?)<\/div>/i)?.[1] ||
      body.match(/<img[^>]+alt=["']([^"']+)["']/i)?.[1] ||
      "好游快爆推荐"
    );
    const summary = stripHtml(
      body.match(/class=["']desc["'][^>]*>([\s\S]*?)<\/p>/i)?.[1] ||
      "来自好游快爆公开首页的游戏推荐。"
    );
    return {
      id: `haoyou:${href.match(/\d+/)?.[0] ?? index}`,
      provider: "haoyou",
      providerLabel: "好游快爆",
      kind: "subject",
      category: "game",
      title,
      summary,
      url: absoluteUrl(href, "https://www.3839.com/"),
      imageUrl: image ? secureMediaUrl(absoluteUrl(image, "https://www.3839.com/")) : undefined,
      publishedAt: now(),
      tags: ["中国大陆社区", "游戏推荐"],
      sourceLanguage: "zh-CN"
    };
  });
  return uniqueByUrl(items).slice(0, 18);
}

export function parseHeyboxBanner(payload: HeyboxBannerPayload): ContentItem[] {
  return (payload.result?.banner ?? []).map((entry, index): ContentItem => ({
    id: `heybox:${entry.linkid ?? index}`,
    provider: "heybox",
    providerLabel: "小黑盒",
    kind: "post",
    category: "community",
    title: entry.title || "小黑盒社区精选",
    summary: entry.topic?.name
      ? `来自「${entry.topic.name}」社区的公开精选内容。`
      : "来自小黑盒公开首页的社区精选内容。",
    url: entry.linkid
      ? `https://www.xiaoheihe.cn/app/bbs/link/${entry.linkid}`
      : "https://xiaoheihe.cn/home",
    imageUrl: secureMediaUrl(entry.thumb),
    author: entry.author?.username,
    publishedAt: new Date((entry.timestamp || Date.now() / 1000) * 1000).toISOString(),
    tags: ["中国大陆社区", entry.topic?.name || "玩家社区"],
    viewCount: entry.click,
    sourceLanguage: "zh-CN"
  }));
}

export function parseIyingdi(html: string): ContentItem[] {
  const matches = html.matchAll(
    /<a[^>]+href=["']((?:https:\/\/www\.iyingdi\.com)?\/tz\/post\/\d+)["'][^>]*>([\s\S]{0,1200}?)<\/a>/gi
  );
  const items = Array.from(matches, ([, href, body], index): ContentItem => {
    const title = stripHtml(body).slice(0, 100);
    const image = body.match(/<img[^>]+src=["']([^"']+)["']/i)?.[1];
    return {
      id: `iyingdi:${href.match(/\d+$/)?.[0] ?? index}`,
      provider: "iyingdi",
      providerLabel: "旅法师营地",
      kind: "post",
      category: "community",
      title: title || "旅法师营地社区精选",
      summary: "来自旅法师营地公开首页的资讯、攻略或玩家讨论。",
      url: absoluteUrl(href, "https://www.iyingdi.com/"),
      imageUrl: image ? secureMediaUrl(absoluteUrl(image, "https://www.iyingdi.com/")) : undefined,
      publishedAt: now(),
      tags: ["中国大陆社区", "攻略"],
      sourceLanguage: "zh-CN"
    };
  });
  return uniqueByUrl(items).slice(0, 18);
}

export class CommunityProvider implements ContentProvider {
  categories: ContentCategory[] = ["game", "community"];

  constructor(private definition: CommunityDefinition) {}

  get id(): string {
    return this.definition.id;
  }

  get label(): string {
    return this.definition.label;
  }

  private async fetchItems(): Promise<ContentItem[]> {
    if (this.definition.mode === "portal") {
      const response = await fetchWithTimeout(this.definition.homepage);
      if (!response.ok) throw new Error(`${this.label} HTTP ${response.status}`);
      return [portalFallbackItem(this.definition)];
    }

    if (this.definition.mode === "heybox") {
      const response = await fetchWithTimeout("https://api.xiaoheihe.cn/bbs/web/home/banner");
      if (!response.ok) throw new Error(`${this.label} HTTP ${response.status}`);
      const items = parseHeyboxBanner(await response.json() as HeyboxBannerPayload);
      return items.length ? items : [portalFallbackItem(this.definition)];
    }

    const response = await fetchWithTimeout(this.definition.homepage);
    if (!response.ok) throw new Error(`${this.label} HTTP ${response.status}`);
    const html = await response.text();
    const items = this.definition.mode === "haoyou"
      ? parseHaoyouKuaibao(html)
      : parseIyingdi(html);
    return items.length ? items : [portalFallbackItem(this.definition)];
  }

  async list(query: FeedQuery): Promise<ContentItem[]> {
    const items = await this.fetchItems();
    const page = Math.max(1, Number(query.cursor || "1"));
    const limit = Math.max(1, query.limit ?? 20);
    const start = (page - 1) * limit;
    return items.slice(start, start + limit);
  }

  async search(query: string): Promise<ContentItem[]> {
    const items = await this.fetchItems();
    return items.filter((item) => matchesSearchQuery(`${item.title} ${item.summary}`, query));
  }
}

export const COMMUNITY_PROVIDER_DEFINITIONS: CommunityDefinition[] = [
  {
    id: "taptap",
    label: "TapTap",
    homepage: "https://www.taptap.cn/moment",
    description: "发现游戏动态、开发者公告、玩家评价与社区讨论。",
    mode: "portal"
  },
  {
    id: "haoyou",
    label: "好游快爆",
    homepage: "https://www.3839.com/",
    description: "关注手游预约、测试资格、新游推荐和玩家攻略。",
    mode: "haoyou"
  },
  {
    id: "heybox",
    label: "小黑盒",
    homepage: "https://xiaoheihe.cn/home",
    description: "聚合 PC、主机游戏资讯、攻略、模组和玩家社区内容。",
    mode: "heybox"
  },
  {
    id: "iyingdi",
    label: "旅法师营地",
    homepage: "https://www.iyingdi.com/",
    description: "提供卡牌、策略与综合游戏资讯、攻略和玩家创作。",
    mode: "iyingdi"
  }
];
