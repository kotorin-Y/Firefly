import type { ContentCategory } from "../../shared/contracts.js";

interface ClassificationInput {
  title: string;
  summary?: string;
  tags?: string[];
  providerCategories?: readonly ContentCategory[];
}

export interface ClassificationResult {
  category: ContentCategory;
  confidence: number;
  scores: Record<ContentCategory, number>;
}

const KEYWORDS: Record<Exclude<ContentCategory, "community" | "video">, RegExp[]> = {
  anime: [
    /动画|新番|番剧|剧场版|动画化|声优|监督|制作委员会|放送|播出|anime|animation|seiyuu/i,
    /op\b|ed\b|pv\b/i
  ],
  manga: [
    /漫画|连载|单行本|话数|原画|作者休刊|杂志连载|manga|comic|tankoubon|tankōbon/i
  ],
  game: [
    /游戏|玩家|主机|手游|端游|补丁|版本更新|开发者|发售|试玩|攻略|game|gaming|steam|playstation|xbox|switch|nintendo|dlc|boss|patch/i,
    /pc\s*版|ps[45]\b/i
  ],
  novel: [
    /轻小说|小说|文库|卷册|作者新作|web\s*novel|light\s*novel|novel|bunko/i
  ]
};

const SPECIALIST_CATEGORIES = Object.keys(KEYWORDS) as Array<keyof typeof KEYWORDS>;

function scoreMatches(text: string, patterns: RegExp[], weight: number): number {
  return patterns.reduce((score, pattern) => score + (pattern.test(text) ? weight : 0), 0);
}

export function classifyContent(input: ClassificationInput): ClassificationResult {
  const scores: Record<ContentCategory, number> = {
    anime: 0,
    manga: 0,
    game: 0,
    novel: 0,
    community: 0,
    video: 0
  };
  const title = input.title.toLocaleLowerCase();
  const body = `${input.summary ?? ""} ${(input.tags ?? []).join(" ")}`.toLocaleLowerCase();

  for (const category of SPECIALIST_CATEGORIES) {
    scores[category] += scoreMatches(title, KEYWORDS[category], 2.4);
    scores[category] += scoreMatches(body, KEYWORDS[category], 1.2);
  }

  for (const category of input.providerCategories ?? []) {
    scores[category] += category === "community" ? 0.35 : 0.55;
  }

  if (/社区|论坛|站务|活动|讨论|同人|cosplay|community|forum/i.test(`${title} ${body}`)) {
    scores.community += 1.6;
  }
  if (/视频|直播|预告|实机|video|trailer|stream/i.test(`${title} ${body}`)) {
    scores.video += 1.1;
  }

  const ranked = (Object.entries(scores) as Array<[ContentCategory, number]>)
    .sort((a, b) => b[1] - a[1]);
  const [top, second] = ranked;
  if (!top || top[1] < 2) {
    return { category: "community", confidence: 0.35, scores };
  }

  const confidence = Math.min(0.98, top[1] / Math.max(top[1] + (second?.[1] ?? 0), 1));
  return {
    category: top[0] === "video" ? "community" : top[0],
    confidence,
    scores
  };
}
