import { useInfiniteQuery } from "@tanstack/react-query";
import { ArrowRight, RefreshCw, Signal, Sparkles, TrendingUp } from "lucide-react";
import { useEffect, useMemo, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { CheckinCard } from "../components/CheckinCard";
import { ContentCard } from "../components/ContentCard";
import { dedupeContent } from "../features/feed/dedupe";
import { rankRecommendations } from "../features/feed/recommendation";
import { useAppStore } from "../state/useAppStore";

export function HomePage() {
  const navigate = useNavigate();
  const preferences = useAppStore((state) => state.preferences);
  const addHistory = useAppStore((state) => state.addHistory);
  const sentinel = useRef<HTMLDivElement>(null);
  const feed = useInfiniteQuery({
    queryKey: ["feed", "home"],
    initialPageParam: "1",
    queryFn: ({ pageParam }) => window.fancy.feed.list({ category: "all", limit: 18, cursor: pageParam }),
    getNextPageParam: (lastPage) => lastPage.nextCursor
  });
  const pages = feed.data?.pages ?? [];
  const ranked = useMemo(
    () => rankRecommendations(dedupeContent(pages.flatMap((page) => page.items)), preferences),
    [pages, preferences]
  );
  const latest = pages[0];
  const featured = ranked[0];
  const openFeatured = () => {
    if (!featured) return;
    addHistory(featured);
    if (featured.bvid) navigate(`/video/bilibili/${featured.bvid}`, { state: featured });
    else navigate(`/article/${encodeURIComponent(featured.id)}`, { state: featured });
  };
  const refresh = async () => {
    await window.fancy.feed.list({ category: "all", limit: 18, cursor: "1", forceRefresh: true });
    await feed.refetch();
  };
  useEffect(() => {
    const node = sentinel.current;
    if (!node) return;
    const observer = new IntersectionObserver((entries) => {
      if (entries[0]?.isIntersecting && feed.hasNextPage && !feed.isFetchingNextPage) {
        void feed.fetchNextPage();
      }
    }, { rootMargin: "260px" });
    observer.observe(node);
    return () => observer.disconnect();
  }, [feed.hasNextPage, feed.isFetchingNextPage]);

  return (
    <div className="page home-page">
      <section className="page-heading">
        <div>
          <span className="eyebrow"><Signal size={14} /> 多来源实时情报</span>
          <h1>今日情报台</h1>
          <p>汇总作品更新、行业动态与社区观察；保留来源和发布时间，让每一次追更与判断都有上下文。</p>
        </div>
        <button className="secondary-button" onClick={refresh} disabled={feed.isFetching}>
          <RefreshCw size={16} className={feed.isFetching ? "spin" : ""} />
          {feed.isFetching ? "正在刷新" : "刷新推荐"}
        </button>
      </section>

      <section className="discovery-hero">
        <div className="discovery-hero__copy">
          <span><Sparkles size={14} /> 今日发现</span>
          <h2>{featured?.title || "正在整理今天值得关注的 ACGN 情报"}</h2>
          <p>{featured?.summary || "连接国内外资讯源后，Fancy! 会在这里展示编辑优先级最高的内容。"}</p>
          {featured && (
            <button className="hero-link" onClick={openFeatured}>
              查看完整内容 <ArrowRight size={16} />
            </button>
          )}
        </div>
        <div className="discovery-hero__visual">
          <img
            src={featured?.imageUrl || "./assets/default-cover.png"}
            alt=""
            onError={(event) => { event.currentTarget.src = "./assets/default-cover.png"; }}
          />
          <span>{featured?.providerLabel || "Fancy! 编辑部"}</span>
        </div>
      </section>

      <div className="home-grid">
        <section className="feed-column">
          <div className="section-heading">
            <h2>值得继续追踪</h2>
            <span>{latest?.refreshedAt ? `更新于 ${new Date(latest.refreshedAt).toLocaleTimeString("zh-CN")}` : ""}</span>
          </div>
          {feed.isLoading && <div className="feed-loading">正在连接已启用的资讯源，并校对更新时间…</div>}
          {feed.isError && <div className="error-panel">暂时无法完成本轮聚合。你可以检查网络后重试，其他本地功能不受影响。</div>}
          <div className="content-list">
            {ranked.slice(featured ? 1 : 0).map((item) => <ContentCard key={item.id} item={item} />)}
          </div>
          <div ref={sentinel} className="feed-sentinel">
            {feed.isFetchingNextPage ? "正在获取下一批来源内容…" : "继续下滑，查看更多已去重内容"}
          </div>
          {!feed.isLoading && ranked.length === 0 && (
            <div className="empty-panel">当前来源暂未返回可展示内容。你可以重新刷新，或进入搜索按作品、角色和版本主动查找。</div>
          )}
        </section>

        <aside className="right-rail">
          <CheckinCard />
          <section className="rail-card">
            <div className="section-heading"><h2><TrendingUp size={18} /> 来源状态</h2></div>
            <div className="provider-list">
              {latest?.providers.map((provider) => (
                <div key={provider.id}>
                  <span className={`status-dot ${provider.ok ? "" : "status-dot--error"}`} />
                  <b>{provider.label}</b>
                  <small>{provider.ok ? `${provider.itemCount} 条 · ${provider.latencyMs}ms` : "暂不可用"}</small>
                </div>
              ))}
            </div>
          </section>
          <section className="rail-card">
            <div className="section-heading"><h2>正在发生</h2></div>
            <ol className="trend-list">
              {ranked.slice(0, 6).map((item, index) => (
                <li key={item.id}>
                  <span>{String(index + 1).padStart(2, "0")}</span>
                  <div><b>{item.title}</b><small>{item.providerLabel}</small></div>
                </li>
              ))}
            </ol>
          </section>
        </aside>
      </div>
    </div>
  );
}
