import type { FancyApi } from "../../electron/preload";
import type {
  ArticleDocument,
  AuthState,
  BrowserState,
  CheckinState,
  ContentCategory,
  ContentItem,
  FeedQuery,
  FeedResponse,
  LoginInput,
  RegistrationInput,
  SearchResponse,
  UgcDraft
} from "../shared/contracts";

const cover = "./assets/default-cover.png";
const now = Date.now();
const samples: ContentItem[] = [
  ["anime-1", "Anime! Anime!", "anime", "夏季原创动画公开主视觉、制作阵容与首播日期", "制作委员会同步公布导演、系列构成和音乐团队，首集将在七月第一周播出。", "https://animeanime.jp/"],
  ["anime-2", "哔哩哔哩", "anime", "本周新番观察：演出节奏与角色关系的三个看点", "编辑整理前两集的非剧透观察，并关联制作团队访谈。", "https://www.bilibili.com/anime/"],
  ["manga-1", "Anime! Anime!", "manga", "人气漫画单行本第 12 卷确认发售，附作者新绘封面", "出版社公开书店特典、收录话数与电子版上架时间。", "https://animeanime.jp/"],
  ["manga-2", "TapTap", "manga", "从分镜到动作：社区长文拆解战斗漫画的阅读节奏", "作者以连续页面为例说明视线引导、留白与跨页构图。", "https://www.taptap.cn/moment"],
  ["game-1", "PlayStation Blog", "game", "动作游戏大型版本更新：新 Boss、武器平衡与存档继承", "官方补丁说明确认上线时间、支持平台和已知问题。", "https://blog.playstation.com/"],
  ["game-2", "小黑盒", "game", "社区实测：PC 版本性能、画面设置与手柄适配", "玩家汇总不同硬件下的帧率表现，并提供可复现的设置建议。", "https://xiaoheihe.cn/home"],
  ["novel-1", "4Gamer", "novel", "轻小说新卷公开书影与发售日期，动画改编同步更新", "文库编辑部确认纸质版、电子版与店铺特典信息。", "https://www.4gamer.net/"],
  ["novel-2", "旅法师营地", "novel", "译名考据：同一角色在不同版本中的文本差异", "社区作者整理日文原词、官方译名和语境变化。", "https://www.iyingdi.com/"],
  ["community-1", "机核 GCORES", "community", "编辑圆桌：我们如何保存一款游戏带来的长期记忆", "从音乐、关卡和玩家笔记出发，讨论作品如何进入个人经验。", "https://www.gcores.com/"],
  ["community-2", "好游快爆", "community", "本周社区精选：攻略、同人图与无剧透体验报告", "聚合高信息量内容，并保留作者、来源和发布时间。", "https://www.3839.com/"]
].map(([id, providerLabel, category, title, summary, url], index): ContentItem => ({
  id,
  provider: providerLabel.toLocaleLowerCase().replace(/\s+/g, "-"),
  providerLabel,
  kind: "article",
  category: category as ContentCategory,
  title,
  summary,
  url,
  imageUrl: cover,
  publishedAt: new Date(now - index * 3_600_000).toISOString(),
  tags: [category, "Web 演示"],
  sourceLanguage: "zh-CN",
  recommendationReason: "来自 Web 演示数据，用于验证 Fancy! 的布局、筛选和阅读流程。"
}));

function load<T>(key: string, fallback: T): T {
  try {
    const value = localStorage.getItem(`fancy-web-${key}`);
    return value ? JSON.parse(value) as T : fallback;
  } catch {
    return fallback;
  }
}

function save<T>(key: string, value: T): T {
  localStorage.setItem(`fancy-web-${key}`, JSON.stringify(value));
  return value;
}

function feedResponse(query: FeedQuery = {}): FeedResponse {
  const filtered = !query.category || query.category === "all"
    ? samples
    : samples.filter((item) => item.category === query.category);
  return {
    items: filtered.slice(0, query.limit ?? 20),
    providers: Array.from(new Set(filtered.map((item) => item.provider))).map((provider) => {
      const item = filtered.find((entry) => entry.provider === provider)!;
      return { id: provider, label: item.providerLabel, ok: true, itemCount: filtered.filter((entry) => entry.provider === provider).length, latencyMs: 12 };
    }),
    refreshedAt: new Date().toISOString()
  };
}

function articleDocument(item: ContentItem): ArticleDocument {
  return {
    sourceUrl: item.url,
    sourceLabel: item.providerLabel,
    sourceLanguage: item.sourceLanguage,
    title: item.title,
    summary: item.summary,
    heroImageUrl: item.imageUrl,
    publishedAt: item.publishedAt,
    translated: item.translated,
    keyPoints: [
      item.summary,
      "Fancy! 会优先呈现可核验的时间、平台、版本与创作者信息。",
      "Web 演示正文用于验证统一专栏界面；正式桌面版会按需读取公开来源并在线翻译。"
    ],
    paragraphs: [
      item.summary,
      "这一条内容已经被整理为站内阅读结构。用户可以先快速掌握核心事实，再决定是否进入来源页面核验细节，避免在多个网页之间反复切换。",
      "所有编辑整理内容都应保留来源名称、发布时间和原始地址。海外来源在翻译失败时回退原文，不以缺少依据的生成内容填补空白。",
      "讨论入口与当前作品上下文保持连接。用户进入论坛后，可以继续引用标题、版本和来源，形成可追踪的交流记录。"
    ]
  };
}

export function installWebFallback(): void {
  if (window.fancy) return;
  let account = load<AuthState["account"]>("account", null);
  let checkin = load<CheckinState>("checkin", {
    streak: 0,
    points: 0,
    claimedToday: false,
    rewardToday: 10
  });
  let ugc = load<UgcDraft[]>("ugc", []);
  const browserState: BrowserState = {
    isOpen: false,
    url: "",
    title: "",
    loading: false,
    canGoBack: false,
    canGoForward: false
  };

  window.fancy = {
    feed: {
      list: async (query) => feedResponse(query),
      search: async (query): Promise<SearchResponse> => ({
        query,
        groups: [{
          provider: "web-preview",
          providerLabel: "Web 演示来源",
          items: samples.filter((item) => `${item.title} ${item.summary}`.includes(query))
        }],
        searchedAt: new Date().toISOString()
      })
    },
    article: { read: async (item) => articleDocument(item) },
    store: {
      get: async (key) => load(String(key), undefined),
      set: async (key, value) => save(String(key), value)
    },
    ugc: {
      list: async () => ugc,
      create: async (draft) => {
        const saved = { ...draft, status: "published" as const, updatedAt: new Date().toISOString() };
        ugc = save("ugc", [saved, ...ugc]);
        return saved;
      }
    },
    checkin: {
      status: async () => checkin,
      claim: async () => {
        checkin = save("checkin", {
          ...checkin,
          claimedToday: true,
          streak: checkin.claimedToday ? checkin.streak : checkin.streak + 1,
          points: checkin.claimedToday ? checkin.points : checkin.points + checkin.rewardToday
        });
        return checkin;
      }
    },
    auth: {
      state: async () => ({ account, mode: "local-demo", endpointConfigured: false }),
      register: async (input: RegistrationInput) => {
        account = save("account", {
          id: crypto.randomUUID(),
          displayName: input.displayName,
          email: input.email,
          createdAt: new Date().toISOString()
        });
        return { account, mode: "local-demo", endpointConfigured: false };
      },
      login: async (input: LoginInput) => {
        if (!account || account.email.toLocaleLowerCase() !== input.email.toLocaleLowerCase()) {
          throw new Error("Web 演示中请先注册该邮箱");
        }
        return { account, mode: "local-demo", endpointConfigured: false };
      },
      logout: async () => {
        account = null;
        save("account", account);
        return { account, mode: "local-demo", endpointConfigured: false };
      }
    },
    browser: {
      open: async (url) => ({ url, title: url }),
      setBounds: async () => undefined,
      navigate: async (url) => { window.open(url, "_blank", "noopener,noreferrer"); },
      back: async () => history.back(),
      forward: async () => history.forward(),
      reload: async () => location.reload(),
      close: async () => undefined,
      state: async () => browserState
    },
    shell: {
      openExternal: async (url) => { window.open(url, "_blank", "noopener,noreferrer"); }
    },
    app: { info: async () => ({ version: "web-preview", platform: navigator.platform }) }
  } as FancyApi;
}
