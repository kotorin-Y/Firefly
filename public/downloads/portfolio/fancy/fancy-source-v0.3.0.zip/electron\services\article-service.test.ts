import { describe, expect, it } from "vitest";
import { extractArticleDocument } from "./article-service";

describe("extractArticleDocument", () => {
  it("extracts source-owned hero media and readable paragraphs", () => {
    const article = extractArticleDocument(`
      <html>
        <head>
          <title>原始标题 - Example</title>
          <meta property="og:title" content="正式文章标题">
          <meta property="og:image" content="/media/hero.jpg">
          <meta name="author" content="编辑 A">
        </head>
        <body>
          <nav>首页 分类 登录</nav>
          <article>
            <p>官方公布了作品的发售时间、支持平台与首发语言。</p>
            <p>本次更新同时说明了预约奖励、存档继承和后续补丁计划。</p>
            <p>广告</p>
          </article>
        </body>
      </html>
    `, "https://example.com/news/1");

    expect(article.title).toBe("正式文章标题");
    expect(article.heroImageUrl).toBe("https://example.com/media/hero.jpg");
    expect(article.author).toBe("编辑 A");
    expect(article.paragraphs).toHaveLength(2);
    expect(article.keyPoints[0]).toContain("发售时间");
  });

  it("rejects non-http source addresses", () => {
    expect(() => extractArticleDocument("<p>正文内容足够长，可以参与文章整理。</p>", "file:///tmp/a"))
      .toThrow("仅支持");
  });
});
