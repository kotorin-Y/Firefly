import { Bell, Bookmark, ImagePlus, Settings as SettingsIcon, Trash2 } from "lucide-react";
import { ContentCard } from "../components/ContentCard";
import { ThemePicker } from "../components/ThemePicker";
import type { ContentCategory } from "../shared/contracts";
import { useAppStore } from "../state/useAppStore";
import { normalizeThemeId } from "../config/themes";

export function FavoritesPage() {
  const favorites = useAppStore((state) => state.favorites);
  return <div className="page"><section className="page-heading"><div><span className="eyebrow"><Bookmark size={14} /> 稍后继续</span><h1>收藏</h1><p>资讯、视频与条目保存在本机。</p></div></section><div className="content-list content-list--wide">{favorites.map((item) => <ContentCard key={item.id} item={item} />)}</div>{favorites.length === 0 && <div className="empty-panel">暂时没有收藏内容。</div>}</div>;
}

export function NotificationsPage() {
  return <div className="page"><section className="page-heading"><div><span className="eyebrow"><Bell size={14} /> 统一通知</span><h1>通知</h1><p>关注更新、社区回复、审核状态与系统公告。</p></div></section><div className="notification-list"><article><span className="status-dot" /><div><b>欢迎进入 Fancy!</b><p>实时来源、搜索、浏览器与共创功能已经就绪。</p></div><time>刚刚</time></article><article><span className="status-dot" /><div><b>剧透控制提示</b><p>可在设置中选择兴趣和屏蔽关键词。</p></div><time>今天</time></article></div></div>;
}

export function SettingsPage() {
  const { preferences, setPreferences, setTheme } = useAppStore();
  const labels: Record<ContentCategory, string> = {
    anime: "动画",
    manga: "漫画",
    game: "游戏",
    novel: "轻小说",
    community: "社区",
    video: "视频"
  };
  const toggleInterest = (interest: ContentCategory) => setPreferences({
    ...preferences,
    interests: preferences.interests.includes(interest)
      ? preferences.interests.filter((item) => item !== interest)
      : [...preferences.interests, interest]
  });
  const uploadBackground = (file?: File) => {
    if (!file) return;
    if (!file.type.startsWith("image/") || file.size > 8 * 1024 * 1024) return;
    const reader = new FileReader();
    reader.onload = () => setPreferences({
      ...preferences,
      backgroundImage: typeof reader.result === "string" ? reader.result : undefined
    });
    reader.readAsDataURL(file);
  };
  return (
    <div className="page">
      <section className="page-heading">
        <div>
          <span className="eyebrow"><SettingsIcon size={14} /> 本机偏好</span>
          <h1>设置</h1>
          <p>推荐、主题、剧透和来源由你控制；动态效果同时遵循系统“减少动态”设置。</p>
        </div>
      </section>
      <div className="settings-list">
        <ThemePicker value={normalizeThemeId(preferences.themeId)} onChange={setTheme} />
        <section className="settings-section background-settings">
          <div>
            <span className="eyebrow"><ImagePlus size={14} /> 个性背景</span>
            <h2>背景图片与磨砂质感</h2>
            <p>背景只作用于页面底层；正文卡片保持足够不透明度，确保长时间阅读清晰。</p>
          </div>
          <div className="background-settings__controls">
            <label className="secondary-button">
              <ImagePlus size={16} /> 上传图片
              <input type="file" accept="image/*" onChange={(event) => uploadBackground(event.target.files?.[0])} />
            </label>
            <button
              className="secondary-button"
              disabled={!preferences.backgroundImage}
              onClick={() => setPreferences({ ...preferences, backgroundImage: undefined })}
            >
              <Trash2 size={16} /> 清除
            </button>
            <label>
              <span>背景可见度</span>
              <input
                type="range"
                min="0"
                max="70"
                value={preferences.backgroundOpacity ?? 26}
                onChange={(event) => setPreferences({ ...preferences, backgroundOpacity: Number(event.target.value) })}
              />
              <b>{preferences.backgroundOpacity ?? 26}%</b>
            </label>
            <label>
              <span>磨砂强度</span>
              <input
                type="range"
                min="0"
                max="24"
                value={preferences.backgroundBlur ?? 12}
                onChange={(event) => setPreferences({ ...preferences, backgroundBlur: Number(event.target.value) })}
              />
              <b>{preferences.backgroundBlur ?? 12}px</b>
            </label>
          </div>
        </section>
        <section>
          <div>
            <h2>个性化推荐</h2>
            <p>关闭后只按时间、质量与来源多样性排序。</p>
          </div>
          <button
            type="button"
            aria-label="切换个性化推荐"
            aria-pressed={preferences.personalized}
            className={`switch ${preferences.personalized ? "is-on" : ""}`}
            onClick={() => setPreferences({
              ...preferences,
              personalized: !preferences.personalized
            })}
          >
            <span />
          </button>
        </section>
        <section className="settings-section">
          <div>
            <h2>兴趣频道</h2>
            <p>用于本机推荐排序，不上传个人画像。</p>
          </div>
          <div className="interest-tags">
            {(["anime", "manga", "game", "novel", "community", "video"] as ContentCategory[])
              .map((tag) => (
                <button
                  type="button"
                  aria-pressed={preferences.interests.includes(tag)}
                  key={tag}
                  className={preferences.interests.includes(tag) ? "is-active" : ""}
                  onClick={() => toggleInterest(tag)}
                >
                  {labels[tag]}
                </button>
              ))}
          </div>
        </section>
        <section>
          <div>
            <h2>屏蔽关键词</h2>
            <p>使用逗号分隔；匹配内容不会进入推荐。</p>
          </div>
          <input
            aria-label="屏蔽关键词"
            value={preferences.blockedKeywords.join(",")}
            onChange={(event) => setPreferences({
              ...preferences,
              blockedKeywords: event.target.value
                .split(",")
                .map((value) => value.trim())
                .filter(Boolean)
            })}
          />
        </section>
      </div>
    </div>
  );
}
