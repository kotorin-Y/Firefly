import type { ModerationResult, UgcDraft } from "../../shared/contracts.js";

const HIGH_RISK = [
  /手机号/,
  /家庭住址/,
  /身份证/,
  /开盒/,
  /人肉/,
  /真实姓名.*地址/
];

const MEDIUM_RISK = [/https?:\/\//i, /网盘/i, /群号/i, /加我微信/i];
const CONFLICT = [/去死/, /废物/, /垃圾作者/, /围攻/];

export function moderateDraft(draft: UgcDraft): ModerationResult {
  const content = `${draft.title}\n${draft.body}`;

  if (HIGH_RISK.some((pattern) => pattern.test(content))) {
    return {
      risk: "L3",
      action: "block",
      reasons: ["疑似包含隐私披露或人肉信息"],
      suggestions: ["删除可识别个人身份、住址或联系方式的信息后重新提交"]
    };
  }

  const reasons: string[] = [];
  const suggestions: string[] = [];
  if (MEDIUM_RISK.some((pattern) => pattern.test(content))) {
    reasons.push("包含外部链接");
    suggestions.push("确认链接来源、素材授权和站外风险");
  }
  if (CONFLICT.some((pattern) => pattern.test(content))) {
    reasons.push("包含可能升级冲突的表达");
    suggestions.push("针对观点而非个人进行讨论");
  }
  if (draft.aiAssistance === "substantial") {
    reasons.push("大量使用 AI 辅助");
    suggestions.push("确认已保留 AI 生成内容标识");
  }

  if (reasons.length > 0) {
    return {
      risk: reasons.length > 1 ? "L2" : "L1",
      action: reasons.length > 1 ? "review" : "review",
      reasons,
      suggestions
    };
  }

  return {
    risk: "L0",
    action: "publish",
    reasons: [],
    suggestions: []
  };
}
