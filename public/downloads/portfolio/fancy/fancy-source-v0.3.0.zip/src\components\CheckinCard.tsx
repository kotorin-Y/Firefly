import { Gift, Sparkles } from "lucide-react";
import { useEffect, useState } from "react";
import type { CheckinState } from "../shared/contracts";

export function CheckinCard() {
  const [state, setState] = useState<CheckinState>();
  const [message, setMessage] = useState("");

  useEffect(() => {
    void window.fancy.checkin.status().then(setState);
  }, []);

  const claim = async () => {
    try {
      const next = await window.fancy.checkin.claim();
      setState(next);
      setMessage(`签到成功，获得 ${next.rewardToday} 星尘`);
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "签到失败");
    }
  };

  if (!state) return <div className="checkin-card skeleton" />;
  return (
    <section className="checkin-card">
      <div>
        <span className="eyebrow"><Sparkles size={14} /> 每日星轨</span>
        <h3>连续签到 {state.streak} 天</h3>
        <p>星尘 {state.points} · 今日奖励 {state.rewardToday}</p>
      </div>
      <button className="primary-button" onClick={claim} disabled={state.claimedToday}>
        <Gift size={16} />
        {state.claimedToday ? "今日已签到" : "领取奖励"}
      </button>
      {message && <p className="inline-message" role="status">{message}</p>}
    </section>
  );
}
