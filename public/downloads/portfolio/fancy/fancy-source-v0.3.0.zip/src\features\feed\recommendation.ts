import type { ContentItem, UserPreferences } from "../../shared/contracts.js";

const HOUR = 3_600_000;

function matchesBlockedKeyword(item: ContentItem, keywords: string[]): boolean {
  const text = `${item.title} ${item.summary} ${item.tags.join(" ")}`.toLocaleLowerCase();
  return keywords.some((keyword) => text.includes(keyword.toLocaleLowerCase()));
}

function score(item: ContentItem, preferences: UserPreferences): number {
  const ageHours = Math.max(0, (Date.now() - new Date(item.publishedAt).getTime()) / HOUR);
  const freshness = Math.max(0, 42 - Math.log2(ageHours + 1) * 8);
  const affinity =
    preferences.personalized && preferences.interests.includes(item.category) ? 32 : 0;
  const engagement =
    Math.min(14, Math.log10((item.viewCount ?? 0) + 1) * 2) +
    Math.min(10, Math.log10((item.likeCount ?? 0) + 1) * 2);
  const seenPenalty = preferences.seenIds.includes(item.id) ? 35 : 0;
  return freshness + affinity + engagement - seenPenalty;
}

function reason(item: ContentItem, preferences: UserPreferences): string {
  if (preferences.personalized && preferences.interests.includes(item.category)) {
    const label: Record<ContentItem["category"], string> = {
      anime: "动画",
      manga: "漫画",
      game: "游戏",
      novel: "轻小说",
      community: "社区讨论",
      video: "视频"
    };
    return `因为你关注${label[item.category]}，且内容近期更新`;
  }
  return "来自近期活跃来源，并通过多样性排序";
}

export function rankRecommendations(
  items: ContentItem[],
  preferences: UserPreferences
): ContentItem[] {
  const filtered = items
    .filter((item) => !preferences.blockedProviders.includes(item.provider))
    .filter((item) => !matchesBlockedKeyword(item, preferences.blockedKeywords))
    .map((item) => ({
      ...item,
      score: score(item, preferences),
      recommendationReason: reason(item, preferences)
    }))
    .sort((a, b) => (b.score ?? 0) - (a.score ?? 0));

  const result: ContentItem[] = [];
  const deferred: ContentItem[] = [];
  for (const item of filtered) {
    const recent = result.slice(-3);
    if (recent.length === 3 && recent.every((entry) => entry.provider === item.provider)) {
      deferred.push(item);
    } else {
      result.push(item);
    }
  }

  for (const item of deferred) {
    const insertAt = result.findIndex((entry, index) => {
      const recent = result.slice(Math.max(0, index - 2), index + 1);
      return !recent.every((candidate) => candidate.provider === item.provider);
    });
    if (insertAt >= 0) result.splice(insertAt + 1, 0, item);
    else result.push(item);
  }
  return result;
}
