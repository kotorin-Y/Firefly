import { useEffect, useMemo, useState } from "react";
import { Eye, FileCheck2, Heart, MessageCircle, TrendingUp } from "lucide-react";
import type { UgcDraft } from "../shared/contracts";

export function CreatorCenterPage() {
  const [items, setItems] = useState<UgcDraft[]>([]);
  useEffect(() => { void window.fancy.ugc.list().then(setItems); }, []);
  const metrics = useMemo(() => ({
    published: items.filter((item) => item.status === "published").length,
    reviewing: items.filter((item) => item.status === "reviewing").length,
    views: 0,
    interactions: 0
  }), [items]);
  return (
    <div className="page">
      <section className="page-heading"><div><span className="eyebrow"><TrendingUp size={14} /> 创作者工作台</span><h1>创作者中心</h1><p>发布与审核状态来自本机真实记录；阅读和互动数据尚未接入时保持零值，不使用估算数据填充。</p></div></section>
      <div className="metric-grid">
        <div><FileCheck2 /><span>已发布<b>{metrics.published}</b></span></div>
        <div><Eye /><span>累计阅读<b>{metrics.views}</b></span></div>
        <div><Heart /><span>累计互动<b>{metrics.interactions}</b></span></div>
        <div><MessageCircle /><span>审核中<b>{metrics.reviewing}</b></span></div>
      </div>
      <section className="analytics-card">
        <header><h2>近 7 日内容表现</h2><span>待接入行为统计</span></header>
        <div className="empty-panel">当前版本尚未接入阅读与互动事件，因此不生成趋势图。发布和审核记录仍可正常查看。</div>
      </section>
      <section className="creator-content"><h2>作品与审核</h2>{items.length === 0 ? <div className="empty-panel">你还没有发布作品。进入共创广场完成第一篇内容后，这里会显示真实数据。</div> : items.map((item) => <article key={item.id}><span className={`source-badge status-${item.status}`}>{item.status}</span><div><b>{item.title}</b><p>{item.relatedIp} · {item.contentType} · {new Date(item.updatedAt).toLocaleString("zh-CN")}</p></div><small>{item.moderation?.risk}</small></article>)}</section>
    </div>
  );
}
