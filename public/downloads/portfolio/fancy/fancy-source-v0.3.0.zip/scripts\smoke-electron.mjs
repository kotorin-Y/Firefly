import { _electron as electron } from "playwright-core";
import { spawnSync } from "node:child_process";
import fs from "node:fs/promises";
import path from "node:path";

const root = path.resolve(import.meta.dirname, "..");
const out = path.join(root, "artifacts", "smoke");
const userData = path.join(out, "user-data");
await fs.rm(out, { recursive: true, force: true });
await fs.mkdir(userData, { recursive: true });

const app = await electron.launch({
  args: [root],
  cwd: root,
  env: { ...process.env, FANCY_USER_DATA_DIR: userData }
});
const appPid = app.process().pid;
const page = await app.firstWindow();
page.on("console", (message) => console.log(`[renderer:${message.type()}] ${message.text()}`));
page.on("pageerror", (error) => console.error(`[pageerror] ${error.message}`));

await page.setViewportSize({ width: 1440, height: 920 });
await page.getByRole("heading", { name: "今日情报台" }).waitFor();
await page.waitForTimeout(6_000);
if (await page.title() !== "Fancy!") throw new Error(`Unexpected title: ${await page.title()}`);
await page.screenshot({ path: path.join(out, "01-home.png"), fullPage: true });

await page.getByRole("button", { name: "登录或注册" }).click();
await page.getByRole("dialog", { name: "登录 Fancy!" }).waitFor();
await page.screenshot({ path: path.join(out, "01b-auth-login.png"), fullPage: true });
await page.getByRole("button", { name: "还没有账户？立即注册" }).click();
await page.getByLabel("昵称").fill("SmokeUser");
await page.getByLabel("邮箱").fill("smoke@fancy.local");
await page.getByLabel("密码", { exact: true }).fill("Fancy2026");
await page.getByLabel("确认密码").fill("Fancy2026");
await page.getByRole("checkbox").check();
await page.getByRole("button", { name: "注册并登录" }).click();

await page.getByRole("button", { name: "个人中心" }).click();
await page.getByRole("heading", { name: "SmokeUser" }).waitFor();
await page.waitForTimeout(300);
await page.screenshot({ path: path.join(out, "02-profile.png"), fullPage: true });

await page.getByRole("button", { name: /创作者中心/ }).click();
await page.getByRole("heading", { name: "创作者中心" }).waitFor();
await page.waitForTimeout(300);
await page.screenshot({ path: path.join(out, "03-creator-center.png"), fullPage: true });

await page.locator(".sidebar").getByText("设置", { exact: true }).click();
await page.getByRole("heading", { name: "设置" }).waitFor();
await page.locator(".theme-card__select").filter({ hasText: "酒红樱雾" }).click();
await page.waitForTimeout(300);
await page.screenshot({ path: path.join(out, "04-settings.png"), fullPage: true });

await page.locator(".sidebar").getByText("AI 搜索", { exact: true }).click();
await page.getByRole("heading", { name: "AI 搜索" }).waitFor();
await page.getByPlaceholder(/不剧透地整理/).fill("动画 游戏");
await page.getByRole("button", { name: "开始搜索" }).click();
await page.waitForTimeout(5_000);
await page.getByRole("button", { name: /时间：30 天/ }).click();
await page.screenshot({ path: path.join(out, "05-search.png"), fullPage: true });

await page.locator(".sidebar").getByText("共创广场", { exact: true }).click();
await page.getByRole("heading", { name: /把认真完成的作品/ }).waitFor();
await page.getByLabel("作品标题").fill("镜头语言与城市异界的色彩考据");
await page.getByLabel("正文").fill("这是一篇关于动画镜头、空间构图与角色成长关系的原创长评。");
await page.getByLabel("关联 IP").fill("原创企划");
await page.getByRole("button", { name: /提交审核/ }).click();
await page.getByText(/发布成功|已进入审核/).waitFor();
await page.waitForTimeout(300);
await page.screenshot({ path: path.join(out, "06-create.png"), fullPage: true });

await page.evaluate(() => {
  location.hash = `#/browser?url=${encodeURIComponent("https://www.gcores.com/")}`;
});
await page.getByLabel("网页地址").waitFor();
let browserState;
for (let attempt = 0; attempt < 20; attempt += 1) {
  browserState = await page.evaluate(() => window.fancy.browser.state());
  if (browserState.isOpen && !browserState.loading) break;
  await page.waitForTimeout(500);
}
if (!browserState.isOpen || !browserState.url.startsWith("https://www.gcores.com")) {
  throw new Error(`Embedded browser did not navigate: ${JSON.stringify(browserState)}`);
}
await page.screenshot({ path: path.join(out, "07-browser-shell.png"), fullPage: true });

const report = {
  title: await page.title(),
  url: page.url(),
  screenshots: 8,
  embeddedBrowser: browserState
};
await fs.writeFile(path.join(out, "report.json"), JSON.stringify(report, null, 2), "utf8");
console.log(JSON.stringify(report));

const closed = await Promise.race([
  app.close().then(() => true),
  new Promise((resolve) => setTimeout(() => resolve(false), 5_000))
]);
if (!closed) app.process().kill();
if (process.platform === "win32") {
  spawnSync("taskkill", ["/PID", String(appPid), "/T", "/F"], { stdio: "ignore" });
  const escapedRoot = root.replaceAll("'", "''");
  spawnSync("powershell.exe", [
    "-NoProfile",
    "-Command",
    `$root='${escapedRoot}'; Get-Process electron -ErrorAction SilentlyContinue | Where-Object { $_.Path -and $_.Path.StartsWith($root) } | Stop-Process -Force`
  ], { stdio: "ignore" });
}
process.exit(0);
