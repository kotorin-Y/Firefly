import { describe, expect, it } from "vitest";
import {
  hashPassword,
  validateRegistration,
  verifyPassword
} from "./auth-service";

describe("local auth", () => {
  it("validates registration fields with user-facing messages", () => {
    expect(validateRegistration({
      displayName: "",
      email: "bad",
      password: "123",
      confirmPassword: "456",
      acceptedTerms: false
    })).toEqual({
      displayName: "请输入昵称",
      email: "请输入有效邮箱",
      password: "密码至少需要 8 位，并同时包含字母和数字",
      confirmPassword: "两次输入的密码不一致",
      acceptedTerms: "请先同意服务条款与隐私说明"
    });
  });

  it("hashes passwords with a salt and verifies them", async () => {
    const credential = await hashPassword("Fancy2026");
    expect(credential.hash).not.toContain("Fancy2026");
    expect(await verifyPassword("Fancy2026", credential)).toBe(true);
    expect(await verifyPassword("wrong-password", credential)).toBe(false);
  });
});
