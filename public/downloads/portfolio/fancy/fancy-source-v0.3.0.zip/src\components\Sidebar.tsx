import {
  Bell,
  BookOpen,
  Bookmark,
  Bot,
  Clapperboard,
  Gamepad2,
  Home,
  Library,
  MessageSquareText,
  Palette,
  Settings,
  Sparkles,
  UserRound
} from "lucide-react";
import { NavLink, useNavigate } from "react-router-dom";
import { useAppStore } from "../state/useAppStore";

const navGroups = [
  {
    label: "发现",
    items: [
      ["/", "首页", Home],
      ["/channel/all", "资讯", Clapperboard],
      ["/search", "AI 搜索", Bot]
    ]
  },
  {
    label: "内容分区",
    items: [
      ["/channel/anime", "动画", Sparkles],
      ["/channel/manga", "漫画", Library],
      ["/channel/game", "游戏", Gamepad2],
      ["/channel/novel", "轻小说", BookOpen],
      ["/forum", "论坛", MessageSquareText],
      ["/create", "共创广场", Palette]
    ]
  },
  {
    label: "我的",
    items: [
      ["/favorites", "收藏", Bookmark],
      ["/notifications", "通知", Bell],
      ["/settings", "设置", Settings]
    ]
  }
] as const;

export function Sidebar() {
  const navigate = useNavigate();
  const { account, openAuthModal } = useAppStore();
  return (
    <aside className="sidebar">
      <button
        className="sidebar-account"
        onClick={() => account ? navigate("/profile") : openAuthModal("login")}
        aria-label={account ? "打开个人中心" : "登录或注册"}
      >
        <span className="sidebar-account__avatar">
          {account
            ? <img src="./assets/avatar-default.png" alt="" />
            : <UserRound size={21} />}
        </span>
        <span>
          <b>{account?.displayName || "登录 / 注册"}</b>
          <small>{account ? "个人中心与同步" : "建立你的 ACGN 身份"}</small>
        </span>
      </button>
      <nav aria-label="主导航">
        {navGroups.map((group) => (
          <section className="nav-group" key={group.label}>
            <h2>{group.label}</h2>
            {group.items.map(([to, label, Icon]) => (
              <NavLink key={to} to={to} end={to === "/"}>
                <Icon size={18} />
                <span>{label}</span>
              </NavLink>
            ))}
          </section>
        ))}
      </nav>
      <footer>
        <span className="status-dot" />
        Fancy! 多来源编辑台
      </footer>
    </aside>
  );
}
