import { describe, expect, it } from "vitest";
import type { ContentItem } from "../../shared/contracts";
import { dedupeContent } from "./dedupe";

const item = (id: string, title: string, url: string): ContentItem => ({
  id,
  provider: "test",
  providerLabel: "测试",
  kind: "article",
  category: "game",
  title,
  summary: "",
  url,
  publishedAt: new Date().toISOString(),
  tags: []
});

describe("dedupeContent", () => {
  it("deduplicates tracking variants of the same url", () => {
    const result = dedupeContent([
      item("1", "版本更新", "https://example.com/news?id=1&utm_source=x"),
      item("2", "版本更新", "https://example.com/news?id=1")
    ]);

    expect(result).toHaveLength(1);
  });

  it("keeps different stories from the same provider", () => {
    const result = dedupeContent([
      item("1", "版本更新一", "https://example.com/1"),
      item("2", "版本更新二", "https://example.com/2")
    ]);

    expect(result).toHaveLength(2);
  });
});
