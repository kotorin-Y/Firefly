import { describe, expect, it } from "vitest";
import { classifyContent } from "./classification";

describe("classifyContent", () => {
  it("keeps a manga serialization item out of the anime channel", () => {
    const result = classifyContent({
      title: "漫画《星海旅人》单行本第 8 卷与连载更新",
      summary: "作者公开新绘封面，出版社确认发售日期。",
      tags: ["漫画", "单行本"],
      providerCategories: ["anime", "manga"]
    });

    expect(result.category).toBe("manga");
    expect(result.confidence).toBeGreaterThanOrEqual(0.6);
  });

  it("uses strong game terminology instead of a generic community fallback", () => {
    const result = classifyContent({
      title: "Steam 版本更新：新增 Boss、武器平衡与补丁说明",
      summary: "开发者公开了 PC 版补丁日志和玩家反馈计划。",
      tags: ["版本更新"],
      providerCategories: ["game", "community"]
    });

    expect(result.category).toBe("game");
  });

  it("falls back to community when no specialist category is confident", () => {
    const result = classifyContent({
      title: "编辑部本周讨论与站务说明",
      summary: "社区规则、活动安排与反馈入口更新。",
      tags: ["公告"],
      providerCategories: ["anime", "manga", "game", "novel", "community"]
    });

    expect(result.category).toBe("community");
    expect(result.confidence).toBeLessThan(0.6);
  });
});
