import {
  BarChart3,
  Bookmark,
  Clock3,
  LogIn,
  LogOut,
  Palette,
  Settings,
  Sparkles,
  UserPlus
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import { CheckinCard } from "../components/CheckinCard";
import { useAppStore } from "../state/useAppStore";

export function ProfilePage() {
  const navigate = useNavigate();
  const {
    favorites,
    history,
    preferences,
    account,
    openAuthModal,
    setAccount
  } = useAppStore();
  const interestLabels = {
    anime: "动画",
    manga: "漫画",
    game: "游戏",
    novel: "轻小说",
    community: "社区",
    video: "视频"
  } as const;

  if (!account) {
    return (
      <div className="page">
        <section className="profile-login-panel">
          <img src="./assets/fancy-logo.png" alt="" />
          <span className="eyebrow"><Sparkles size={14} /> 建立你的 Fancy! 身份</span>
          <h1>登录后继续收藏、追更与创作</h1>
          <p>当前版本使用安全的本机账户。注册信息和密码哈希仅保存在这台设备，不上传至第三方服务。</p>
          <div>
            <button className="primary-button" onClick={() => openAuthModal("login")}><LogIn size={16} /> 登录</button>
            <button className="secondary-button" onClick={() => openAuthModal("register")}><UserPlus size={16} /> 注册新账户</button>
          </div>
        </section>
      </div>
    );
  }

  return (
    <div className="page">
      <section className="profile-hero">
        <img src="./assets/avatar-default.png" alt="个人头像" />
        <div>
          <span className="eyebrow"><Sparkles size={14} /> 本机账户 · 星轨观察员</span>
          <h1>{account.displayName}</h1>
          <p>{account.email} · 记录追更进度、可信来源与创作足迹。</p>
        </div>
        <div className="profile-hero__actions">
          <button className="secondary-button" onClick={() => navigate("/settings")}><Settings size={16} /> 编辑设置</button>
          <button className="secondary-button" onClick={async () => {
            const state = await window.fancy.auth.logout();
            setAccount(state.account);
          }}><LogOut size={16} /> 退出登录</button>
        </div>
      </section>
      <div className="profile-grid">
        <div>
          <CheckinCard />
          <section className="profile-section"><h2>兴趣档案</h2><div className="interest-tags">{preferences.interests.map((tag) => <span key={tag}>{interestLabels[tag]}</span>)}</div></section>
          <section className="profile-section"><h2>最近浏览</h2>{history.slice(0, 5).map((item) => <button className="history-row" key={item.id} onClick={() => navigate(`/browser?url=${encodeURIComponent(item.url)}`)}><Clock3 size={15} /><span>{item.title}</span><small>{item.providerLabel}</small></button>)}</section>
        </div>
        <aside>
          <button className="profile-action profile-action--primary" onClick={() => navigate("/creator")}><BarChart3 /><span><b>创作者中心</b><small>查看 UGC 数据、审核和作品表现</small></span></button>
          <button className="profile-action" onClick={() => navigate("/create")}><Palette /><span><b>发布创作</b><small>图文、攻略、考据与二创</small></span></button>
          <button className="profile-action" onClick={() => navigate("/favorites")}><Bookmark /><span><b>我的收藏</b><small>{favorites.length} 条已收藏内容</small></span></button>
        </aside>
      </div>
    </div>
  );
}
