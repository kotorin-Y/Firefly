import Store from "electron-store";
import type {
  CheckinState,
  PublicAccount,
  UgcDraft,
  UserPreferences
} from "../../src/shared/contracts.js";

export interface StoredAccount extends PublicAccount {
  passwordSalt: string;
  passwordHash: string;
}

interface StoreSchema {
  preferences: UserPreferences;
  checkin: CheckinState;
  ugc: UgcDraft[];
  favorites: string[];
  history: string[];
  events: Array<Record<string, unknown>>;
  account: StoredAccount | null;
  sessionActive: boolean;
  remoteAccount: PublicAccount | null;
  remoteAccessToken: string;
}

const defaults: StoreSchema = {
  preferences: {
    personalized: true,
    interests: ["anime", "game", "community"],
    blockedProviders: [],
    blockedKeywords: [],
    seenIds: []
  },
  checkin: {
    streak: 0,
    points: 0,
    claimedToday: false,
    rewardToday: 10
  },
  ugc: [],
  favorites: [],
  history: [],
  events: [],
  account: null,
  sessionActive: false,
  remoteAccount: null,
  remoteAccessToken: ""
};

const legacyStore = new Store<StoreSchema>({
  name: "violet-nexus-data",
  cwd: process.env.FANCY_USER_DATA_DIR || undefined,
  defaults
});

export const localStore = new Store<StoreSchema>({
  name: "fancy-data",
  cwd: process.env.FANCY_USER_DATA_DIR || undefined,
  defaults
});

if (localStore.size === 0 && legacyStore.size > 0) {
  for (const key of Object.keys(defaults) as Array<keyof StoreSchema>) {
    const legacyValue = legacyStore.get(key);
    if (legacyValue !== undefined) localStore.set(key, legacyValue);
  }
}

export type StoreKey = keyof StoreSchema;
