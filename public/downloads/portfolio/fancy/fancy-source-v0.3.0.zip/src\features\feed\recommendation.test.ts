import { describe, expect, it } from "vitest";
import type { ContentItem, UserPreferences } from "../../shared/contracts";
import { rankRecommendations } from "./recommendation";

const base = (id: string, provider: string, category: ContentItem["category"], hoursAgo: number): ContentItem => ({
  id,
  provider,
  providerLabel: provider,
  kind: "article",
  category,
  title: `${category}-${id}`,
  summary: "summary",
  url: `https://example.com/${id}`,
  publishedAt: new Date(Date.now() - hoursAgo * 3_600_000).toISOString(),
  tags: [category],
  viewCount: 1000,
  likeCount: 100
});

const prefs: UserPreferences = {
  personalized: true,
  interests: ["game"],
  blockedProviders: [],
  blockedKeywords: [],
  seenIds: []
};

describe("rankRecommendations", () => {
  it("ranks a fresh interested category above an older unrelated item", () => {
    const ranked = rankRecommendations([
      base("anime-old", "a", "anime", 72),
      base("game-fresh", "b", "game", 2)
    ], prefs);

    expect(ranked[0].id).toBe("game-fresh");
    expect(ranked[0].recommendationReason).toContain("你关注游戏");
  });

  it("removes blocked providers and keywords", () => {
    const ranked = rankRecommendations([
      { ...base("blocked-provider", "blocked", "game", 1) },
      { ...base("blocked-keyword", "ok", "game", 1), title: "含有剧透的内容" },
      base("safe", "ok", "game", 3)
    ], { ...prefs, blockedProviders: ["blocked"], blockedKeywords: ["剧透"] });

    expect(ranked.map((item) => item.id)).toEqual(["safe"]);
  });

  it("limits a single provider to three consecutive results", () => {
    const ranked = rankRecommendations([
      base("a1", "a", "game", 1),
      base("a2", "a", "game", 2),
      base("a3", "a", "game", 3),
      base("a4", "a", "game", 4),
      base("b1", "b", "anime", 8)
    ], prefs);

    expect(ranked.slice(0, 4).some((item) => item.provider === "b")).toBe(true);
  });
});
