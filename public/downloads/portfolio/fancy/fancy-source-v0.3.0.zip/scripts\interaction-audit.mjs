import { _electron as electron } from "playwright-core";
import { spawnSync } from "node:child_process";
import fs from "node:fs/promises";
import path from "node:path";

const root = path.resolve(import.meta.dirname, "..");
const out = path.join(root, "artifacts", "interaction-audit");
const userData = path.join(out, "user-data");
await fs.rm(out, { recursive: true, force: true });
await fs.mkdir(userData, { recursive: true });

const app = await electron.launch({
  args: [root],
  cwd: root,
  env: { ...process.env, FANCY_USER_DATA_DIR: userData }
});
const page = await app.firstWindow();
const results = [];
const runtimeErrors = [];
const thirdPartyWarnings = [];
let videoPlayerFrameUrl = null;

page.on("pageerror", (error) => runtimeErrors.push(error.message));
page.on("console", (message) => {
  if (message.type() !== "error") return;
  const text = message.text();
  const sourceUrl = message.location().url;
  const isBilibiliPlayerWarning =
    sourceUrl.includes("bilibili.com") ||
    text.includes("@bilibili/bili-user-fingerprint");
  const isRemoteResourceWarning =
    text.includes("Failed to load resource") &&
    (sourceUrl.startsWith("http://") || sourceUrl.startsWith("https://"));
  if (isBilibiliPlayerWarning || isRemoteResourceWarning) {
    thirdPartyWarnings.push({ text, sourceUrl });
    return;
  }
  runtimeErrors.push(text);
});

async function step(name, action) {
  try {
    await action();
    results.push({ name, status: "passed" });
  } catch (error) {
    results.push({
      name,
      status: "failed",
      error: error instanceof Error ? error.message : String(error)
    });
  }
}

await page.setViewportSize({ width: 1440, height: 920 });

await step("首页加载与刷新", async () => {
  await page.getByRole("heading", { name: "今日情报台" }).waitFor();
  await page.locator(".provider-list > div").first().waitFor({ timeout: 30_000 });
  const providerCount = await page.locator(".provider-list > div").count();
  if (providerCount < 12) throw new Error(`仅加载了 ${providerCount} 个资讯来源`);
  for (const provider of ["TapTap", "好游快爆", "小黑盒", "旅法师营地"]) {
    await page.locator(".provider-list").getByText(provider, { exact: true }).waitFor();
  }
  await page.locator(".translation-badge").first().waitFor({ timeout: 15_000 });
  const translatedCount = await page.locator(".translation-badge").count();
  if (translatedCount < 1) throw new Error("海外来源未显示任何联网翻译结果");
  await page.getByRole("button", { name: /刷新推荐/ }).click();
  await page.waitForTimeout(1_000);
});

await step("签到活动", async () => {
  const claim = page.getByRole("button", { name: "领取奖励" });
  await claim.click();
  await page.getByText(/签到成功/).waitFor();
});

await step("注册与登录", async () => {
  await page.getByRole("button", { name: "登录或注册" }).click();
  await page.getByRole("dialog", { name: "登录 Fancy!" }).waitFor();
  await page.getByRole("button", { name: "还没有账户？立即注册" }).click();
  await page.getByRole("dialog", { name: "创建 Fancy! 账户" }).waitFor();
  await page.getByLabel("昵称").fill("审计用户");
  await page.getByLabel("邮箱").fill("audit@fancy.local");
  await page.getByLabel("密码", { exact: true }).fill("Fancy2026");
  await page.getByLabel("确认密码").fill("Fancy2026");
  await page.getByRole("checkbox").check();
  await page.getByRole("button", { name: "注册并登录" }).click();
  await page.getByRole("button", { name: "个人中心" }).waitFor();
  await page.getByText("审计用户", { exact: true }).waitFor();
});

await step("内容更多操作对话框", async () => {
  await page.getByRole("button", { name: "更多操作" }).first().click();
  await page.getByRole("dialog", { name: "内容操作" }).waitFor();
  await page.getByRole("button", { name: /减少此来源/ }).click();
  await page.getByRole("dialog", { name: "内容操作" }).waitFor({ state: "detached" });
});

await step("频道标签切换", async () => {
  await page.locator(".sidebar").getByText("资讯", { exact: true }).click();
  for (const tab of ["编辑精选", "热议", "日历", "最新"]) {
    await page.getByRole("tab", { name: tab }).click();
    const selected = await page.getByRole("tab", { name: tab }).getAttribute("aria-selected");
    if (selected !== "true") throw new Error(`${tab} 未进入选中状态`);
  }
});

await step("论坛板块、发布与举报对话框", async () => {
  await page.locator(".sidebar").getByText("论坛", { exact: true }).click();
  await page.getByRole("tab", { name: "动画" }).click();
  await page.getByRole("tab", { name: "综合情报" }).click();
  await page.getByRole("button", { name: /发布主题/ }).click();
  await page.getByRole("dialog", { name: "发布主题" }).waitFor();
  await page.getByRole("button", { name: "取消" }).click();
  await page.getByRole("button", { name: /举报/ }).first().click();
  await page.getByRole("dialog", { name: "举报已受理" }).waitFor();
  await page.getByRole("button", { name: "知道了" }).click();
});

await step("跨来源搜索与筛选", async () => {
  await page.locator(".sidebar").getByText("AI 搜索", { exact: true }).click();
  await page.getByPlaceholder(/不剧透地整理/).fill("游戏");
  await page.getByRole("button", { name: "开始搜索" }).click();
  await page.waitForTimeout(10_000);
  const resultCount = await page.locator(".search-groups .content-card").count();
  if (resultCount < 1) throw new Error("跨来源搜索未返回任何内容");
  await page.getByRole("button", { name: /时间：30 天/ }).click();
  await page.getByRole("button", { name: /来源：全部/ }).click();
  await page.getByRole("button", { name: /语言：全部/ }).click();
});

await step("UGC 草稿与提交", async () => {
  await page.locator(".sidebar").getByText("共创广场", { exact: true }).click();
  await page.getByLabel("作品标题").fill("Fancy! 交互与色彩观察");
  await page.getByLabel("正文").fill("这是一篇用于验证草稿保存、风险自检和提交审核流程的原创长评。");
  await page.getByLabel("关联 IP").fill("原创企划");
  await page.getByRole("button", { name: "保存草稿" }).click();
  await page.getByText("草稿已保存在本机").waitFor();
  await page.getByRole("button", { name: /提交审核/ }).click();
  await page.getByText(/发布成功|已进入审核/).waitFor();
});

await step("个人中心与创作者中心", async () => {
  await page.getByRole("button", { name: "个人中心" }).click();
  await page.getByRole("heading", { name: "审计用户" }).waitFor();
  await page.getByRole("button", { name: /创作者中心/ }).click();
  await page.getByRole("heading", { name: "创作者中心" }).waitFor();
  const published = await page.locator(".metric-grid b").first().textContent();
  if (Number(published) < 1) throw new Error("创作者中心未读取已发布 UGC");
  await page.getByRole("button", { name: "个人中心" }).click();
  await page.getByRole("button", { name: /退出登录/ }).click();
  await page.getByRole("button", { name: "登录或注册" }).waitFor();
});

await step("设置与偏好控件", async () => {
  await page.locator(".sidebar").getByText("设置", { exact: true }).click();
  const toggle = page.getByRole("button", { name: "切换个性化推荐" });
  const before = await toggle.getAttribute("aria-pressed");
  await toggle.click();
  const after = await toggle.getAttribute("aria-pressed");
  if (before === after) throw new Error("个性化推荐开关状态未变化");
  await page.locator(".theme-card__select").filter({ hasText: "午夜杏橙" }).click();
  const theme = await page.locator("html").getAttribute("data-theme");
  if (theme !== "midnight-apricot") throw new Error(`主题未切换：${theme}`);
  await page.getByRole("button", { name: "漫画" }).click();
  await page.getByLabel("屏蔽关键词").fill("剧透,抽奖");
});

await step("内置视频播放器", async () => {
  await page.evaluate(() => {
    location.hash = "#/video/bilibili/BV1xx411c7mD";
  });
  await page.getByRole("heading", { name: "视频播放" }).waitFor();
  const iframe = page.locator(".video-frame iframe");
  if (await iframe.count() !== 1) throw new Error("视频播放器 iframe 未创建");
  await page.waitForTimeout(4_000);
  const playerFrame = page
    .frames()
    .find((frame) => frame.url().includes("player.bilibili.com/player.html"));
  if (!playerFrame) {
    const frameUrls = page.frames().map((frame) => frame.url());
    throw new Error(`Bilibili player frame did not load: ${JSON.stringify(frameUrls)}`);
  }
  videoPlayerFrameUrl = playerFrame.url();
});

await page.screenshot({ path: path.join(out, "final-state.png"), fullPage: true });
const failed = results.filter((result) => result.status === "failed");
const report = {
  checkedAt: new Date().toISOString(),
  passed: results.length - failed.length,
  failed: failed.length,
  results,
  runtimeErrors,
  thirdPartyWarnings,
  videoPlayerFrameUrl
};
await fs.writeFile(path.join(out, "report.json"), JSON.stringify(report, null, 2), "utf8");

const appPid = app.process().pid;
await Promise.race([app.close(), new Promise((resolve) => setTimeout(resolve, 4_000))]);
if (process.platform === "win32") {
  spawnSync("taskkill", ["/PID", String(appPid), "/T", "/F"], { stdio: "ignore" });
  const escapedRoot = root.replaceAll("'", "''");
  spawnSync("powershell.exe", [
    "-NoProfile",
    "-Command",
    `$root='${escapedRoot}'; Get-Process electron -ErrorAction SilentlyContinue | Where-Object { $_.Path -and $_.Path.StartsWith($root) } | Stop-Process -Force`
  ], { stdio: "ignore" });
}

process.exit(failed.length || runtimeErrors.length ? 1 : 0);
