import { describe, expect, it } from "vitest";
import { extractRssImage, matchesSearchQuery, rssPageBounds } from "./rss-provider";

describe("rssPageBounds", () => {
  it("calculates stable offsets from cursor and limit", () => {
    expect(rssPageBounds({ cursor: "1", limit: 20 })).toEqual({ start: 0, end: 20 });
    expect(rssPageBounds({ cursor: "2", limit: 20 })).toEqual({ start: 20, end: 40 });
    expect(rssPageBounds({ cursor: "3", limit: 8 })).toEqual({ start: 16, end: 24 });
  });

  it("normalizes invalid values", () => {
    expect(rssPageBounds({ cursor: "invalid", limit: 0 })).toEqual({ start: 0, end: 20 });
  });
});

describe("matchesSearchQuery", () => {
  it("matches multi-term queries when at least one meaningful term is present", () => {
    expect(matchesSearchQuery("本周游戏版本更新", "动画 游戏")).toBe(true);
    expect(matchesSearchQuery("新番动画制作名单", "动画 游戏")).toBe(true);
    expect(matchesSearchQuery("电影产业观察", "动画 游戏")).toBe(false);
  });
});

describe("extractRssImage", () => {
  it("uses the first image embedded in RSS HTML", () => {
    expect(extractRssImage({
      content: '<p>intro</p><img src="https://cdn.example.com/cover.jpg?size=large" />'
    })).toBe("https://cdn.example.com/cover.jpg?size=large");
  });

  it("derives the standard 4Gamer thumbnail from an article URL", () => {
    expect(extractRssImage({
      link: "https://www.4gamer.net/games/209/G020915/20260616031/"
    })).toBe("https://www.4gamer.net/games/209/G020915/20260616031/TN/001.jpg");
  });
});
