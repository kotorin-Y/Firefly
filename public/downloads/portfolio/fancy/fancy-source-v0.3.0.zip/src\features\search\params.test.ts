import { describe, expect, it } from "vitest";
import { mergeSearchQueryParams } from "./params";

describe("mergeSearchQueryParams", () => {
  it("updates the query without dropping AI search settings", () => {
    const current = new URLSearchParams("q=old&mode=official&spoiler=safe&translate=1");

    const next = mergeSearchQueryParams(current, "动作游戏");

    expect(next.get("q")).toBe("动作游戏");
    expect(next.get("mode")).toBe("official");
    expect(next.get("spoiler")).toBe("safe");
    expect(next.get("translate")).toBe("1");
  });
});
