import type { ContentItem } from "../../shared/contracts.js";

export function interleaveProviderItems(
  groups: readonly (readonly ContentItem[])[],
  limit: number
): ContentItem[] {
  const output: ContentItem[] = [];
  const maxLength = Math.max(0, ...groups.map((group) => group.length));

  for (let index = 0; index < maxLength && output.length < limit; index += 1) {
    for (const group of groups) {
      const item = group[index];
      if (item) output.push(item);
      if (output.length >= limit) break;
    }
  }

  return output;
}
