import { BRAND } from "../config/brand";

interface BrandLogoProps {
  compact?: boolean;
}

export function BrandLogo({ compact = false }: BrandLogoProps) {
  return (
    <div className={`brand-logo ${compact ? "brand-logo--compact" : ""}`} aria-label={BRAND.name}>
      <img src={BRAND.logo} alt="" />
      {!compact && (
        <span>
          <b>{BRAND.name}</b>
          <small>ACGN DISCOVERY</small>
        </span>
      )}
    </div>
  );
}
