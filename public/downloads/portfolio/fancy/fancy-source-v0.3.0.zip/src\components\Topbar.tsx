import { Bell, CalendarDays, ChevronLeft, ChevronRight, Gift, Sparkles } from "lucide-react";
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import type { CheckinState } from "../shared/contracts";
import { SearchCommand } from "./SearchCommand";

export function Topbar() {
  const navigate = useNavigate();
  const [checkin, setCheckin] = useState<CheckinState>();
  const [checkinMessage, setCheckinMessage] = useState("");
  useEffect(() => { void window.fancy.checkin.status().then(setCheckin); }, []);
  const claim = async () => {
    const next = await window.fancy.checkin.claim();
    setCheckin(next);
    setCheckinMessage(next.claimedToday ? `连续 ${next.streak} 天 · ${next.points} 积分` : "今日已签到");
    window.setTimeout(() => setCheckinMessage(""), 2_400);
  };

  return (
    <header className="topbar">
      <div className="history-controls" aria-label="页面历史">
        <button type="button" onClick={() => history.back()} aria-label="后退"><ChevronLeft size={18} /></button>
        <button type="button" onClick={() => history.forward()} aria-label="前进"><ChevronRight size={18} /></button>
      </div>
      <button className="brand-monogram" onClick={() => navigate("/")} aria-label="返回 Fancy! 首页">
        <Sparkles size={14} /><b>F!</b>
      </button>
      <SearchCommand />
      <button className="topbar-action" onClick={() => navigate("/create")} aria-label="活动中心">
        <CalendarDays size={18} /><span>活动</span>
      </button>
      <button className={`topbar-action ${checkin?.claimedToday ? "is-done" : ""}`} onClick={() => void claim()} aria-label="每日签到">
        <Gift size={18} /><span>{checkin?.claimedToday ? "已签到" : "签到"}</span>
      </button>
      <button className="icon-button" onClick={() => navigate("/notifications")} aria-label="通知">
        <Bell size={19} />
      </button>
      {checkinMessage && <div className="topbar-toast" role="status">{checkinMessage}</div>}
    </header>
  );
}
