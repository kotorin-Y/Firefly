<div align="center">
  <img src="public/assets/fancy-logo-256.png" width="112" alt="Fancy! logo" />
  <h1>Fancy!</h1>
  <p><strong>让散落在不同世界的 ACGN 情报，在同一个宇宙相遇。</strong></p>
  <p><strong>Where stories, fandoms, and ACGN discoveries meet.</strong></p>

  <p>
    <img alt="Electron" src="https://img.shields.io/badge/Electron-42-47848F?logo=electron&logoColor=white" />
    <img alt="React" src="https://img.shields.io/badge/React-19-61DAFB?logo=react&logoColor=111827" />
    <img alt="TypeScript" src="https://img.shields.io/badge/TypeScript-5.8-3178C6?logo=typescript&logoColor=white" />
    <img alt="Vite" src="https://img.shields.io/badge/Vite-6-646CFF?logo=vite&logoColor=white" />
    <img alt="Tests" src="https://img.shields.io/badge/tests-41%20passing-2E8B57" />
  </p>

  <p>
    <a href="#中文">中文</a> ·
    <a href="#english">English</a>
  </p>
</div>

![Fancy! home](.github/assets/home.png)

## 中文

### 产品背景

ACGN 爱好者每天穿梭于动画资讯站、游戏平台、创作者社区和海外媒体。信息很多，却经常分散、重复、缺少来源，也容易被剧透和算法噪声淹没。

Fancy! 是一款面向 ACGN 用户的桌面资讯与社区产品。它尝试把“发现、检索、阅读、讨论和创作”整理成一条连续体验：既尊重内容来源，也保留追番、追游戏、研究设定和参与同人创作时那份纯粹的热情。

### 产品目标

- 聚合国内外 ACGN 资讯，并保留来源、作者与发布时间。
- 用清晰的频道分类和去重策略降低信息噪声。
- 通过 AI 辅助搜索组织跨来源结果，而不是用无引用内容替代事实。
- 将海外内容整理为简体中文阅读体验，同时保留原文核验入口。
- 为讨论、收藏、历史记录和二次创作提供统一空间。
- 在内容自由度与社区安全之间建立透明、克制的审核机制。

### 核心能力

| 模块 | 能力 |
| --- | --- |
| 多源资讯 | 聚合社区与媒体来源，支持超时隔离、缓存、去重和降级 |
| 内容频道 | 动画、漫画、游戏、轻小说等频道按关键词和来源规则分类 |
| AI 搜索 | 在搜索栏内配置来源偏好、剧透保护与翻译策略 |
| 统一阅读 | 将文章整理为一致的站内阅读界面，并提供原始来源核验 |
| 海外翻译 | 按需翻译海外内容；失败时保留原文，不阻塞资讯流 |
| 社区论坛 | 面向作品与兴趣板块的讨论空间、举报反馈与风险自检 |
| 共创广场 | 优先展示优质社区创作，提供轻量发布流程 |
| 个性化 | 收藏、历史、兴趣频道、主题与自定义背景 |
| 桌面能力 | Electron 内置浏览器、视频播放与本地安全存储 |

### 产品界面

<table>
  <tr>
    <td width="50%"><img src=".github/assets/search.png" alt="AI 搜索" /></td>
    <td width="50%"><img src=".github/assets/settings.png" alt="主题与偏好设置" /></td>
  </tr>
  <tr>
    <td align="center">跨来源 AI 搜索</td>
    <td align="center">主题与个性化设置</td>
  </tr>
</table>

### 技术架构

```text
React UI
  ├─ pages / reusable components / design tokens
  ├─ Zustand local product state
  └─ TanStack Query data lifecycle
          │ typed IPC contracts
Electron
  ├─ provider registry and feed aggregation
  ├─ article extraction and translation
  ├─ remote-ready authentication gateway
  ├─ local encrypted session storage
  └─ embedded browser and media capabilities
```

技术栈：Electron、React 19、TypeScript、Vite、TanStack Query、Zustand、Vitest、Testing Library。

### 本地运行

环境要求：

- Node.js 22.12+
- npm 10+

```bash
npm install
npm run dev
```

完整检查：

```bash
npm run check
```

Windows 构建：

```bash
npm run dist:win
```

如需接入远程认证服务，可配置 `FANCY_AUTH_API_URL`。公网服务端点必须使用 HTTPS；未配置时应用会明确运行在本地演示模式。

### 当前阶段

Fancy! 目前是一个持续迭代的产品工程原型。资讯源的结构、访问策略和可用性可能随第三方平台变化；生产环境还需要独立部署认证、翻译与内容治理服务。

---

## English

### Why Fancy!

ACGN fans jump between anime news sites, game communities, creator platforms, and overseas media every day. The information is abundant, but it is also fragmented, repetitive, difficult to verify, and often surrounded by spoilers or recommendation noise.

Fancy! is a desktop discovery and community product built for that reality. It connects discovery, search, reading, discussion, and fan creation into one coherent journey—while preserving source attribution and the excitement of following a new episode, exploring a game update, or sharing a piece of fan work.

### Product goals

- Aggregate domestic and international ACGN updates with visible attribution.
- Reduce noise through channel classification, deduplication, and source diversity.
- Use AI-assisted search to organize verifiable results instead of replacing sources.
- Translate overseas content into Simplified Chinese while preserving access to the original.
- Connect reading with collections, history, discussions, and fan creation.
- Balance expressive community culture with conservative, transparent safety controls.

### Key capabilities

| Area | Capability |
| --- | --- |
| Multi-source feed | Provider isolation, caching, deduplication, timeouts, and graceful fallback |
| Content channels | Rule-based classification for anime, manga, games, light novels, and more |
| AI-assisted search | Source preference, spoiler protection, and translation controls inside search |
| Unified reading | Consistent in-app article presentation with original-source verification |
| Translation | On-demand translation with non-blocking fallback to the original language |
| Community | Topic-based forums, reporting, and pre-publish risk checks |
| Creator square | Quality-first discovery and a lightweight publishing flow |
| Personalization | Collections, history, interests, themes, and custom backgrounds |
| Desktop features | Embedded browsing, media playback, and secure local session storage |

### Engineering

Fancy! uses a typed boundary between the React renderer and Electron services. Content providers are replaceable, failures are isolated per source, and product logic is separated from presentation to keep future channels and services extensible.

Stack: Electron, React 19, TypeScript, Vite, TanStack Query, Zustand, Vitest, and Testing Library.

### Run locally

Requirements:

- Node.js 22.12+
- npm 10+

```bash
npm install
npm run dev
```

Run tests, type checks, and the production build:

```bash
npm run check
```

Build for Windows:

```bash
npm run dist:win
```

Set `FANCY_AUTH_API_URL` to connect a remote authentication service. Public endpoints must use HTTPS. Without it, Fancy! clearly operates in local demo mode.

### Project status

Fancy! is an evolving product-engineering prototype. Third-party source structures and availability may change over time. A production deployment should provide dedicated authentication, translation, and content-governance services.

---

<div align="center">
  <strong>Made for every story we followed, every world we explored, and every creation we wanted to share.</strong>
</div>
