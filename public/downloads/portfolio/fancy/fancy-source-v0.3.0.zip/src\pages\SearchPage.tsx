import { FormEvent, useEffect, useMemo, useState } from "react";
import { Search, ShieldCheck, Sparkles } from "lucide-react";
import { useSearchParams } from "react-router-dom";
import type { ContentItem, SearchResponse } from "../shared/contracts";
import { ContentCard } from "../components/ContentCard";
import { mergeSearchQueryParams } from "../features/search/params";

const timeOptions = ["7 天", "30 天", "全部"] as const;
const languageOptions = ["全部", "中文", "日文", "英文"] as const;

function itemLanguage(item: ContentItem): (typeof languageOptions)[number] {
  if (/[\u3040-\u30ff]/u.test(item.title)) return "日文";
  if (/[\u4e00-\u9fff]/u.test(item.title)) return "中文";
  return "英文";
}

export function SearchPage() {
  const [params, setParams] = useSearchParams();
  const [query, setQuery] = useState(params.get("q") || "");
  const [data, setData] = useState<SearchResponse>();
  const [loading, setLoading] = useState(false);
  const [spoilerSafe, setSpoilerSafe] = useState(true);
  const [error, setError] = useState("");
  const [timeIndex, setTimeIndex] = useState(1);
  const [languageIndex, setLanguageIndex] = useState(0);
  const [sourceIndex, setSourceIndex] = useState(0);

  const run = async (value: string) => {
    if (!value.trim()) return;
    setLoading(true);
    setError("");
    setParams((current) => mergeSearchQueryParams(current, value));
    try {
      setData(await window.fancy.feed.search(value.trim()));
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : "搜索暂时不可用");
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => { if (params.get("q")) void run(params.get("q")!); }, []);
  const submit = (event: FormEvent) => { event.preventDefault(); void run(query); };
  const sources = useMemo(
    () => ["全部", ...(data?.groups.map((group) => group.providerLabel) ?? [])],
    [data?.groups]
  );
  const selectedTime = timeOptions[timeIndex];
  const selectedLanguage = languageOptions[languageIndex];
  const selectedSource = sources[sourceIndex] ?? "全部";
  const visibleGroups = useMemo(() => {
    if (!data) return [];
    const now = Date.now();
    const maxAge = selectedTime === "全部"
      ? Number.POSITIVE_INFINITY
      : Number.parseInt(selectedTime, 10) * 86_400_000;
    return data.groups
      .filter((group) => selectedSource === "全部" || group.providerLabel === selectedSource)
      .map((group) => ({
        ...group,
        items: group.items.filter((item) => {
          const inTime = now - new Date(item.publishedAt).getTime() <= maxAge;
          const inLanguage = selectedLanguage === "全部" || itemLanguage(item) === selectedLanguage;
          return inTime && inLanguage;
        })
      }));
  }, [data, selectedLanguage, selectedSource, selectedTime]);

  return (
    <div className="page">
      <section className="page-heading">
        <div><span className="eyebrow"><Sparkles size={14} /> 跨来源检索与核验</span><h1>AI 搜索</h1><p>先召回并归类真实来源，再生成带引用的解释。模型未配置时，仍完整提供可直接核验的来源结果。</p></div>
      </section>
      <form className="search-hero" onSubmit={submit}>
        <Search size={22} />
        <textarea value={query} onChange={(event) => setQuery(event.target.value)} placeholder="例如：不剧透地整理本周值得关注的新番、游戏版本更新与官方来源" />
        <button className="primary-button" disabled={loading}>{loading ? "检索中" : "开始搜索"}</button>
      </form>
      <div className="search-filters">
        <button className={spoilerSafe ? "is-active" : ""} onClick={() => setSpoilerSafe(!spoilerSafe)}>
          <ShieldCheck size={15} /> {spoilerSafe ? "无剧透模式已开启" : "无剧透模式已关闭"}
        </button>
        <button onClick={() => setTimeIndex((timeIndex + 1) % timeOptions.length)}>时间：{selectedTime}</button>
        <button onClick={() => setSourceIndex((sourceIndex + 1) % Math.max(1, sources.length))}>来源：{selectedSource}</button>
        <button onClick={() => setLanguageIndex((languageIndex + 1) % languageOptions.length)}>语言：{selectedLanguage}</button>
      </div>
      {error && <div className="error-panel" role="alert">{error}。请检查网络后重试。</div>}
      {data && (
        <div className="search-groups">
          {visibleGroups.map((group) => (
            <section key={group.provider} className="search-group">
              <header><h2>{group.providerLabel}</h2><span>{group.error ? `连接失败：${group.error}` : `${group.items.length} 条结果`}</span></header>
              <div className="content-list">
                {group.items.map((item) => <ContentCard key={item.id} item={item} />)}
              </div>
              {!group.error && group.items.length === 0 && <div className="empty-panel">该来源暂无匹配结果。</div>}
            </section>
          ))}
          {visibleGroups.every((group) => group.items.length === 0) && (
            <div className="empty-panel">当前筛选条件下没有匹配结果，可以切换时间、来源或语言范围。</div>
          )}
        </div>
      )}
    </div>
  );
}
