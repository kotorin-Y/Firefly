import type { ContentItem } from "../../src/shared/contracts.js";

type TranslationRequest = (text: string, sourceLanguage: string) => Promise<string>;

const BREAK_MARKER = "[[FANCY_BREAK]]";
const ITEM_MARKER = "[[FANCY_ITEM_BREAK]]";
let edgeTokenPromise: Promise<string> | null = null;

async function getEdgeToken(): Promise<string> {
  if (!edgeTokenPromise) {
    edgeTokenPromise = fetch("https://edge.microsoft.com/translate/auth", {
      signal: AbortSignal.timeout(7_000),
      headers: { "User-Agent": "FancyACGN/0.2 Desktop Translator" }
    }).then(async (response) => {
      if (!response.ok) throw new Error(`Translation auth HTTP ${response.status}`);
      return response.text();
    }).catch((error) => {
      edgeTokenPromise = null;
      throw error;
    });
  }
  return edgeTokenPromise;
}

async function requestEdgeTranslation(text: string, sourceLanguage: string): Promise<string> {
  const token = await getEdgeToken();
  const response = await fetch(
    `https://api-edge.cognitive.microsofttranslator.com/translate?api-version=3.0&from=${encodeURIComponent(sourceLanguage)}&to=zh-Hans`,
    {
      method: "POST",
      signal: AbortSignal.timeout(7_000),
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
        "User-Agent": "FancyACGN/0.2 Desktop Translator"
      },
      body: JSON.stringify([{ Text: text }])
    }
  );
  if (!response.ok) {
    if (response.status === 401) edgeTokenPromise = null;
    throw new Error(`Edge translation HTTP ${response.status}`);
  }
  const payload = await response.json() as Array<{
    translations?: Array<{ text?: string }>;
  }>;
  const translated = payload[0]?.translations?.[0]?.text?.trim();
  if (!translated) throw new Error("Edge translation response is empty");
  return translated;
}

async function requestMyMemoryTranslation(text: string, sourceLanguage: string): Promise<string> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 7_000);
  try {
    const response = await fetch(
      `https://api.mymemory.translated.net/get?q=${encodeURIComponent(text)}&langpair=${encodeURIComponent(`${sourceLanguage}|zh-CN`)}`,
      {
        signal: controller.signal,
        headers: { "User-Agent": "FancyACGN/0.2 Desktop Translator" }
      }
    );
    if (!response.ok) throw new Error(`Translation HTTP ${response.status}`);
    const payload = await response.json() as {
      responseStatus?: number;
      responseData?: { translatedText?: string };
      responseDetails?: string;
    };
    if (payload.responseStatus && payload.responseStatus !== 200) {
      throw new Error(payload.responseDetails || `Translation API ${payload.responseStatus}`);
    }
    const translated = payload.responseData?.translatedText?.trim();
    if (!translated) throw new Error("Translation response is empty");
    return translated;
  } finally {
    clearTimeout(timer);
  }
}

async function requestOnlineTranslation(text: string, sourceLanguage: string): Promise<string> {
  try {
    return await requestEdgeTranslation(text, sourceLanguage);
  } catch {
    return requestMyMemoryTranslation(text, sourceLanguage);
  }
}

export class TranslationService {
  private cache = new Map<string, string>();

  constructor(private request: TranslationRequest = requestOnlineTranslation) {}

  async translateSegments(segments: string[], sourceLanguage: string): Promise<string[] | null> {
    if (sourceLanguage.startsWith("zh")) return segments;
    const usable = segments.map((segment) => segment.trim());
    if (!usable.some(Boolean)) return segments;
    const cacheKey = `segments:${sourceLanguage}:${usable.join(ITEM_MARKER)}`;
    try {
      let translated = this.cache.get(cacheKey);
      if (!translated) {
        translated = await this.request(usable.join(`\n${ITEM_MARKER}\n`), sourceLanguage);
        this.cache.set(cacheKey, translated);
      }
      const output = translated.split(ITEM_MARKER).map((segment) => segment.trim());
      return output.length === usable.length ? output : null;
    } catch {
      return null;
    }
  }

  async translateItem(item: ContentItem): Promise<ContentItem> {
    if (!item.sourceLanguage || item.sourceLanguage.startsWith("zh")) return item;

    const source = `${item.title}\n${BREAK_MARKER}\n${item.summary}`;
    const cacheKey = `${item.sourceLanguage}:${source}`;
    try {
      let translated = this.cache.get(cacheKey);
      if (!translated) {
        translated = await this.request(source, item.sourceLanguage);
        this.cache.set(cacheKey, translated);
      }
      return this.applyTranslation(item, translated);
    } catch {
      return item;
    }
  }

  async translateItems(items: ContentItem[], concurrency = 4): Promise<ContentItem[]> {
    void concurrency;
    const output = [...items];
    const groups = new Map<string, Array<{ item: ContentItem; index: number }>>();

    items.forEach((item, index) => {
      if (!item.sourceLanguage || item.sourceLanguage.startsWith("zh")) return;
      const group = groups.get(item.sourceLanguage) ?? [];
      group.push({ item, index });
      groups.set(item.sourceLanguage, group);
    });

    await Promise.all(Array.from(groups.entries()).map(async ([language, entries]) => {
      const chunks: typeof entries[] = [];
      let chunk: typeof entries = [];
      let length = 0;
      for (const entry of entries) {
        const source = `${entry.item.title}\n${BREAK_MARKER}\n${entry.item.summary}`;
        if (chunk.length && length + source.length > 470) {
          chunks.push(chunk);
          chunk = [];
          length = 0;
        }
        chunk.push(entry);
        length += source.length + ITEM_MARKER.length + 2;
      }
      if (chunk.length) chunks.push(chunk);

      let chunkCursor = 0;
      const translateChunk = async (current: typeof entries) => {
        if (current.length === 1) {
          output[current[0].index] = await this.translateItem(current[0].item);
          return;
        }

        const uncached = current.filter(({ item, index }) => {
          const source = `${item.title}\n${BREAK_MARKER}\n${item.summary}`;
          const cached = this.cache.get(`${language}:${source}`);
          if (!cached) return true;
          output[index] = this.applyTranslation(item, cached);
          return false;
        });
        if (!uncached.length) return;

        const batchSource = uncached
          .map(({ item }) => `${item.title}\n${BREAK_MARKER}\n${item.summary}`)
          .join(`\n${ITEM_MARKER}\n`);
        try {
          const batchTranslation = await this.request(batchSource, language);
          const translatedItems = batchTranslation.split(ITEM_MARKER);
          if (translatedItems.length !== uncached.length) return;
          uncached.forEach(({ item, index }, translatedIndex) => {
            const translated = translatedItems[translatedIndex].trim();
            const source = `${item.title}\n${BREAK_MARKER}\n${item.summary}`;
            this.cache.set(`${language}:${source}`, translated);
            output[index] = this.applyTranslation(item, translated);
          });
        } catch {
          // Keep the original content when the translation endpoint is unavailable.
        }
      };
      const worker = async () => {
        while (chunkCursor < chunks.length) {
          const index = chunkCursor;
          chunkCursor += 1;
          await translateChunk(chunks[index]);
        }
      };
      await Promise.all(
        Array.from({ length: Math.min(3, chunks.length) }, () => worker())
      );
    }));
    return output;
  }

  private applyTranslation(item: ContentItem, translated: string): ContentItem {
    const [title, ...summaryParts] = translated.split(BREAK_MARKER);
    const summary = summaryParts.join(BREAK_MARKER);
    if (!title?.trim() || !summary.trim()) return item;
    return {
      ...item,
      title: title.trim(),
      summary: summary.trim(),
      originalTitle: item.title,
      originalSummary: item.summary,
      translated: true
    };
  }
}

export const translationService = new TranslationService();
