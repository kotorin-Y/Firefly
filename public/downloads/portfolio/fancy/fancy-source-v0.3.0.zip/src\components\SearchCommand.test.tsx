import { fireEvent, render, screen } from "@testing-library/react";
import { MemoryRouter, Route, Routes, useLocation } from "react-router-dom";
import { describe, expect, it } from "vitest";
import { SearchCommand } from "./SearchCommand";

function LocationProbe() {
  const location = useLocation();
  return <output data-testid="location">{location.pathname}{location.search}</output>;
}

describe("SearchCommand", () => {
  it("runs the configured search when Enter is pressed in the input", () => {
    render(
      <MemoryRouter initialEntries={["/"]}>
        <SearchCommand />
        <Routes>
          <Route path="*" element={<LocationProbe />} />
        </Routes>
      </MemoryRouter>
    );

    const input = screen.getByRole("textbox", { name: "全局搜索" });
    fireEvent.change(input, { target: { value: "动作游戏" } });
    fireEvent.keyDown(input, { key: "Enter", code: "Enter" });

    expect(screen.getByTestId("location")).toHaveTextContent(
      "/search?q=%E5%8A%A8%E4%BD%9C%E6%B8%B8%E6%88%8F"
    );
  });
});
