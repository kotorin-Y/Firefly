import { ExternalLink } from "lucide-react";
import { useLocation, useParams } from "react-router-dom";
import type { ContentItem } from "../shared/contracts";

export function VideoPage() {
  const { provider, id } = useParams();
  const item = useLocation().state as ContentItem | undefined;
  const embed = provider === "bilibili"
    ? `https://player.bilibili.com/player.html?bvid=${encodeURIComponent(id || "")}&autoplay=0&high_quality=1`
    : "";
  return (
    <div className="page video-page">
      <section className="page-heading">
        <div><span className="eyebrow">内置视频播放器</span><h1>{item?.title || "视频播放"}</h1><p>{item?.author ? `创作者：${item.author}` : "支持全屏、画中画与播放进度。"}</p></div>
        {item?.url && <button className="secondary-button" onClick={() => window.fancy.shell.openExternal(item.url)}><ExternalLink size={16} /> 打开原页面</button>}
      </section>
      <div className="video-frame">
        {embed ? <iframe src={embed} allow="autoplay; fullscreen; picture-in-picture" allowFullScreen title={item?.title || "视频"} /> : <div className="empty-panel">当前视频来源暂不支持嵌入播放。</div>}
      </div>
      <section className="video-info">
        <span className="source-badge">{item?.providerLabel || provider}</span>
        <p>{item?.summary}</p>
      </section>
    </div>
  );
}
