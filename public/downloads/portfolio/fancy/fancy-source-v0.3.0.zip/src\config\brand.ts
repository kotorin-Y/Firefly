export const BRAND = {
  name: "Fancy!",
  description: "ACGN 资讯、搜索与共创社区",
  shortDescription: "发现、核验、讨论与创作",
  logo: "./assets/fancy-logo.png",
  logoSmall: "./assets/fancy-logo-64.png",
  storageKey: "fancy-ui",
  legacyStorageKey: "violet-nexus-ui"
} as const;
