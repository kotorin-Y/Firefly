import type { ArticleDocument, ContentItem } from "../../src/shared/contracts.js";
import { translationService } from "./translation-service.js";
import { fetchWithTimeout, stripHtml } from "./providers/provider.js";

function assertHttpUrl(value: string): URL {
  const url = new URL(value);
  if (!["http:", "https:"].includes(url.protocol)) {
    throw new Error("仅支持 http/https 来源地址");
  }
  return url;
}

function decodeEntities(value: string): string {
  return stripHtml(value)
    .replace(/&#(\d+);/g, (_, code: string) => String.fromCodePoint(Number(code)))
    .replace(/&#x([\da-f]+);/gi, (_, code: string) => String.fromCodePoint(Number.parseInt(code, 16)));
}

function metaContent(html: string, name: string): string {
  const escaped = name.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const patterns = [
    new RegExp(`<meta[^>]+(?:property|name)=["']${escaped}["'][^>]+content=["']([^"']+)["']`, "i"),
    new RegExp(`<meta[^>]+content=["']([^"']+)["'][^>]+(?:property|name)=["']${escaped}["']`, "i")
  ];
  return decodeEntities(patterns.map((pattern) => html.match(pattern)?.[1]).find(Boolean) ?? "");
}

function absoluteMediaUrl(value: string, sourceUrl: URL): string | undefined {
  if (!value) return undefined;
  try {
    const url = new URL(value, sourceUrl);
    return ["http:", "https:"].includes(url.protocol) ? url.toString() : undefined;
  } catch {
    return undefined;
  }
}

function extractParagraphs(html: string): string[] {
  const articleBody =
    html.match(/<article\b[^>]*>([\s\S]*?)<\/article>/i)?.[1] ??
    html.match(/<main\b[^>]*>([\s\S]*?)<\/main>/i)?.[1] ??
    html;
  const blocked = /^(广告|推广|相关阅读|点击查看|返回首页|copyright)$/i;
  return Array.from(articleBody.matchAll(/<p\b[^>]*>([\s\S]*?)<\/p>/gi))
    .map((match) => decodeEntities(match[1]))
    .filter((paragraph) => paragraph.length >= 18 && !blocked.test(paragraph))
    .filter((paragraph, index, all) => all.indexOf(paragraph) === index)
    .slice(0, 12);
}

export function extractArticleDocument(html: string, source: string): ArticleDocument {
  const sourceUrl = assertHttpUrl(source);
  const paragraphs = extractParagraphs(html);
  const title =
    metaContent(html, "og:title") ||
    decodeEntities(html.match(/<title\b[^>]*>([\s\S]*?)<\/title>/i)?.[1] ?? "")
      .replace(/\s+[-|｜]\s+[^-|｜]+$/, "") ||
    "未命名资讯";
  const description = metaContent(html, "og:description") || metaContent(html, "description");
  const heroImageUrl = absoluteMediaUrl(
    metaContent(html, "og:image") ||
    html.match(/<article[\s\S]*?<img[^>]+src=["']([^"']+)["']/i)?.[1] ||
    "",
    sourceUrl
  );
  const keyPoints = paragraphs.slice(0, 3);

  return {
    sourceUrl: sourceUrl.toString(),
    title,
    summary: description || paragraphs[0] || "",
    author: metaContent(html, "author") || undefined,
    publishedAt: metaContent(html, "article:published_time") || undefined,
    heroImageUrl,
    paragraphs,
    keyPoints
  };
}

export async function readArticle(item: ContentItem): Promise<ArticleDocument> {
  const response = await fetchWithTimeout(item.url, {
    headers: { Accept: "text/html,application/xhtml+xml" }
  }, 10_000);
  if (!response.ok) throw new Error(`${item.providerLabel} HTTP ${response.status}`);
  const extracted = extractArticleDocument(await response.text(), item.url);
  const sourceLanguage = item.sourceLanguage ?? "unknown";
  const translated = sourceLanguage.startsWith("zh")
    ? null
    : await translationService.translateSegments([
      extracted.title,
      extracted.summary,
      ...extracted.keyPoints,
      ...extracted.paragraphs
    ], sourceLanguage);
  if (!translated) {
    return {
      ...extracted,
      title: item.title || extracted.title,
      summary: item.summary || extracted.summary,
      heroImageUrl: extracted.heroImageUrl || item.imageUrl,
      sourceLabel: item.providerLabel,
      sourceLanguage,
      translated: Boolean(item.translated)
    };
  }
  let cursor = 0;
  const title = translated[cursor++] || item.title;
  const summary = translated[cursor++] || item.summary;
  const keyPoints = extracted.keyPoints.map(() => translated[cursor++] || "");
  const paragraphs = extracted.paragraphs.map(() => translated[cursor++] || "");
  return {
    ...extracted,
    title,
    summary,
    keyPoints,
    paragraphs,
    heroImageUrl: extracted.heroImageUrl || item.imageUrl,
    sourceLabel: item.providerLabel,
    sourceLanguage,
    translated: true,
    originalTitle: extracted.title
  };
}
