import { ArrowLeft, ArrowRight, ExternalLink, RefreshCw, X } from "lucide-react";
import { FormEvent, useEffect, useRef, useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import type { BrowserState } from "../shared/contracts";

function hostname(value: string): string {
  try {
    return new URL(value).hostname;
  } catch {
    return value;
  }
}

export function BrowserPage() {
  const [params] = useSearchParams();
  const navigate = useNavigate();
  const viewport = useRef<HTMLDivElement>(null);
  const initialUrl = params.get("url") || "https://www.bilibili.com/";
  const [url, setUrl] = useState(initialUrl);
  const [browserState, setBrowserState] = useState<BrowserState>({
    isOpen: false,
    url: initialUrl,
    title: "",
    loading: true,
    canGoBack: false,
    canGoForward: false
  });

  useEffect(() => {
    const sync = () => {
      const rect = viewport.current?.getBoundingClientRect();
      if (!rect) return;
      const bounds = {
        x: Math.round(rect.x),
        y: Math.round(rect.y),
        width: Math.max(1, Math.round(rect.width)),
        height: Math.max(1, Math.round(rect.height))
      };
      void window.fancy.browser.setBounds(bounds);
    };
    const rect = viewport.current?.getBoundingClientRect();
    if (rect) void window.fancy.browser.open(initialUrl, {
      x: Math.round(rect.x), y: Math.round(rect.y),
      width: Math.round(rect.width), height: Math.round(rect.height)
    });
    const observer = new ResizeObserver(sync);
    if (viewport.current) observer.observe(viewport.current);
    window.addEventListener("resize", sync);
    const stateTimer = window.setInterval(() => {
      void window.fancy.browser.state().then((state) => {
        setBrowserState(state);
        if (state.url) setUrl(state.url);
      });
    }, 500);
    return () => {
      observer.disconnect();
      window.clearInterval(stateTimer);
      window.removeEventListener("resize", sync);
      void window.fancy.browser.close();
    };
  }, [initialUrl]);

  const submit = (event: FormEvent) => {
    event.preventDefault();
    let next = url.trim();
    if (!/^https?:\/\//i.test(next)) next = `https://${next}`;
    setUrl(next);
    void window.fancy.browser.navigate(next);
  };

  return (
    <div className="browser-page">
      <div className="browser-toolbar">
        <button disabled={!browserState.canGoBack} onClick={() => window.fancy.browser.back()} aria-label="后退"><ArrowLeft size={17} /></button>
        <button disabled={!browserState.canGoForward} onClick={() => window.fancy.browser.forward()} aria-label="前进"><ArrowRight size={17} /></button>
        <button onClick={() => window.fancy.browser.reload()} aria-label="刷新"><RefreshCw size={16} /></button>
        <form onSubmit={submit}><input value={url} onChange={(event) => setUrl(event.target.value)} aria-label="网页地址" /></form>
        <button onClick={() => window.fancy.shell.openExternal(url)} aria-label="系统浏览器打开"><ExternalLink size={17} /></button>
        <button onClick={() => navigate(-1)} aria-label="关闭浏览器"><X size={18} /></button>
      </div>
      <div className="browser-context">
        <span>{browserState.loading ? "正在连接" : "安全浏览"}</span>
        <b>{browserState.title || hostname(url)}</b>
        <small>Fancy! 保留原始域名，不修改原文，也不绕过访问限制</small>
      </div>
      <div ref={viewport} className="browser-viewport" />
    </div>
  );
}
