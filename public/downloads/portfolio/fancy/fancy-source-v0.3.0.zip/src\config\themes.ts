import type { ThemeId } from "../shared/contracts";

export interface ThemeDefinition {
  id: ThemeId;
  name: string;
  description: string;
  colors: readonly [string, string];
  sourceUrl?: string;
}

export const DEFAULT_THEME_ID: ThemeId = "fancy";

export const THEMES: ThemeDefinition[] = [
  {
    id: "fancy",
    name: "Fancy! 默认",
    description: "品牌紫与奶油黄，温和而有辨识度。",
    colors: ["#744577", "#F0E9B6"]
  },
  {
    id: "mist-blue",
    name: "雾蓝书房",
    description: "沉静深蓝与清透雾蓝，适合长时间阅读。",
    colors: ["#27374D", "#DDE6ED"],
    sourceUrl: "https://colorhunt.co/palette/27374d526d829db2bfdde6ed"
  },
  {
    id: "midnight-apricot",
    name: "午夜杏橙",
    description: "夜色靛蓝与低饱和杏橙，稳重但不沉闷。",
    colors: ["#2D3250", "#F6B17A"],
    sourceUrl: "https://colorhunt.co/palette/2d32504247697077a1f6b17a"
  },
  {
    id: "burgundy-blush",
    name: "酒红樱雾",
    description: "克制酒红与淡樱粉，适合柔和的内容界面。",
    colors: ["#643843", "#E7CBCB"],
    sourceUrl: "https://colorhunt.co/palette/64384399627ac88ea7e7cbcb"
  }
];

export function normalizeThemeId(value?: string): ThemeId {
  return THEMES.some((theme) => theme.id === value) ? value as ThemeId : DEFAULT_THEME_ID;
}
