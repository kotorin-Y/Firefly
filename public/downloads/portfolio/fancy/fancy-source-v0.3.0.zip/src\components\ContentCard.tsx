import {
  Bookmark,
  ExternalLink,
  MessageCircle,
  MoreHorizontal,
  Play,
  Sparkles
} from "lucide-react";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import type { ContentItem } from "../shared/contracts";
import { useAppStore } from "../state/useAppStore";
import { Modal } from "./Modal";

export function ContentCard({ item, featured = false }: { item: ContentItem; featured?: boolean }) {
  const navigate = useNavigate();
  const { favorites, toggleFavorite, addHistory, preferences, setPreferences } = useAppStore();
  const [showReason, setShowReason] = useState(false);
  const [showActions, setShowActions] = useState(false);
  const [showOriginal, setShowOriginal] = useState(false);
  const [copied, setCopied] = useState(false);
  const isFavorite = favorites.some((entry) => entry.id === item.id);

  const open = () => {
    addHistory(item);
    if (item.bvid) {
      navigate(`/video/bilibili/${item.bvid}`, { state: item });
    } else {
      navigate(`/article/${encodeURIComponent(item.id)}`, { state: item });
    }
  };

  return (
    <article className={`content-card content-card--${item.category} ${featured ? "content-card--featured" : ""}`}>
      <button className="content-card__image" onClick={open} aria-label={`打开 ${item.title}`}>
        <img
          src={item.imageUrl || "./assets/default-cover.png"}
          alt={item.title}
          onError={(event) => { event.currentTarget.src = "./assets/default-cover.png"; }}
        />
        {item.kind === "video" && <span className="play-badge"><Play size={15} /> {item.duration}</span>}
      </button>
      <div className="content-card__body">
        <div className="content-card__meta">
          <span className="source-badge">{item.providerLabel}</span>
          {item.translated && <span className="translation-badge">已翻译</span>}
          <time>{new Date(item.publishedAt).toLocaleString("zh-CN", { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" })}</time>
        </div>
        <button className="content-card__title" onClick={open}>{item.title}</button>
        {item.summary && <p>{item.summary}</p>}
        <footer>
          <button onClick={() => toggleFavorite(item)} className={isFavorite ? "is-active" : ""}>
            <Bookmark size={16} fill={isFavorite ? "currentColor" : "none"} />
            {isFavorite ? "已收藏" : "收藏"}
          </button>
          <button onClick={() => navigate("/forum", { state: { subject: item.title } })}>
            <MessageCircle size={16} /> 讨论
          </button>
          <button onClick={() => setShowReason(true)}>
            <Sparkles size={16} /> 推荐理由
          </button>
          <button onClick={open} aria-label="打开内容"><ExternalLink size={16} /></button>
          <button onClick={() => setShowActions(true)} aria-label="更多操作"><MoreHorizontal size={16} /></button>
        </footer>
      </div>
      {showReason && (
        <Modal title="为什么推荐给你" onClose={() => setShowReason(false)}>
          <p>{item.recommendationReason || "来自近期活跃来源，并通过来源多样性排序。"}</p>
          <p className="muted">你可以在设置中关闭个性化推荐、调整兴趣或屏蔽来源。</p>
        </Modal>
      )}
      {showActions && (
        <Modal title="内容操作" onClose={() => setShowActions(false)}>
          <div className="action-sheet">
            <button onClick={open}><ExternalLink size={17} /><span><b>阅读编辑整理版</b><small>在 Fancy! 统一专栏界面中阅读</small></span></button>
            <button onClick={async () => {
              await navigator.clipboard.writeText(item.url);
              setCopied(true);
            }}><Bookmark size={17} /><span><b>{copied ? "链接已复制" : "复制原文链接"}</b><small>保留来源地址，便于分享和核验</small></span></button>
            {item.translated && (
              <button onClick={() => {
                setShowActions(false);
                setShowOriginal(true);
              }}><Sparkles size={17} /><span><b>查看原文</b><small>对照翻译前的标题和摘要</small></span></button>
            )}
            <button onClick={() => {
              setPreferences({
                ...preferences,
                blockedProviders: [...new Set([...preferences.blockedProviders, item.provider])]
              });
              setShowActions(false);
            }}><MoreHorizontal size={17} /><span><b>减少此来源</b><small>该来源将不再进入个性化推荐</small></span></button>
          </div>
        </Modal>
      )}
      {showOriginal && (
        <Modal title="原文对照" onClose={() => setShowOriginal(false)}>
          <div className="original-content">
            <span>{item.sourceLanguage?.toLocaleUpperCase()} · {item.providerLabel}</span>
            <h3>{item.originalTitle || item.title}</h3>
            <p>{item.originalSummary || item.summary}</p>
            <button className="secondary-button" onClick={() => void window.fancy.shell.openExternal(item.url)}><ExternalLink size={16} /> 打开来源页面</button>
          </div>
        </Modal>
      )}
    </article>
  );
}
