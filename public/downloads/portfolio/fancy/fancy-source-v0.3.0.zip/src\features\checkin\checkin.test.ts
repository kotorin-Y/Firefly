import { describe, expect, it, vi } from "vitest";
import { claimCheckin } from "./checkin";

describe("claimCheckin", () => {
  it("awards once per day and grows streak on consecutive days", () => {
    vi.setSystemTime(new Date("2026-06-23T08:00:00+08:00"));
    const first = claimCheckin({ streak: 0, points: 0, claimedToday: false, rewardToday: 0 });
    expect(first.points).toBe(10);
    expect(first.streak).toBe(1);

    expect(() => claimCheckin(first)).toThrow("今天已经签到");

    vi.setSystemTime(new Date("2026-06-24T08:00:00+08:00"));
    const second = claimCheckin(first);
    expect(second.streak).toBe(2);
    expect(second.points).toBe(22);
    vi.useRealTimers();
  });

  it("resets streak after a missed day", () => {
    vi.setSystemTime(new Date("2026-06-26T08:00:00+08:00"));
    const state = claimCheckin({
      lastClaimDate: "2026-06-23",
      streak: 5,
      points: 60,
      claimedToday: false,
      rewardToday: 0
    });
    expect(state.streak).toBe(1);
    vi.useRealTimers();
  });
});
