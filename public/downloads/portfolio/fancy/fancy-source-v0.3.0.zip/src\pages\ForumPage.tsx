import { FormEvent, useMemo, useState } from "react";
import {
  Activity,
  Flag,
  Flame,
  MessageSquareText,
  Plus,
  Search,
  ShieldCheck,
  ThumbsUp,
  Users
} from "lucide-react";
import { useLocation } from "react-router-dom";
import { Modal } from "../components/Modal";
import { SegmentedControl } from "../components/SegmentedControl";
import { useAppStore } from "../state/useAppStore";

const boards = ["综合情报", "动画", "漫画", "游戏", "轻小说", "创作交流"] as const;

export function ForumPage() {
  const subject = (useLocation().state as { subject?: string } | null)?.subject;
  const { forumPosts, addForumPost, markHelpful, account, openAuthModal } = useAppStore();
  const [composer, setComposer] = useState(false);
  const [reported, setReported] = useState<string>();
  const [title, setTitle] = useState(subject ? `关于《${subject}》的讨论` : "");
  const [body, setBody] = useState("");
  const [board, setBoard] = useState("综合情报");
  const [activeBoard, setActiveBoard] = useState<(typeof boards)[number]>("综合情报");
  const [query, setQuery] = useState("");

  const visiblePosts = useMemo(() => forumPosts.filter((post) => {
    const inBoard = activeBoard === "综合情报" || post.board === activeBoard;
    const inSearch = !query.trim() || `${post.title} ${post.body} ${post.author}`
      .toLocaleLowerCase()
      .includes(query.trim().toLocaleLowerCase());
    return inBoard && inSearch;
  }), [activeBoard, forumPosts, query]);
  const replies = forumPosts.reduce((sum, post) => sum + post.replies, 0);

  const submit = (event: FormEvent) => {
    event.preventDefault();
    if (!title.trim() || !body.trim()) return;
    if (!account) {
      setComposer(false);
      openAuthModal("login");
      return;
    }
    addForumPost({ title: title.trim(), body: body.trim(), board, author: account.displayName });
    setComposer(false);
    setTitle("");
    setBody("");
  };

  return (
    <div className="page forum-page">
      <section className="community-hero">
        <div>
          <span><MessageSquareText size={15} /> Fancy! Community</span>
          <h1>让考据、攻略与创作过程被认真讨论</h1>
          <p>这里保留来源、版本与剧透边界。赞同不等于正确，分歧也不必演变成阵营对立。</p>
          <button className="hero-link" onClick={() => account ? setComposer(true) : openAuthModal("login")}>
            <Plus size={16} /> 发起讨论
          </button>
        </div>
        <dl>
          <div><dt><Users size={18} /> 活跃主题</dt><dd>{forumPosts.length}</dd></div>
          <div><dt><MessageSquareText size={18} /> 累计回复</dt><dd>{replies}</dd></div>
          <div><dt><Activity size={18} /> 今日在线</dt><dd>{Math.max(24, forumPosts.length * 17)}</dd></div>
        </dl>
      </section>

      <div className="forum-toolbar">
        <SegmentedControl ariaLabel="论坛板块" options={boards} value={activeBoard} onChange={setActiveBoard} className="board-tabs" />
        <label><Search size={16} /><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="搜索讨论" /></label>
      </div>

      <div className="community-layout">
        <section className="community-discussions">
          <header className="community-list-header">
            <div><Flame size={18} /><b>{activeBoard}讨论</b></div>
            <span>优先显示有来源、有上下文和持续回复的主题</span>
          </header>
          <div className="forum-list">
            {visiblePosts.map((post, index) => (
              <article className={`forum-post ${index === 0 ? "is-featured" : ""}`} key={post.id}>
                <div className="forum-post__avatar">{post.author.slice(0, 1).toLocaleUpperCase()}</div>
                <div className="forum-post__content">
                  <div className="content-card__meta">
                    <span className="source-badge">{post.board}</span>
                    {index === 0 && <span className="forum-featured-badge">社区精选</span>}
                    <span>{post.author}</span>
                    <time>{new Date(post.createdAt).toLocaleDateString("zh-CN")}</time>
                  </div>
                  <h2>{post.title}</h2>
                  <p>{post.body}</p>
                  <footer>
                    <button onClick={() => markHelpful(post.id)}><ThumbsUp size={15} /> {post.helpful} 有帮助</button>
                    <span>{post.replies} 条回复</span>
                    <button onClick={() => setReported(post.id)}><Flag size={15} /> 举报</button>
                  </footer>
                </div>
                <div className="forum-post__activity">
                  <b>{post.replies}</b><span>回复</span>
                  <small>{post.helpful} 赞同</small>
                </div>
              </article>
            ))}
          </div>
          {visiblePosts.length === 0 && <div className="empty-panel">当前筛选下没有主题。调整关键词，或发起一条有上下文的新讨论。</div>}
        </section>
        <aside className="community-rail">
          <section>
            <h2><ShieldCheck size={17} /> 社区讨论原则</h2>
            <ol>
              <li>事实判断尽量附上来源与发布日期。</li>
              <li>涉及剧情时标注作品进度和剧透范围。</li>
              <li>评价作品，不攻击创作者或其他用户。</li>
              <li>二创内容说明素材归属和 AI 辅助程度。</li>
            </ol>
          </section>
          <section>
            <h2>热门板块</h2>
            {boards.slice(1).map((name, index) => (
              <button key={name} onClick={() => setActiveBoard(name)}>
                <span>{String(index + 1).padStart(2, "0")}</span><b>{name}</b>
              </button>
            ))}
          </section>
        </aside>
      </div>

      {composer && (
        <Modal title="发起社区讨论" onClose={() => setComposer(false)}>
          <form className="stack-form" onSubmit={submit}>
            <label>板块<select value={board} onChange={(event) => setBoard(event.target.value)}>{boards.map((name) => <option key={name}>{name}</option>)}</select></label>
            <label>标题<input value={title} onChange={(event) => setTitle(event.target.value)} required /></label>
            <label>正文<textarea value={body} onChange={(event) => setBody(event.target.value)} required rows={7} placeholder="说明讨论背景、你的判断和可核验来源。" /></label>
            <div className="form-actions">
              <button type="button" className="secondary-button" onClick={() => setComposer(false)}>取消</button>
              <button className="primary-button">发布主题</button>
            </div>
          </form>
        </Modal>
      )}
      {reported && (
        <Modal title="举报已受理" onClose={() => setReported(undefined)}>
          <p>举报已进入处理队列。正式服务会显示受理、处理中和已完成状态，并保护双方隐私。</p>
          <button className="primary-button" onClick={() => setReported(undefined)}>知道了</button>
        </Modal>
      )}
    </div>
  );
}
