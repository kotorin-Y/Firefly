import {
  randomBytes,
  scrypt as scryptCallback,
  timingSafeEqual
} from "node:crypto";
import { promisify } from "node:util";
import type { RegistrationInput } from "../../src/shared/contracts.js";

const scrypt = promisify(scryptCallback);

export interface PasswordCredential {
  salt: string;
  hash: string;
}

export type RegistrationErrors = Partial<Record<keyof RegistrationInput, string>>;

export function validateRegistration(input: RegistrationInput): RegistrationErrors {
  const errors: RegistrationErrors = {};
  if (!input.displayName.trim()) errors.displayName = "请输入昵称";
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(input.email.trim())) {
    errors.email = "请输入有效邮箱";
  }
  if (input.password.length < 8 || !/[A-Za-z]/.test(input.password) || !/\d/.test(input.password)) {
    errors.password = "密码至少需要 8 位，并同时包含字母和数字";
  }
  if (input.password !== input.confirmPassword) {
    errors.confirmPassword = "两次输入的密码不一致";
  }
  if (!input.acceptedTerms) {
    errors.acceptedTerms = "请先同意服务条款与隐私说明";
  }
  return errors;
}

export async function hashPassword(password: string): Promise<PasswordCredential> {
  const salt = randomBytes(16);
  const derived = await scrypt(password, salt, 64) as Buffer;
  return {
    salt: salt.toString("base64"),
    hash: derived.toString("base64")
  };
}

export async function verifyPassword(
  password: string,
  credential: PasswordCredential
): Promise<boolean> {
  const expected = Buffer.from(credential.hash, "base64");
  const derived = await scrypt(password, Buffer.from(credential.salt, "base64"), expected.length) as Buffer;
  return expected.length === derived.length && timingSafeEqual(expected, derived);
}
