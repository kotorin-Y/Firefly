import { useQuery } from "@tanstack/react-query";
import {
  ArrowLeft,
  Bookmark,
  ExternalLink,
  Languages,
  MessageCircle,
  ShieldCheck
} from "lucide-react";
import { useLocation, useNavigate } from "react-router-dom";
import type { ContentItem } from "../shared/contracts";
import { useAppStore } from "../state/useAppStore";

export function ArticlePage() {
  const navigate = useNavigate();
  const item = (useLocation().state as ContentItem | null) ?? null;
  const { favorites, toggleFavorite } = useAppStore();
  const article = useQuery({
    queryKey: ["article", item?.id],
    queryFn: () => window.fancy.article.read(item!),
    enabled: Boolean(item),
    retry: 1
  });

  if (!item) {
    return (
      <div className="page article-page">
        <div className="error-panel">
          当前文章上下文已经失效。请返回资讯流重新打开，来源链接和收藏记录不会受影响。
        </div>
        <button className="secondary-button" onClick={() => navigate(-1)}>
          <ArrowLeft size={16} /> 返回
        </button>
      </div>
    );
  }

  const document = article.data;
  const isFavorite = favorites.some((entry) => entry.id === item.id);
  return (
    <div className="page article-page">
      <header className="article-toolbar">
        <button className="secondary-button" onClick={() => navigate(-1)}>
          <ArrowLeft size={16} /> 返回资讯流
        </button>
        <div>
          <button onClick={() => toggleFavorite(item)} className={isFavorite ? "is-active" : ""}>
            <Bookmark size={16} fill={isFavorite ? "currentColor" : "none"} />
            {isFavorite ? "已收藏" : "收藏"}
          </button>
          <button onClick={() => navigate("/forum", { state: { subject: item.title } })}>
            <MessageCircle size={16} /> 参与讨论
          </button>
          <button onClick={() => void window.fancy.shell.openExternal(item.url)}>
            <ExternalLink size={16} /> 核验来源
          </button>
        </div>
      </header>

      {article.isLoading && (
        <div className="article-skeleton" aria-label="正在整理文章">
          <span /><span /><span /><span />
        </div>
      )}
      {article.isError && (
        <div className="error-panel">
          暂时无法读取来源正文。你仍可核验原始来源，或稍后重试站内整理。
          <button className="secondary-button" onClick={() => void article.refetch()}>重新整理</button>
        </div>
      )}
      {document && (
        <article className="editorial-article">
          {document.heroImageUrl && (
            <figure>
              <img
                src={document.heroImageUrl}
                alt={document.title}
                onError={(event) => { event.currentTarget.hidden = true; }}
              />
            </figure>
          )}
          <div className="editorial-article__header">
            <div className="content-card__meta">
              <span className="source-badge">{document.sourceLabel || item.providerLabel}</span>
              {document.translated && <span className="translation-badge"><Languages size={12} /> 已翻译整理</span>}
              <time>{new Date(document.publishedAt || item.publishedAt).toLocaleString("zh-CN")}</time>
            </div>
            <h1>{document.title}</h1>
            <p className="article-deck">{document.summary}</p>
            <div className="article-byline">
              <ShieldCheck size={15} />
              Fancy! 编辑整理 · {document.author || item.author || document.sourceLabel || item.providerLabel}
            </div>
          </div>

          {document.keyPoints.length > 0 && (
            <aside className="article-key-points">
              <span>快速了解</span>
              <ul>{document.keyPoints.map((point, index) => <li key={`${index}-${point}`}>{point}</li>)}</ul>
            </aside>
          )}

          <div className="article-body">
            {(document.paragraphs.length ? document.paragraphs : [document.summary])
              .map((paragraph, index) => <p key={`${index}-${paragraph}`}>{paragraph}</p>)}
          </div>

          <footer className="article-source-note">
            <b>来源与编辑说明</b>
            <p>
              本页为便于阅读的翻译与结构化整理，不替代原作者全文。事实、图片与发布日期以
              <button onClick={() => void window.fancy.shell.openExternal(item.url)}>原始来源</button>
              为准。
            </p>
          </footer>
        </article>
      )}
    </div>
  );
}
