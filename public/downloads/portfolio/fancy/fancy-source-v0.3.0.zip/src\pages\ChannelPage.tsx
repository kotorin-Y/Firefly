import { useQuery } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import { useParams } from "react-router-dom";
import { ContentCard } from "../components/ContentCard";
import { ChannelSpotlight } from "../components/ChannelSpotlight";
import { SegmentedControl } from "../components/SegmentedControl";
import type { ContentCategory, ContentItem } from "../shared/contracts";

const names: Record<string, string> = {
  all: "全部资讯",
  anime: "动画",
  manga: "漫画",
  game: "游戏",
  novel: "轻小说"
};

const modes = ["最新", "编辑精选", "热议", "日历"] as const;
type ChannelMode = typeof modes[number];

function sortItems(items: ContentItem[], mode: ChannelMode): ContentItem[] {
  const copy = [...items];
  if (mode === "热议") {
    return copy.sort((a, b) =>
      ((b.viewCount ?? 0) + (b.likeCount ?? 0) * 4) -
      ((a.viewCount ?? 0) + (a.likeCount ?? 0) * 4)
    );
  }
  if (mode === "编辑精选") {
    return copy.sort((a, b) =>
      (Number(Boolean(b.imageUrl)) + Number(Boolean(b.summary)) + b.tags.length / 10) -
      (Number(Boolean(a.imageUrl)) + Number(Boolean(a.summary)) + a.tags.length / 10)
    );
  }
  return copy.sort((a, b) =>
    new Date(b.publishedAt).getTime() - new Date(a.publishedAt).getTime()
  );
}

export function ChannelPage() {
  const { category = "all" } = useParams();
  const [mode, setMode] = useState<ChannelMode>("最新");
  const feed = useQuery({
    queryKey: ["feed", category],
    queryFn: () => window.fancy.feed.list({
      category: category as ContentCategory | "all",
      limit: 30
    })
  });
  const items = useMemo(() => {
    const source = feed.data?.items ?? [];
    const exact = category === "all"
      ? source
      : source.filter((item) => item.category === category);
    return sortItems(exact, mode);
  }, [category, feed.data?.items, mode]);
  return (
    <div className="page">
      <ChannelSpotlight items={items} channelName={names[category] || category} />
      <SegmentedControl ariaLabel="频道浏览方式" options={modes} value={mode} onChange={setMode} className="channel-tabs" />
      {mode === "日历" && <div className="mode-note">按发布时间排列，方便查看近期播出、发售和版本更新节点。</div>}
      <div className="content-list content-list--wide">
        {items.map((item) => <ContentCard key={item.id} item={item} />)}
      </div>
      {feed.isLoading && <div className="feed-loading">正在加载频道内容…</div>}
      {feed.isError && <div className="error-panel">频道来源暂时不可用，请稍后重试。</div>}
      {!feed.isLoading && !feed.isError && items.length === 0 && <div className="empty-panel">当前浏览方式下暂无可展示内容。</div>}
    </div>
  );
}
