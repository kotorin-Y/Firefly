import { describe, expect, it, vi } from "vitest";
import { TranslationService } from "./translation-service";

describe("TranslationService", () => {
  it("skips simplified Chinese content", async () => {
    const request = vi.fn();
    const service = new TranslationService(request);
    const result = await service.translateItem({
      id: "cn",
      provider: "cn",
      providerLabel: "中文",
      kind: "article",
      category: "game",
      title: "国产游戏资讯",
      summary: "保持原文",
      url: "https://example.com/cn",
      publishedAt: "2026-06-23T00:00:00.000Z",
      tags: [],
      sourceLanguage: "zh-CN"
    });
    expect(request).not.toHaveBeenCalled();
    expect(result.translated).not.toBe(true);
  });

  it("translates foreign title and summary while preserving originals", async () => {
    const request = vi.fn().mockResolvedValue("中文标题\n[[FANCY_BREAK]]\n中文摘要");
    const service = new TranslationService(request);
    const result = await service.translateItem({
      id: "en",
      provider: "en",
      providerLabel: "English",
      kind: "article",
      category: "game",
      title: "English title",
      summary: "English summary",
      url: "https://example.com/en",
      publishedAt: "2026-06-23T00:00:00.000Z",
      tags: [],
      sourceLanguage: "en"
    });
    expect(result.title).toBe("中文标题");
    expect(result.summary).toBe("中文摘要");
    expect(result.originalTitle).toBe("English title");
    expect(result.translated).toBe(true);
  });

  it("caches successful translations and falls back to the original on failure", async () => {
    const request = vi.fn()
      .mockResolvedValueOnce("译文\n[[FANCY_BREAK]]\n摘要")
      .mockRejectedValueOnce(new Error("offline"));
    const service = new TranslationService(request);
    const base = {
      id: "a",
      provider: "en",
      providerLabel: "English",
      kind: "article" as const,
      category: "game" as const,
      title: "Title",
      summary: "Summary",
      url: "https://example.com/a",
      publishedAt: "2026-06-23T00:00:00.000Z",
      tags: [],
      sourceLanguage: "en" as const
    };
    await service.translateItem(base);
    await service.translateItem({ ...base, id: "b" });
    expect(request).toHaveBeenCalledTimes(1);

    const failed = await service.translateItem({ ...base, id: "c", title: "Other" });
    expect(failed.title).toBe("Other");
    expect(failed.translated).not.toBe(true);
  });
});
