import { ArrowRight, ChevronLeft, ChevronRight } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import type { ContentItem } from "../shared/contracts";

export function ChannelSpotlight({
  items,
  channelName
}: {
  items: ContentItem[];
  channelName: string;
}) {
  const navigate = useNavigate();
  const slides = useMemo(
    () => items.filter((item) => Boolean(item.imageUrl)).slice(0, 6),
    [items]
  );
  const [index, setIndex] = useState(0);
  const [paused, setPaused] = useState(false);

  useEffect(() => {
    if (slides.length < 2 || paused || matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    const timer = window.setInterval(() => setIndex((value) => (value + 1) % slides.length), 5_500);
    return () => window.clearInterval(timer);
  }, [paused, slides.length]);

  useEffect(() => {
    if (index >= slides.length) setIndex(0);
  }, [index, slides.length]);

  const active = slides[index] || items[0];
  if (!active) {
    return (
      <section className="channel-spotlight channel-spotlight--empty">
        <span>{channelName}</span>
        <h1>正在整理本频道热点</h1>
        <p>来源返回后，最新的重要信息会在这里形成可自动浏览的预览。</p>
      </section>
    );
  }

  const open = () => navigate(
    active.bvid ? `/video/bilibili/${active.bvid}` : `/article/${encodeURIComponent(active.id)}`,
    { state: active }
  );
  const move = (direction: number) => setIndex((value) =>
    (value + direction + Math.max(slides.length, 1)) % Math.max(slides.length, 1)
  );

  return (
    <section
      className="channel-spotlight"
      onPointerEnter={() => setPaused(true)}
      onPointerLeave={() => setPaused(false)}
    >
      <div className="channel-spotlight__media">
        <img
          key={active.id}
          src={active.imageUrl || "./assets/default-cover.png"}
          alt=""
          onError={(event) => { event.currentTarget.src = "./assets/default-cover.png"; }}
        />
      </div>
      <div className="channel-spotlight__scrim" />
      <div className="channel-spotlight__content">
        <span>{channelName} · 当前热点</span>
        <h1>{active.title}</h1>
        <p>{active.summary}</p>
        <div>
          <button className="hero-link" onClick={open}>阅读整理版 <ArrowRight size={16} /></button>
          <small>{active.providerLabel} · {new Date(active.publishedAt).toLocaleDateString("zh-CN")}</small>
        </div>
      </div>
      {slides.length > 1 && (
        <div className="channel-spotlight__controls">
          <button onClick={() => move(-1)} aria-label="上一条热点"><ChevronLeft size={18} /></button>
          <span>{index + 1} / {slides.length}</span>
          <button onClick={() => move(1)} aria-label="下一条热点"><ChevronRight size={18} /></button>
        </div>
      )}
    </section>
  );
}
