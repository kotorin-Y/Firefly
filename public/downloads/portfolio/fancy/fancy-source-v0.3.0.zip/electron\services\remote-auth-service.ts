import type {
  LoginInput,
  PublicAccount,
  RegistrationInput
} from "../../src/shared/contracts.js";

type Request = (input: string, init?: RequestInit) => Promise<Response>;

export interface RemoteAuthSession {
  account: PublicAccount;
  accessToken: string;
}

export class RemoteAuthClient {
  private baseUrl: string;

  constructor(
    baseUrl: string,
    private request: Request = (input, init) => fetch(input, init)
  ) {
    const parsed = new URL(baseUrl);
    const localDevelopment = ["localhost", "127.0.0.1", "::1"].includes(parsed.hostname);
    if (parsed.protocol !== "https:" && !(localDevelopment && parsed.protocol === "http:")) {
      throw new Error("公网账户服务必须使用 HTTPS");
    }
    if (parsed.username || parsed.password) throw new Error("账户服务地址不得包含凭据");
    this.baseUrl = parsed.toString().replace(/\/+$/, "");
  }

  login(input: LoginInput): Promise<RemoteAuthSession> {
    return this.send("/login", input);
  }

  register(input: RegistrationInput): Promise<RemoteAuthSession> {
    return this.send("/register", input);
  }

  restore(accessToken: string): Promise<RemoteAuthSession> {
    return this.send("/session", undefined, accessToken);
  }

  async logout(accessToken: string): Promise<void> {
    await this.send("/logout", undefined, accessToken, true);
  }

  private async send(
    path: string,
    body?: LoginInput | RegistrationInput,
    accessToken?: string,
    allowEmpty = false
  ): Promise<RemoteAuthSession> {
    const response = await this.request(`${this.baseUrl}${path}`, {
      method: "POST",
      signal: AbortSignal.timeout(8_000),
      headers: {
        "Content-Type": "application/json",
        ...(accessToken ? { Authorization: `Bearer ${accessToken}` } : {})
      },
      body: body ? JSON.stringify(body) : undefined
    });
    const payload = await response.json().catch(() => ({})) as Partial<RemoteAuthSession> & { message?: string };
    if (!response.ok) throw new Error(payload.message || `账户服务 HTTP ${response.status}`);
    if (allowEmpty) return payload as RemoteAuthSession;
    if (!payload.account || !payload.accessToken) throw new Error("账户服务响应不完整");
    return payload as RemoteAuthSession;
  }
}
