import { SwatchBook } from "lucide-react";
import { THEMES } from "../config/themes";
import type { ThemeId } from "../shared/contracts";

interface ThemePickerProps {
  value: ThemeId;
  onChange: (themeId: ThemeId) => void;
}

export function ThemePicker({ value, onChange }: ThemePickerProps) {
  return (
    <section className="settings-section theme-settings">
      <div>
        <span className="eyebrow"><SwatchBook size={14} /> 外观</span>
        <h2>主题切换</h2>
      </div>
      <div className="theme-grid">
        {THEMES.map((theme) => (
          <article className={`theme-card ${value === theme.id ? "is-active" : ""}`} key={theme.id}>
            <button
              type="button"
              className="theme-card__select"
              aria-pressed={value === theme.id}
              onClick={() => onChange(theme.id)}
            >
              <span className="theme-swatches">
                <i style={{ background: theme.colors[0] }} />
                <i style={{ background: theme.colors[1] }} />
              </span>
              <span>
                <b>{theme.name}</b>
              </span>
            </button>
          </article>
        ))}
      </div>
    </section>
  );
}
