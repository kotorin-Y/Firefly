import { create } from "zustand";
import { persist } from "zustand/middleware";
import type {
  ContentItem,
  PublicAccount,
  ThemeId,
  UserPreferences
} from "../shared/contracts";
import { DEFAULT_THEME_ID } from "../config/themes";
import { BRAND } from "../config/brand";

export interface ForumPost {
  id: string;
  title: string;
  body: string;
  author: string;
  board: string;
  replies: number;
  helpful: number;
  createdAt: string;
}

interface AppState {
  preferences: UserPreferences;
  favorites: ContentItem[];
  history: ContentItem[];
  forumPosts: ForumPost[];
  account: PublicAccount | null;
  authModalMode: "login" | "register" | null;
  setPreferences: (preferences: UserPreferences) => void;
  setTheme: (themeId: ThemeId) => void;
  setAccount: (account: PublicAccount | null) => void;
  openAuthModal: (mode?: "login" | "register") => void;
  closeAuthModal: () => void;
  toggleFavorite: (item: ContentItem) => void;
  addHistory: (item: ContentItem) => void;
  addForumPost: (post: Omit<ForumPost, "id" | "createdAt" | "replies" | "helpful">) => void;
  markHelpful: (id: string) => void;
}

const defaultPreferences: UserPreferences = {
  personalized: true,
  interests: ["anime", "game", "community"],
  blockedProviders: [],
  blockedKeywords: [],
  seenIds: []
  ,
  themeId: DEFAULT_THEME_ID
};

const seedPosts: ForumPost[] = [
  {
    id: "version-2",
    title: "【版本专楼】本周 ACGN 新作与版本更新集中讨论",
    body: "欢迎补充官方来源、试玩体验和无剧透建议。数据结论请尽量附上出处。",
    author: "Fancy! 编辑部",
    board: "综合情报",
    replies: 286,
    helpful: 96,
    createdAt: new Date(Date.now() - 3_600_000).toISOString()
  },
  {
    id: "summer-anime",
    title: "夏季动画追更计划：你会保留哪几部？",
    body: "请使用集数进度标记剧透。欢迎分享制作团队、演出和音乐方面的观察。",
    author: "弦月记录",
    board: "动画",
    replies: 142,
    helpful: 58,
    createdAt: new Date(Date.now() - 8_000_000).toISOString()
  }
];

if (!localStorage.getItem(BRAND.storageKey) && localStorage.getItem(BRAND.legacyStorageKey)) {
  localStorage.setItem(BRAND.storageKey, localStorage.getItem(BRAND.legacyStorageKey)!);
}

export const useAppStore = create<AppState>()(
  persist(
    (set, get) => ({
      preferences: defaultPreferences,
      favorites: [],
      history: [],
      forumPosts: seedPosts,
      account: null,
      authModalMode: null,
      setPreferences: (preferences) => set({ preferences }),
      setTheme: (themeId) => set({
        preferences: { ...get().preferences, themeId }
      }),
      setAccount: (account) => set({ account }),
      openAuthModal: (mode = "login") => set({ authModalMode: mode }),
      closeAuthModal: () => set({ authModalMode: null }),
      toggleFavorite: (item) => {
        const exists = get().favorites.some((entry) => entry.id === item.id);
        set({
          favorites: exists
            ? get().favorites.filter((entry) => entry.id !== item.id)
            : [item, ...get().favorites]
        });
      },
      addHistory: (item) => set({
        history: [item, ...get().history.filter((entry) => entry.id !== item.id)].slice(0, 100)
      }),
      addForumPost: (post) => set({
        forumPosts: [{
          ...post,
          id: crypto.randomUUID(),
          createdAt: new Date().toISOString(),
          replies: 0,
          helpful: 0
        }, ...get().forumPosts]
      }),
      markHelpful: (id) => set({
        forumPosts: get().forumPosts.map((post) =>
          post.id === id ? { ...post, helpful: post.helpful + 1 } : post
        )
      })
    }),
    { name: BRAND.storageKey }
  )
);
