export function mergeSearchQueryParams(
  current: URLSearchParams,
  query: string
): URLSearchParams {
  const next = new URLSearchParams(current);
  next.set("q", query.trim());
  return next;
}
