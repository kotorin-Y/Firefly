import { createServer } from "node:net";

function portAvailable(port) {
  return new Promise((resolve) => {
    const server = createServer();
    server.unref();
    server.once("error", () => resolve(false));
    server.listen(port, "127.0.0.1", () => {
      server.close(() => resolve(true));
    });
  });
}

export async function findAvailablePort(startPort = 5173, attempts = 30) {
  for (let offset = 0; offset < attempts; offset += 1) {
    const port = startPort + offset;
    if (await portAvailable(port)) return port;
  }
  throw new Error(`No available development port in ${startPort}-${startPort + attempts - 1}`);
}
