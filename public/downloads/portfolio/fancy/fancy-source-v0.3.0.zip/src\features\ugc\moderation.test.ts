import { describe, expect, it } from "vitest";
import type { UgcDraft } from "../../shared/contracts";
import { moderateDraft } from "./moderation";

const draft = (body: string): UgcDraft => ({
  id: "draft",
  title: "创作标题",
  body,
  category: "anime",
  contentType: "article",
  relatedIp: "测试作品",
  ownership: "original",
  license: "attribution",
  spoilerLevel: "none",
  aiAssistance: "none",
  status: "draft",
  createdAt: new Date().toISOString(),
  updatedAt: new Date().toISOString()
});

describe("moderateDraft", () => {
  it("publishes normal original text", () => {
    expect(moderateDraft(draft("这是一篇关于镜头语言与角色成长的长评。")).action).toBe("publish");
  });

  it("requires review for external links", () => {
    const result = moderateDraft(draft("素材见 https://example.com/source"));
    expect(result.action).toBe("review");
    expect(result.reasons).toContain("包含外部链接");
  });

  it("blocks privacy doxxing language", () => {
    const result = moderateDraft(draft("公开他的手机号和家庭住址"));
    expect(result.action).toBe("block");
    expect(result.risk).toBe("L3");
  });
});
