import { FormEvent, useEffect, useRef, useState } from "react";
import { Search, ShieldCheck, Sparkles } from "lucide-react";
import { useNavigate } from "react-router-dom";

const modes = [
  ["all", "综合检索"],
  ["official", "官方优先"],
  ["community", "社区优先"]
] as const;

export function SearchCommand() {
  const navigate = useNavigate();
  const root = useRef<HTMLDivElement>(null);
  const [query, setQuery] = useState("");
  const [open, setOpen] = useState(false);
  const [mode, setMode] = useState<(typeof modes)[number][0]>("all");
  const [spoilerSafe, setSpoilerSafe] = useState(true);
  const [translate, setTranslate] = useState(true);

  useEffect(() => {
    const close = (event: PointerEvent) => {
      if (!root.current?.contains(event.target as Node)) setOpen(false);
    };
    document.addEventListener("pointerdown", close);
    return () => document.removeEventListener("pointerdown", close);
  }, []);

  const runSearch = () => {
    if (!query.trim()) return;
    const params = new URLSearchParams({
      q: query.trim(),
      mode,
      spoiler: spoilerSafe ? "safe" : "all",
      translate: translate ? "1" : "0"
    });
    setOpen(false);
    navigate(`/search?${params.toString()}`);
  };
  const submit = (event: FormEvent) => {
    event.preventDefault();
    runSearch();
  };

  return (
    <div className={`search-command ${open ? "is-open" : ""}`} ref={root}>
      <form className="global-search" onSubmit={submit}>
        <Search size={17} aria-hidden="true" />
        <input
          value={query}
          onFocus={() => setOpen(true)}
          onChange={(event) => setQuery(event.target.value)}
          onKeyDown={(event) => {
            if (event.key !== "Enter" || event.nativeEvent.isComposing) return;
            event.preventDefault();
            runSearch();
          }}
          placeholder="搜索作品、版本、创作者，或直接提问"
          aria-label="全局搜索"
          aria-expanded={open}
        />
        <button
          type="button"
          className="ai-star"
          onClick={() => setOpen((value) => !value)}
          aria-label="AI 搜索设置"
          aria-expanded={open}
        >
          <Sparkles size={18} fill="currentColor" />
        </button>
      </form>
      {open && (
        <section className="search-command__panel" aria-label="搜索设置">
          <header>
            <div><Sparkles size={17} /><b>智能检索设置</b></div>
            <span>先检索来源，再组织答案</span>
          </header>
          <div className="search-mode-grid">
            {modes.map(([value, label]) => (
              <button
                type="button"
                key={value}
                className={mode === value ? "is-active" : ""}
                onClick={() => setMode(value)}
              >
                {label}
              </button>
            ))}
          </div>
          <label>
            <span><ShieldCheck size={16} /> 无剧透保护</span>
            <input type="checkbox" checked={spoilerSafe} onChange={(event) => setSpoilerSafe(event.target.checked)} />
          </label>
          <label>
            <span>海外内容自动翻译为简体中文</span>
            <input type="checkbox" checked={translate} onChange={(event) => setTranslate(event.target.checked)} />
          </label>
          <button className="primary-button" onClick={() => {
            if (query.trim()) runSearch();
            else navigate("/search");
          }}>
            打开完整搜索
          </button>
        </section>
      )}
    </div>
  );
}
