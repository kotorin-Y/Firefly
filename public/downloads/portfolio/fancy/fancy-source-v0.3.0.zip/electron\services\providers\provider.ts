import type {
  ContentCategory,
  ContentItem,
  FeedQuery
} from "../../../src/shared/contracts.js";
import { classifyContent } from "../../../src/features/feed/classification.js";

export interface ContentProvider {
  id: string;
  label: string;
  categories: readonly ContentCategory[];
  list(query: FeedQuery): Promise<ContentItem[]>;
  search(query: string): Promise<ContentItem[]>;
}

export async function fetchWithTimeout(
  url: string,
  init: RequestInit = {},
  timeoutMs = 8_000
): Promise<Response> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fetch(url, {
      ...init,
      signal: controller.signal,
      headers: {
        "User-Agent": "FancyACGN/0.1 Desktop Reader",
        Accept: "application/json, application/rss+xml, application/xml, text/xml, */*",
        ...init.headers
      }
    });
  } finally {
    clearTimeout(timer);
  }
}

export function stripHtml(value = ""): string {
  return value
    .replace(/<script[\s\S]*?<\/script>/gi, "")
    .replace(/<style[\s\S]*?<\/style>/gi, "")
    .replace(/<[^>]+>/g, " ")
    .replace(/&nbsp;/g, " ")
    .replace(/&amp;/g, "&")
    .replace(/&#39;/g, "'")
    .replace(/&quot;/g, '"')
    .replace(/\s+/g, " ")
    .trim();
}

export function secureMediaUrl(value?: string): string | undefined {
  if (!value) return undefined;
  if (value.startsWith("//")) return `https:${value}`;
  if (value.startsWith("http://")) return `https://${value.slice(7)}`;
  return value;
}

export function classifyText(value: string): ContentCategory {
  return classifyContent({ title: value }).category;
}
