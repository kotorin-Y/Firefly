import type { CheckinState } from "../../shared/contracts.js";

function localDate(date = new Date()): string {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

function dayDistance(from: string, to: string): number {
  const start = new Date(`${from}T12:00:00`);
  const end = new Date(`${to}T12:00:00`);
  return Math.round((end.getTime() - start.getTime()) / 86_400_000);
}

export function normalizeCheckin(state: CheckinState): CheckinState {
  const today = localDate();
  return {
    ...state,
    claimedToday: state.lastClaimDate === today,
    rewardToday: Math.min(30, 10 + Math.max(0, state.streak - 1) * 2)
  };
}

export function claimCheckin(state: CheckinState): CheckinState {
  const today = localDate();
  if (state.lastClaimDate === today) {
    throw new Error("今天已经签到");
  }

  const isConsecutive = state.lastClaimDate
    ? dayDistance(state.lastClaimDate, today) === 1
    : false;
  const streak = isConsecutive ? state.streak + 1 : 1;
  const reward = Math.min(30, 10 + (streak - 1) * 2);

  return {
    lastClaimDate: today,
    streak,
    points: state.points + reward,
    claimedToday: true,
    rewardToday: reward
  };
}
