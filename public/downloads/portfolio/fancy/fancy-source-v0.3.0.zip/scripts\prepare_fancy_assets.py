from __future__ import annotations

from pathlib import Path

from PIL import Image, ImageChops


ROOT = Path(__file__).resolve().parents[2]
APP = Path(__file__).resolve().parents[1]
SOURCE_DIR = ROOT / "outputs" / "logos" / "fancy" / "generated"
PUBLIC_DIR = APP / "public" / "assets"
BUILD_DIR = APP / "build"

PALETTE = (
    (116, 69, 119),
    (240, 233, 182),
)

SOURCES = {
    "page-exclamation": "page-exclamation-source.png",
    "editorial-spark": "editorial-spark-source.png",
    "speech-bloom": "speech-bloom-source.png",
    "origami-comet": "origami-comet-source.png",
}


def nearest_palette(rgb: tuple[int, int, int]) -> tuple[int, int, int]:
    return min(
        PALETTE,
        key=lambda candidate: sum((channel - target) ** 2 for channel, target in zip(rgb, candidate)),
    )


def flatten_logo(source: Path, output: Path, size: int = 1024) -> Image.Image:
    image = Image.open(source).convert("RGB")
    working = image.resize((2048, 2048), Image.Resampling.LANCZOS)
    pixels = working.load()

    for y in range(working.height):
        for x in range(working.width):
            red, green, blue = pixels[x, y]
            if red > 244 and green > 244 and blue > 244:
                pixels[x, y] = (255, 255, 255)
            else:
                pixels[x, y] = nearest_palette((red, green, blue))

    background = Image.new("RGB", working.size, "white")
    difference = ImageChops.difference(working, background).convert("L")
    bbox = difference.point(lambda value: 255 if value > 4 else 0).getbbox()
    if not bbox:
        raise ValueError(f"No visible logo content in {source}")

    cropped = working.crop(bbox)
    target = int(size * 0.76)
    cropped.thumbnail((target, target), Image.Resampling.LANCZOS)
    cropped_rgba = cropped.convert("RGBA")
    rgba_pixels = cropped_rgba.load()
    for y in range(cropped_rgba.height):
        for x in range(cropped_rgba.width):
            red, green, blue, _alpha = rgba_pixels[x, y]
            distance_from_white = max(255 - red, 255 - green, 255 - blue)
            if distance_from_white < 5:
                rgba_pixels[x, y] = (255, 255, 255, 0)
            else:
                brand_color = nearest_palette((red, green, blue))
                rgba_pixels[x, y] = (*brand_color, min(255, distance_from_white * 4))

    canvas = Image.new("RGBA", (size, size), (255, 255, 255, 0))
    x = (size - cropped.width) // 2
    y = (size - cropped.height) // 2
    canvas.alpha_composite(cropped_rgba, (x, y))
    output.parent.mkdir(parents=True, exist_ok=True)
    canvas.save(output)
    return canvas


def build_icons(logo: Image.Image) -> None:
    BUILD_DIR.mkdir(parents=True, exist_ok=True)
    icon_background = Image.new("RGBA", logo.size, (240, 233, 182, 255))
    icon_background.alpha_composite(logo)
    icon_background.save(
        BUILD_DIR / "icon.ico",
        sizes=[(16, 16), (24, 24), (32, 32), (48, 48), (64, 64), (128, 128), (256, 256)],
    )
    icon_background.save(
        BUILD_DIR / "icon.icns",
        append_images=[
            icon_background.resize((16, 16), Image.Resampling.LANCZOS),
            icon_background.resize((32, 32), Image.Resampling.LANCZOS),
            icon_background.resize((64, 64), Image.Resampling.LANCZOS),
            icon_background.resize((128, 128), Image.Resampling.LANCZOS),
            icon_background.resize((256, 256), Image.Resampling.LANCZOS),
            icon_background.resize((512, 512), Image.Resampling.LANCZOS),
            icon_background.resize((1024, 1024), Image.Resampling.LANCZOS),
        ],
    )


def main() -> None:
    flattened: dict[str, Image.Image] = {}
    for route, filename in SOURCES.items():
        flattened[route] = flatten_logo(
            SOURCE_DIR / filename,
            SOURCE_DIR / f"{route}.png",
        )

    selected = flattened["editorial-spark"]
    PUBLIC_DIR.mkdir(parents=True, exist_ok=True)
    selected.save(PUBLIC_DIR / "fancy-logo.png")
    selected.resize((256, 256), Image.Resampling.LANCZOS).save(PUBLIC_DIR / "fancy-logo-256.png")
    selected.resize((64, 64), Image.Resampling.LANCZOS).save(PUBLIC_DIR / "fancy-logo-64.png")
    build_icons(selected)

    print(PUBLIC_DIR / "fancy-logo.png")
    print(BUILD_DIR / "icon.ico")
    print(BUILD_DIR / "icon.icns")


if __name__ == "__main__":
    main()
