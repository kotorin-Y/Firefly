import { FormEvent, useEffect, useMemo, useState } from "react";
import {
  AlertTriangle,
  CheckCircle2,
  ChevronDown,
  FilePenLine,
  Heart,
  MessageCircle,
  Send,
  Sparkles
} from "lucide-react";
import type { ContentCategory, UgcDraft } from "../shared/contracts";
import { moderateDraft } from "../features/ugc/moderation";

const empty = (): UgcDraft => ({
  id: crypto.randomUUID(),
  title: "",
  body: "",
  category: "anime",
  contentType: "article",
  relatedIp: "",
  ownership: "original",
  license: "attribution",
  spoilerLevel: "none",
  aiAssistance: "none",
  status: "draft",
  createdAt: new Date().toISOString(),
  updatedAt: new Date().toISOString()
});

function initialDraft(): UgcDraft {
  try {
    const saved = localStorage.getItem("fancy-draft");
    return saved ? { ...empty(), ...JSON.parse(saved) as UgcDraft } : empty();
  } catch {
    return empty();
  }
}

const curated = [
  { id: "curated-1", title: "从镜头语言拆解本季原创动画的城市感", author: "弦月记录", tag: "动画长评", likes: 842, replies: 96 },
  { id: "curated-2", title: "动作游戏 Boss 设计：读招、公平性与重复挑战", author: "第七码头", tag: "游戏设计", likes: 716, replies: 128 },
  { id: "curated-3", title: "轻小说译名考据与不同版本文本差异整理", author: "纸页航线", tag: "文本考据", likes: 531, replies: 74 }
];

export function CreatePage() {
  const [draft, setDraft] = useState(initialDraft);
  const [saved, setSaved] = useState<UgcDraft>();
  const [items, setItems] = useState<UgcDraft[]>([]);
  const [advanced, setAdvanced] = useState(false);
  const [draftMessage, setDraftMessage] = useState("");
  const moderation = useMemo(() => moderateDraft(draft), [draft]);
  const patch = <K extends keyof UgcDraft>(key: K, value: UgcDraft[K]) =>
    setDraft({ ...draft, [key]: value, updatedAt: new Date().toISOString() });

  useEffect(() => { void window.fancy.ugc.list().then(setItems); }, []);

  const submit = async (event: FormEvent) => {
    event.preventDefault();
    const normalized = {
      ...draft,
      relatedIp: draft.relatedIp.trim() || draft.title.trim()
    };
    const result = await window.fancy.ugc.create(normalized);
    setSaved(result);
    setItems((current) => [result, ...current.filter((item) => item.id !== result.id)]);
  };

  return (
    <div className="page creator-square">
      <section className="page-heading">
        <div>
          <span className="eyebrow"><Sparkles size={14} /> 社区优质内容优先</span>
          <h1>共创广场</h1>
          <p>先阅读同好认真完成的作品，再用尽可能轻的步骤发布你的长评、攻略、设定整理或二次创作。</p>
        </div>
      </section>

      <section className="curated-creations">
        {(items.filter((item) => item.status === "published").slice(0, 3).length
          ? items.filter((item) => item.status === "published").slice(0, 3).map((item, index) => ({
            id: item.id,
            title: item.title,
            author: "Fancy! 创作者",
            tag: item.contentType,
            likes: 120 - index * 17,
            replies: 24 - index * 3
          }))
          : curated
        ).map((item, index) => (
          <article key={item.id} className={index === 0 ? "is-primary" : ""}>
            <span>{item.tag}</span>
            <h2>{item.title}</h2>
            <p>{item.author}</p>
            <footer><span><Heart size={15} /> {item.likes}</span><span><MessageCircle size={15} /> {item.replies}</span></footer>
          </article>
        ))}
      </section>

      <section className="quick-publish">
        <header>
          <div><FilePenLine size={19} /><div><h2>快速发布</h2><p>标题、正文和分区是唯一的首屏必填项。</p></div></div>
          <button onClick={() => setAdvanced((value) => !value)} aria-expanded={advanced}>
            高级设置 <ChevronDown size={16} className={advanced ? "rotate" : ""} />
          </button>
        </header>
        <div className="quick-publish__layout">
          <form className="creator-form stack-form" onSubmit={submit}>
            <label>作品标题<input value={draft.title} onChange={(event) => patch("title", event.target.value)} required placeholder="准确说明主题，不用夸张标题替代信息" /></label>
            <label>正文<textarea value={draft.body} onChange={(event) => patch("body", event.target.value)} required rows={9} placeholder="写下你的观察、过程和可核验来源。" /></label>
            <label>分区<select value={draft.category} onChange={(event) => patch("category", event.target.value as ContentCategory)}><option value="anime">动画</option><option value="manga">漫画</option><option value="game">游戏</option><option value="novel">轻小说</option><option value="community">社区</option></select></label>
            {advanced && (
              <div className="form-grid advanced-fields">
                <label>关联 IP<input value={draft.relatedIp} onChange={(event) => patch("relatedIp", event.target.value)} placeholder="留空时使用作品标题" /></label>
                <label>创作属性<select value={draft.ownership} onChange={(event) => patch("ownership", event.target.value as UgcDraft["ownership"])}><option value="original">原创</option><option value="authorized">授权转载</option><option value="curated">引用整理</option></select></label>
                <label>授权方式<select value={draft.license} onChange={(event) => patch("license", event.target.value as UgcDraft["license"])}><option value="no-repost">禁止转载</option><option value="attribution">允许署名转载</option><option value="non-commercial">允许非商业二创</option></select></label>
                <label>剧透范围<select value={draft.spoilerLevel} onChange={(event) => patch("spoilerLevel", event.target.value as UgcDraft["spoilerLevel"])}><option value="none">无剧透</option><option value="light">轻微剧透</option><option value="major">重大剧透</option></select></label>
                <label>AI 辅助<select value={draft.aiAssistance} onChange={(event) => patch("aiAssistance", event.target.value as UgcDraft["aiAssistance"])}><option value="none">未使用</option><option value="proofread">仅校对</option><option value="partial">部分辅助</option><option value="substantial">大量辅助</option></select></label>
              </div>
            )}
            <div className="form-actions">
              <span className="form-status" role="status">{draftMessage}</span>
              <button type="button" className="secondary-button" onClick={() => {
                localStorage.setItem("fancy-draft", JSON.stringify(draft));
                setDraftMessage("草稿已保存在本机");
              }}>保存草稿</button>
              <button type="submit" className="primary-button" disabled={moderation.action === "block"}><Send size={16} /> 提交</button>
            </div>
          </form>
          <aside className="moderation-panel">
            <h2>发布前检查</h2>
            <div className={`moderation-state moderation-state--${moderation.action}`}>
              {moderation.action === "publish" ? <CheckCircle2 /> : <AlertTriangle />}
              <div><b>{moderation.action === "publish" ? "可以提交" : moderation.action === "block" ? "暂不可提交" : "需要人工复核"}</b><span>风险等级 {moderation.risk}</span></div>
            </div>
            {moderation.reasons.map((reason) => <p key={reason}>• {reason}</p>)}
            {moderation.suggestions.map((reason) => <p className="muted" key={reason}>建议：{reason}</p>)}
            {saved && <div className="success-panel"><CheckCircle2 size={18} /><b>{saved.status === "published" ? "发布成功" : "已进入审核"}</b><p>{saved.status === "published" ? "内容已进入共创广场。" : "当前仅自己可见，完成复核后更新状态。"}</p></div>}
          </aside>
        </div>
      </section>
    </div>
  );
}
