import { contextBridge, ipcRenderer } from "electron";
import type {
  BrowserBounds,
  BrowserState,
  ArticleDocument,
  CheckinState,
  FeedQuery,
  FeedResponse,
  AuthState,
  LoginInput,
  RegistrationInput,
  SearchResponse,
  UgcDraft
} from "../src/shared/contracts.js";
import type { StoreKey } from "./services/local-store.js";

const api = {
  feed: {
    list: (query: FeedQuery): Promise<FeedResponse> => ipcRenderer.invoke("feed:list", query),
    search: (query: string): Promise<SearchResponse> => ipcRenderer.invoke("feed:search", query)
  },
  article: {
    read: (item: import("../src/shared/contracts.js").ContentItem): Promise<ArticleDocument> =>
      ipcRenderer.invoke("article:read", item)
  },
  store: {
    get: <T>(key: StoreKey): Promise<T> => ipcRenderer.invoke("store:get", key),
    set: <T>(key: StoreKey, value: T): Promise<T> => ipcRenderer.invoke("store:set", key, value)
  },
  ugc: {
    list: (): Promise<UgcDraft[]> => ipcRenderer.invoke("ugc:list"),
    create: (draft: UgcDraft): Promise<UgcDraft> => ipcRenderer.invoke("ugc:create", draft)
  },
  checkin: {
    status: (): Promise<CheckinState> => ipcRenderer.invoke("checkin:status"),
    claim: (): Promise<CheckinState> => ipcRenderer.invoke("checkin:claim")
  },
  auth: {
    state: (): Promise<AuthState> => ipcRenderer.invoke("auth:state"),
    register: (input: RegistrationInput): Promise<AuthState> => ipcRenderer.invoke("auth:register", input),
    login: (input: LoginInput): Promise<AuthState> => ipcRenderer.invoke("auth:login", input),
    logout: (): Promise<AuthState> => ipcRenderer.invoke("auth:logout")
  },
  browser: {
    open: (url: string, bounds: BrowserBounds) => ipcRenderer.invoke("browser:open", url, bounds),
    setBounds: (bounds: BrowserBounds) => ipcRenderer.invoke("browser:setBounds", bounds),
    navigate: (url: string) => ipcRenderer.invoke("browser:navigate", url),
    back: () => ipcRenderer.invoke("browser:back"),
    forward: () => ipcRenderer.invoke("browser:forward"),
    reload: () => ipcRenderer.invoke("browser:reload"),
    close: () => ipcRenderer.invoke("browser:close"),
    state: (): Promise<BrowserState> => ipcRenderer.invoke("browser:state")
  },
  shell: {
    openExternal: (url: string) => ipcRenderer.invoke("shell:openExternal", url)
  },
  app: {
    info: (): Promise<{ version: string; platform: string }> => ipcRenderer.invoke("app:info")
  }
};

contextBridge.exposeInMainWorld("fancy", api);

export type FancyApi = typeof api;
