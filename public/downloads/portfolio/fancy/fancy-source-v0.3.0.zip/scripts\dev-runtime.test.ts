import { createServer } from "node:net";
import { describe, expect, it } from "vitest";
import { findAvailablePort } from "./dev-runtime.mjs";

describe("findAvailablePort", () => {
  it("skips an occupied port so Vite and Electron cannot attach to a stale server", async () => {
    const server = createServer();
    await new Promise<void>((resolve) => server.listen(0, "127.0.0.1", resolve));
    const occupied = (server.address() as { port: number }).port;

    try {
      const selected = await findAvailablePort(occupied, 10);
      expect(selected).toBeGreaterThan(occupied);
    } finally {
      await new Promise<void>((resolve, reject) => server.close((error) => error ? reject(error) : resolve()));
    }
  });
});
