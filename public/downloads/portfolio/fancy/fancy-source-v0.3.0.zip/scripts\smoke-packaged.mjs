import { _electron as electron } from "playwright-core";
import { spawnSync } from "node:child_process";
import fs from "node:fs/promises";
import path from "node:path";

const root = path.resolve(import.meta.dirname, "..");
const releaseDir = process.env.FANCY_RELEASE_DIR || "release-0.3.0";
const executablePath = path.join(root, releaseDir, "win-unpacked", "Fancy!.exe");
const out = path.join(root, "artifacts", "packaged-smoke");
const userData = path.join(out, "user-data");
await fs.rm(out, { recursive: true, force: true });
await fs.mkdir(userData, { recursive: true });

const app = await electron.launch({
  executablePath,
  cwd: path.dirname(executablePath),
  env: { ...process.env, FANCY_USER_DATA_DIR: userData }
});
const appPid = app.process().pid;
try {
  const page = await app.firstWindow();
  const pageErrors = [];
  page.on("pageerror", (error) => pageErrors.push(error.message));

  await page.setViewportSize({ width: 1440, height: 920 });
  await page.locator(".app-shell").waitFor({ state: "visible", timeout: 30_000 });
  await page.locator(".global-search input").waitFor({ state: "visible" });
  await page.waitForTimeout(3_000);

  const title = await page.title();
  if (title !== "Fancy!") throw new Error(`Unexpected packaged title: ${title}`);
  if (pageErrors.length > 0) throw new Error(`Packaged page errors: ${pageErrors.join(" | ")}`);

  const navCount = await page.locator(".sidebar nav a").count();
  if (navCount < 6) throw new Error(`Only ${navCount} navigation entries rendered`);

  await page.locator(".global-search input").click();
  await page.locator(".search-command__panel").waitFor({ state: "visible" });
  await page.locator(".global-search input").fill("Stellar Blade");
  await page.locator(".global-search input").press("Enter");
  await page.waitForURL(/#\/search\?/);
  await page.locator(".search-hero").waitFor({ state: "visible" });

  await page.screenshot({ path: path.join(out, "01-packaged-search.png"), fullPage: true });
  const report = {
    executablePath,
    title,
    navCount,
    pageErrors,
    url: page.url(),
    checkedAt: new Date().toISOString()
  };
  await fs.writeFile(path.join(out, "report.json"), JSON.stringify(report, null, 2), "utf8");
}
finally {
  await Promise.race([
    app.close(),
    new Promise((resolve) => setTimeout(resolve, 4_000))
  ]);
  if (process.platform === "win32") {
    spawnSync("taskkill", ["/PID", String(appPid), "/T", "/F"], { stdio: "ignore" });
  }
}
