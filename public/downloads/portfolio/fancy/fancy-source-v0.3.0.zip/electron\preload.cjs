const { contextBridge, ipcRenderer } = require("electron");

const api = {
  feed: {
    list: (query) => ipcRenderer.invoke("feed:list", query),
    search: (query) => ipcRenderer.invoke("feed:search", query)
  },
  store: {
    get: (key) => ipcRenderer.invoke("store:get", key),
    set: (key, value) => ipcRenderer.invoke("store:set", key, value)
  },
  ugc: {
    list: () => ipcRenderer.invoke("ugc:list"),
    create: (draft) => ipcRenderer.invoke("ugc:create", draft)
  },
  checkin: {
    status: () => ipcRenderer.invoke("checkin:status"),
    claim: () => ipcRenderer.invoke("checkin:claim")
  },
  auth: {
    state: () => ipcRenderer.invoke("auth:state"),
    register: (input) => ipcRenderer.invoke("auth:register", input),
    login: (input) => ipcRenderer.invoke("auth:login", input),
    logout: () => ipcRenderer.invoke("auth:logout")
  },
  browser: {
    open: (url, bounds) => ipcRenderer.invoke("browser:open", url, bounds),
    setBounds: (bounds) => ipcRenderer.invoke("browser:setBounds", bounds),
    navigate: (url) => ipcRenderer.invoke("browser:navigate", url),
    back: () => ipcRenderer.invoke("browser:back"),
    forward: () => ipcRenderer.invoke("browser:forward"),
    reload: () => ipcRenderer.invoke("browser:reload"),
    close: () => ipcRenderer.invoke("browser:close"),
    state: () => ipcRenderer.invoke("browser:state")
  },
  shell: {
    openExternal: (url) => ipcRenderer.invoke("shell:openExternal", url)
  },
  app: {
    info: () => ipcRenderer.invoke("app:info")
  }
};

contextBridge.exposeInMainWorld("fancy", api);
