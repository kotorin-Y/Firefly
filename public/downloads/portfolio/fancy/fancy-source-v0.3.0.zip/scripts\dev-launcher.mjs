import { spawn } from "node:child_process";
import { createRequire } from "node:module";
import path from "node:path";
import process from "node:process";
import { fileURLToPath } from "node:url";
import { findAvailablePort } from "./dev-runtime.mjs";

const root = path.dirname(path.dirname(fileURLToPath(import.meta.url)));
const require = createRequire(import.meta.url);
const viteBin = path.join(root, "node_modules", "vite", "bin", "vite.js");
const tscBin = path.join(root, "node_modules", "typescript", "bin", "tsc");
const electronPath = require("electron");
const children = new Set();
let stopping = false;

function run(command, args, options = {}) {
  const child = spawn(command, args, {
    cwd: root,
    stdio: "inherit",
    windowsHide: true,
    ...options
  });
  children.add(child);
  child.once("exit", () => children.delete(child));
  return child;
}

function waitForExit(child, label) {
  return new Promise((resolve, reject) => {
    child.once("error", reject);
    child.once("exit", (code) => code === 0
      ? resolve()
      : reject(new Error(`${label} exited with code ${code}`)));
  });
}

async function waitForServer(url, timeoutMs = 30_000) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    try {
      const response = await fetch(url, { signal: AbortSignal.timeout(1_000) });
      if (response.ok) return;
    } catch {
      // The server is still starting.
    }
    await new Promise((resolve) => setTimeout(resolve, 250));
  }
  throw new Error(`Vite did not become ready at ${url}`);
}

function stop(exitCode = 0) {
  if (stopping) return;
  stopping = true;
  for (const child of children) child.kill();
  setTimeout(() => process.exit(exitCode), 120).unref();
}

process.on("SIGINT", () => stop(0));
process.on("SIGTERM", () => stop(0));
process.on("uncaughtException", (error) => {
  console.error(error);
  stop(1);
});

const port = await findAvailablePort(Number(process.env.FANCY_DEV_PORT || 5173));
const devUrl = `http://127.0.0.1:${port}`;
console.log(`[Fancy!] development server: ${devUrl}`);

await waitForExit(
  run(process.execPath, [tscBin, "-p", "tsconfig.electron.json"]),
  "Electron TypeScript build"
);

const vite = run(process.execPath, [
  viteBin,
  "--host", "127.0.0.1",
  "--port", String(port),
  "--strictPort"
]);
vite.once("exit", (code) => {
  if (!stopping) stop(code ?? 1);
});
await waitForServer(devUrl);

const electron = run(electronPath, ["."], {
  env: { ...process.env, VITE_DEV_SERVER_URL: devUrl }
});
electron.once("exit", (code) => {
  if (!stopping) stop(code ?? 0);
});
