export type ContentCategory = "anime" | "manga" | "game" | "novel" | "community" | "video";
export type ContentKind = "article" | "video" | "subject" | "post";
export type ContentLanguage = "zh-CN" | "zh-TW" | "en" | "ja" | "ko" | "fr" | "es" | "unknown";
export type ThemeId = "fancy" | "mist-blue" | "midnight-apricot" | "burgundy-blush";

export interface ContentItem {
  id: string;
  provider: string;
  providerLabel: string;
  kind: ContentKind;
  category: ContentCategory;
  title: string;
  summary: string;
  url: string;
  imageUrl?: string;
  author?: string;
  publishedAt: string;
  tags: string[];
  score?: number;
  viewCount?: number;
  likeCount?: number;
  bvid?: string;
  duration?: string;
  recommendationReason?: string;
  sourceLanguage?: ContentLanguage;
  originalTitle?: string;
  originalSummary?: string;
  translated?: boolean;
}

export interface ArticleDocument {
  sourceUrl: string;
  sourceLabel?: string;
  sourceLanguage?: ContentLanguage;
  title: string;
  originalTitle?: string;
  summary: string;
  author?: string;
  publishedAt?: string;
  heroImageUrl?: string;
  paragraphs: string[];
  keyPoints: string[];
  translated?: boolean;
}

export interface ProviderStatus {
  id: string;
  label: string;
  ok: boolean;
  itemCount: number;
  latencyMs: number;
  message?: string;
}

export interface FeedResponse {
  items: ContentItem[];
  providers: ProviderStatus[];
  refreshedAt: string;
  nextCursor?: string;
  fromCache?: boolean;
}

export interface FeedQuery {
  category?: ContentCategory | "all";
  cursor?: string;
  limit?: number;
  forceRefresh?: boolean;
}

export interface SearchResponse {
  query: string;
  groups: Array<{
    provider: string;
    providerLabel: string;
    items: ContentItem[];
    error?: string;
  }>;
  searchedAt: string;
}

export interface UserPreferences {
  personalized: boolean;
  interests: ContentCategory[];
  blockedProviders: string[];
  blockedKeywords: string[];
  seenIds: string[];
  themeId?: ThemeId;
  backgroundImage?: string;
  backgroundOpacity?: number;
  backgroundBlur?: number;
}

export interface PublicAccount {
  id: string;
  displayName: string;
  email: string;
  createdAt: string;
}

export interface RegistrationInput {
  displayName: string;
  email: string;
  password: string;
  confirmPassword: string;
  acceptedTerms: boolean;
}

export interface LoginInput {
  email: string;
  password: string;
}

export interface AuthState {
  account: PublicAccount | null;
  mode?: "remote" | "local-demo";
  endpointConfigured?: boolean;
}

export interface UgcDraft {
  id: string;
  title: string;
  body: string;
  category: ContentCategory;
  contentType: "article" | "art" | "cosplay" | "guide" | "video";
  relatedIp: string;
  ownership: "original" | "authorized" | "curated";
  license: "no-repost" | "attribution" | "non-commercial";
  spoilerLevel: "none" | "light" | "major";
  aiAssistance: "none" | "proofread" | "partial" | "substantial";
  status: "draft" | "reviewing" | "published" | "changes_required" | "appealing";
  createdAt: string;
  updatedAt: string;
  moderation?: ModerationResult;
}

export interface ModerationResult {
  risk: "L0" | "L1" | "L2" | "L3";
  action: "publish" | "warn" | "review" | "block";
  reasons: string[];
  suggestions: string[];
}

export interface CheckinState {
  lastClaimDate?: string;
  streak: number;
  points: number;
  claimedToday: boolean;
  rewardToday: number;
}

export interface BrowserBounds {
  x: number;
  y: number;
  width: number;
  height: number;
}

export interface BrowserState {
  isOpen: boolean;
  url: string;
  title: string;
  loading: boolean;
  canGoBack: boolean;
  canGoForward: boolean;
}
