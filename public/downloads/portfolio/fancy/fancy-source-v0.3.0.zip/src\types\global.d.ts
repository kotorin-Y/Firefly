import type { FancyApi } from "../../electron/preload";

declare global {
  interface Window {
    fancy: FancyApi;
  }
}

export {};
