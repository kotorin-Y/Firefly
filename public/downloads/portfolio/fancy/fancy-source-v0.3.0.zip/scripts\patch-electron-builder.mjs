import fs from "node:fs/promises";
import path from "node:path";

const root = path.resolve(import.meta.dirname, "..");
const target = path.join(root, "node_modules", "app-builder-lib", "out", "util", "electronGet.js");
const marker = "archive rename remained blocked; copying extracted files instead";
const original = `        await fs.rm(dir, { recursive: true, force: true });
        await fs.rename(tmpDir, dir);`;
const replacement = `        await fs.rm(dir, { recursive: true, force: true });
        for (let attempt = 0;; attempt++) {
            try {
                await fs.rename(tmpDir, dir);
                break;
            }
            catch (error) {
                const retryable = error != null && (error.code === "EPERM" || error.code === "EBUSY");
                if (!retryable) {
                    throw error;
                }
                if (attempt >= 4 && process.platform === "win32") {
                    builder_util_1.log.warn({ dir }, "${marker}");
                    await fs.mkdir(dir, { recursive: true });
                    await fs.cp(tmpDir, dir, { recursive: true, force: true });
                    break;
                }
                if (attempt >= 9) {
                    throw error;
                }
                const delay = 400 * (attempt + 1);
                builder_util_1.log.warn({ dir, attempt: attempt + 1, delay }, "archive rename temporarily blocked, retrying");
                await new Promise(resolve => setTimeout(resolve, delay));
            }
        }`;

const source = await fs.readFile(target, "utf8");
if (source.includes(marker)) {
  console.log("electron-builder Windows extraction patch already applied");
} else if (source.includes(original)) {
  await fs.writeFile(target, source.replace(original, replacement), "utf8");
  console.log("applied electron-builder Windows extraction patch");
} else {
  throw new Error("Unsupported app-builder-lib layout; update the compatibility patch before packaging");
}
