import Parser from "rss-parser";
import type {
  ContentCategory,
  ContentItem,
  ContentLanguage,
  FeedQuery
} from "../../../src/shared/contracts.js";
import type { ContentProvider } from "./provider.js";
import { classifyText, secureMediaUrl, stripHtml } from "./provider.js";
import { classifyContent } from "../../../src/features/feed/classification.js";

type CustomFeed = {
  title?: string;
  link?: string;
  pubDate?: string;
  isoDate?: string;
  content?: string;
  contentSnippet?: string;
  creator?: string;
  author?: string;
  enclosure?: { url?: string };
  "media:content"?: { $?: { url?: string } };
  "content:encoded"?: string;
};

export function extractRssImage(item: Pick<
  CustomFeed,
  "content" | "content:encoded" | "enclosure" | "media:content" | "link"
>): string | undefined {
  const explicit = item.enclosure?.url || item["media:content"]?.$?.url;
  if (explicit && !/\.(mp3|m4a|wav|ogg)(\?|$)/i.test(explicit)) return secureMediaUrl(explicit);

  const html = item["content:encoded"] || item.content || "";
  const embedded = html.match(/<img[^>]+src=["']([^"']+)["']/i)?.[1];
  if (embedded) return secureMediaUrl(embedded.replaceAll("&amp;", "&"));

  const fourGamer = item.link?.match(
    /^(https:\/\/www\.4gamer\.net\/games\/\d+\/[A-Z]\d+\/\d+\/)/
  )?.[1];
  return fourGamer ? `${fourGamer}TN/001.jpg` : undefined;
}

export function rssPageBounds(query: FeedQuery): { start: number; end: number } {
  const parsedCursor = Number.parseInt(query.cursor ?? "1", 10);
  const parsedLimit = Number.parseInt(String(query.limit ?? 20), 10);
  const page = Number.isFinite(parsedCursor) && parsedCursor > 0 ? parsedCursor : 1;
  const limit = Number.isFinite(parsedLimit) && parsedLimit > 0 ? parsedLimit : 20;
  const start = (page - 1) * limit;
  return { start, end: start + limit };
}

export function matchesSearchQuery(text: string, query: string): boolean {
  const normalizedText = text.toLocaleLowerCase();
  const tokens = query
    .toLocaleLowerCase()
    .split(/[\s,，、/|]+/u)
    .map((token) => token.trim())
    .filter(Boolean);
  return tokens.length > 0 && tokens.some((token) => normalizedText.includes(token));
}

export class RssProvider implements ContentProvider {
  categories: ContentCategory[];
  private parser = new Parser<Record<string, unknown>, CustomFeed>({
    timeout: 9_000,
    headers: {
      "User-Agent": "FancyACGN/0.1 Desktop Reader"
    },
    customFields: {
      item: [
        ["media:content", "media:content"],
        ["content:encoded", "content:encoded"]
      ]
    }
  });

  constructor(
    public id: string,
    public label: string,
    private url: string,
    categories: ContentCategory[],
    private sourceLanguage: ContentLanguage = "unknown"
  ) {
    this.categories = categories;
  }

  private normalize(item: CustomFeed, index: number): ContentItem {
    const title = stripHtml(item.title ?? "未命名资讯");
    const summary = stripHtml(item.contentSnippet || item.content || "").slice(0, 260);
    const url = item.link || this.url;
    return {
      id: `${this.id}:${Buffer.from(`${url}:${index}`).toString("base64url")}`,
      provider: this.id,
      providerLabel: this.label,
      kind: "article",
      category: this.categories.length === 1
        ? this.categories[0]
        : classifyContent({
          title,
          summary,
          tags: [this.label],
          providerCategories: this.categories
        }).category,
      title,
      summary,
      url,
      imageUrl: extractRssImage(item),
      author: item.creator || item.author,
      publishedAt: new Date(item.isoDate || item.pubDate || Date.now()).toISOString(),
      tags: [this.label],
      sourceLanguage: this.sourceLanguage
    };
  }

  async list(query: FeedQuery): Promise<ContentItem[]> {
    const feed = await this.parser.parseURL(this.url);
    const { start, end } = rssPageBounds(query);
    return feed.items
      .slice(start, end)
      .map((item, index) => this.normalize(item, start + index));
  }

  async search(query: string): Promise<ContentItem[]> {
    const items = await this.list({ limit: 60 });
    return items.filter((item) =>
      matchesSearchQuery(`${item.title} ${item.summary}`, query)
    );
  }
}
