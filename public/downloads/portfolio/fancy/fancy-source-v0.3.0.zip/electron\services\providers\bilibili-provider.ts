import type { ContentItem, FeedQuery } from "../../../src/shared/contracts.js";
import type { ContentProvider } from "./provider.js";
import { classifyText, fetchWithTimeout, secureMediaUrl, stripHtml } from "./provider.js";

interface BiliVideo {
  bvid: string;
  title: string;
  desc?: string;
  pic?: string;
  owner?: { name?: string };
  pubdate?: number;
  duration?: number | string;
  stat?: { view?: number; like?: number };
  author?: string;
  arcurl?: string;
  play?: number;
  like?: number;
}

function formatDuration(value?: number | string): string | undefined {
  if (typeof value === "string") return value;
  if (!value) return undefined;
  const minutes = Math.floor(value / 60);
  const seconds = String(value % 60).padStart(2, "0");
  return `${minutes}:${seconds}`;
}

function normalize(video: BiliVideo): ContentItem {
  const title = stripHtml(video.title);
  return {
    id: `bilibili:${video.bvid}`,
    provider: "bilibili",
    providerLabel: "哔哩哔哩",
    kind: "video",
    category: classifyText(`${title} ${video.desc ?? ""}`),
    title,
    summary: stripHtml(video.desc ?? "来自哔哩哔哩的近期热门视频"),
    url: video.arcurl || `https://www.bilibili.com/video/${video.bvid}`,
    imageUrl: secureMediaUrl(video.pic),
    author: video.owner?.name || video.author,
    publishedAt: new Date((video.pubdate ?? Date.now() / 1000) * 1000).toISOString(),
    tags: ["视频", "Bilibili"],
    viewCount: video.stat?.view ?? video.play,
    likeCount: video.stat?.like ?? video.like,
    bvid: video.bvid,
    duration: formatDuration(video.duration)
    ,
    sourceLanguage: "zh-CN"
  };
}

export class BilibiliProvider implements ContentProvider {
  id = "bilibili";
  label = "哔哩哔哩";
  categories = ["anime", "manga", "game", "novel", "community", "video"] as const;

  async list(query: FeedQuery): Promise<ContentItem[]> {
    const page = Math.max(1, Number(query.cursor || "1"));
    const limit = Math.min(30, query.limit ?? 20);
    const response = await fetchWithTimeout(
      `https://api.bilibili.com/x/web-interface/popular?pn=${page}&ps=${limit}`,
      { headers: { Referer: "https://www.bilibili.com/" } }
    );
    if (!response.ok) throw new Error(`Bilibili HTTP ${response.status}`);
    const payload = await response.json() as { code: number; data?: { list?: BiliVideo[] } };
    if (payload.code !== 0) throw new Error(`Bilibili API ${payload.code}`);
    return (payload.data?.list ?? []).map(normalize);
  }

  async search(query: string): Promise<ContentItem[]> {
    const response = await fetchWithTimeout(
      `https://api.bilibili.com/x/web-interface/search/type?search_type=video&page=1&page_size=18&keyword=${encodeURIComponent(query)}`,
      { headers: { Referer: "https://search.bilibili.com/" } }
    );
    if (!response.ok) throw new Error(`Bilibili search HTTP ${response.status}`);
    const payload = await response.json() as {
      code: number;
      data?: { result?: BiliVideo[] };
    };
    if (payload.code !== 0) throw new Error(`Bilibili search API ${payload.code}`);
    return (payload.data?.result ?? []).map(normalize);
  }
}
