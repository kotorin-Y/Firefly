import { randomUUID } from "node:crypto";
import { safeStorage } from "electron";
import type {
  AuthState,
  LoginInput,
  PublicAccount,
  RegistrationInput
} from "../../src/shared/contracts.js";
import {
  hashPassword,
  validateRegistration,
  verifyPassword
} from "./auth-service.js";
import { localStore, type StoredAccount } from "./local-store.js";
import { RemoteAuthClient } from "./remote-auth-service.js";

const remoteAuthUrl = process.env.FANCY_AUTH_API_URL?.trim();
const remoteClient = remoteAuthUrl ? new RemoteAuthClient(remoteAuthUrl) : null;
let volatileRemoteToken = "";

function saveRemoteToken(token: string): void {
  volatileRemoteToken = token;
  if (!token) {
    localStore.set("remoteAccessToken", "");
    return;
  }
  if (safeStorage.isEncryptionAvailable()) {
    localStore.set("remoteAccessToken", `encrypted:${safeStorage.encryptString(token).toString("base64")}`);
  } else {
    localStore.set("remoteAccessToken", "");
  }
}

function getRemoteToken(): string {
  const saved = localStore.get("remoteAccessToken");
  if (saved.startsWith("encrypted:") && safeStorage.isEncryptionAvailable()) {
    try {
      return safeStorage.decryptString(Buffer.from(saved.slice("encrypted:".length), "base64"));
    } catch {
      localStore.set("remoteAccessToken", "");
    }
  }
  return volatileRemoteToken;
}

function toPublicAccount(account: StoredAccount): PublicAccount {
  const { passwordHash: _passwordHash, passwordSalt: _passwordSalt, ...publicAccount } = account;
  return publicAccount;
}

function authMetadata(): Pick<AuthState, "mode" | "endpointConfigured"> {
  return {
    mode: remoteClient ? "remote" : "local-demo",
    endpointConfigured: Boolean(remoteClient)
  };
}

export async function getAuthState(): Promise<AuthState> {
  if (remoteClient) {
    const token = getRemoteToken();
    if (!token) return { account: null, ...authMetadata() };
    try {
      const session = await remoteClient.restore(token);
      localStore.set("remoteAccount", session.account);
      saveRemoteToken(session.accessToken);
      return { account: session.account, ...authMetadata() };
    } catch {
      localStore.set("remoteAccount", null);
      saveRemoteToken("");
      return { account: null, ...authMetadata() };
    }
  }
  const account = localStore.get("account");
  return {
    account: account && localStore.get("sessionActive") ? toPublicAccount(account) : null,
    ...authMetadata()
  };
}

export async function registerAccount(input: RegistrationInput): Promise<AuthState> {
  const errors = validateRegistration(input);
  const firstError = Object.values(errors)[0];
  if (firstError) throw new Error(firstError);
  if (remoteClient) {
    const session = await remoteClient.register(input);
    localStore.set("remoteAccount", session.account);
    saveRemoteToken(session.accessToken);
    return { account: session.account, ...authMetadata() };
  }

  const email = input.email.trim().toLocaleLowerCase();
  const existing = localStore.get("account");
  if (existing?.email.toLocaleLowerCase() === email) {
    throw new Error("该邮箱已经注册，请直接登录");
  }

  const credential = await hashPassword(input.password);
  const account: StoredAccount = {
    id: randomUUID(),
    displayName: input.displayName.trim(),
    email,
    createdAt: new Date().toISOString(),
    passwordSalt: credential.salt,
    passwordHash: credential.hash
  };
  localStore.set("account", account);
  localStore.set("sessionActive", true);
  return { account: toPublicAccount(account), ...authMetadata() };
}

export async function loginAccount(input: LoginInput): Promise<AuthState> {
  if (remoteClient) {
    const session = await remoteClient.login(input);
    localStore.set("remoteAccount", session.account);
    saveRemoteToken(session.accessToken);
    return { account: session.account, ...authMetadata() };
  }
  const account = localStore.get("account");
  if (!account || account.email.toLocaleLowerCase() !== input.email.trim().toLocaleLowerCase()) {
    throw new Error("邮箱或密码不正确");
  }
  const valid = await verifyPassword(input.password, {
    salt: account.passwordSalt,
    hash: account.passwordHash
  });
  if (!valid) throw new Error("邮箱或密码不正确");
  localStore.set("sessionActive", true);
  return { account: toPublicAccount(account), ...authMetadata() };
}

export async function logoutAccount(): Promise<AuthState> {
  if (remoteClient) {
    const token = getRemoteToken();
    if (token) await remoteClient.logout(token).catch(() => undefined);
    localStore.set("remoteAccount", null);
    saveRemoteToken("");
    return { account: null, ...authMetadata() };
  }
  localStore.set("sessionActive", false);
  return { account: null, ...authMetadata() };
}
