export function findAvailablePort(startPort?: number, attempts?: number): Promise<number>;
