import { Outlet, useLocation } from "react-router-dom";
import { useEffect } from "react";
import { Sidebar } from "../components/Sidebar";
import { Topbar } from "../components/Topbar";
import { AuthModal } from "../components/AuthModal";
import { useAppStore } from "../state/useAppStore";
import { normalizeThemeId } from "../config/themes";
import type { CSSProperties } from "react";

export function AppShell() {
  const location = useLocation();
  const browserMode = location.pathname === "/browser";
  const { preferences, setAccount } = useAppStore();
  const themeId = normalizeThemeId(preferences.themeId);
  const shellStyle = {
    "--user-background-image": preferences.backgroundImage ? `url("${preferences.backgroundImage}")` : "none",
    "--user-background-opacity": String((preferences.backgroundOpacity ?? 26) / 100),
    "--user-background-blur": `${preferences.backgroundBlur ?? 12}px`
  } as CSSProperties;

  useEffect(() => {
    document.documentElement.dataset.theme = themeId;
  }, [themeId]);

  useEffect(() => {
    void window.fancy.auth.state().then((state) => setAccount(state.account));
  }, [setAccount]);

  return (
    <div className={`app-shell ${browserMode ? "app-shell--browser" : ""}`} style={shellStyle}>
      <div className="app-background" aria-hidden="true" />
      <Sidebar />
      <Topbar />
      <main className="app-content">
        <Outlet />
      </main>
      <AuthModal />
    </div>
  );
}
