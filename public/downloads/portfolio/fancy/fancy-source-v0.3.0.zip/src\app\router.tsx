import { createHashRouter } from "react-router-dom";
import { AppShell } from "./AppShell";
import { BrowserPage } from "../pages/BrowserPage";
import { ChannelPage } from "../pages/ChannelPage";
import { CreatePage } from "../pages/CreatePage";
import { CreatorCenterPage } from "../pages/CreatorCenterPage";
import { ForumPage } from "../pages/ForumPage";
import { HomePage } from "../pages/HomePage";
import { FavoritesPage, NotificationsPage, SettingsPage } from "../pages/LibraryPages";
import { ProfilePage } from "../pages/ProfilePage";
import { SearchPage } from "../pages/SearchPage";
import { VideoPage } from "../pages/VideoPage";
import { ArticlePage } from "../pages/ArticlePage";

export const router = createHashRouter([
  {
    path: "/",
    element: <AppShell />,
    children: [
      { index: true, element: <HomePage /> },
      { path: "channel/:category", element: <ChannelPage /> },
      { path: "search", element: <SearchPage /> },
      { path: "browser", element: <BrowserPage /> },
      { path: "video/:provider/:id", element: <VideoPage /> },
      { path: "article/:id", element: <ArticlePage /> },
      { path: "forum", element: <ForumPage /> },
      { path: "create", element: <CreatePage /> },
      { path: "profile", element: <ProfilePage /> },
      { path: "creator", element: <CreatorCenterPage /> },
      { path: "favorites", element: <FavoritesPage /> },
      { path: "notifications", element: <NotificationsPage /> },
      { path: "settings", element: <SettingsPage /> }
    ]
  }
]);
