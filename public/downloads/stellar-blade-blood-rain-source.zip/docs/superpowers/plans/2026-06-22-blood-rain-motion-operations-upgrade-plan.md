# BLOOD RAIN 动效与运营说明升级实现计划

> **面向 AI 代理的工作者：** 必需子技能：使用 superpowers:executing-plans 逐任务实现此计划。步骤使用复选框跟踪。

**目标：** 增加任务终端式转场、官方标题锁定图、运营化说明和跨设备复现方案，并完成 Debug 与代码 Review。

**架构：** 新增独立的 motion preference、section observer 和 transition controller hooks。App 统一协调语言与章节转场，组件只负责触发意图。视觉动效由 CSS class 和自定义属性实现，按 Full/Balanced/Lite 分级。

**技术栈：** React、TypeScript、Vite、Vitest、CSS、Docker、Nginx。

---

### 任务 1：隔离开发和基线

- [ ] 创建功能分支/worktree。
- [ ] 运行现有 18 项测试。
- [ ] 运行生产构建。

### 任务 2：转场和动效状态（TDD）

**文件：**
- 创建：`src/motion.ts`
- 创建：`src/hooks/useMotionProfile.ts`
- 创建：`src/hooks/useSectionReveal.ts`
- 创建：`src/components/TransitionOverlay.tsx`
- 测试：`src/motion.test.ts`
- 测试：`src/components/MotionInteractions.test.tsx`

- [ ] 编写性能模式和转场失败测试。
- [ ] 运行并确认因功能缺失失败。
- [ ] 实现最少状态逻辑。
- [ ] 运行测试通过。

### 任务 3：站内导航、语言与章节显现

- [ ] Header 将站内导航改为回调触发。
- [ ] App 协调章节转场和语言转场。
- [ ] Sections 使用 reveal hook。
- [ ] 弹层加入扫描状态。
- [ ] 测试导航、语言和章节显现。

### 任务 4：官方 Logo 与运营内容

- [ ] 从官方素材裁切标题锁定图。
- [ ] 记录来源和裁切方式。
- [ ] Hero、TransitionOverlay、Footer 引入 Logo。
- [ ] 增强简体中文页面运营文案。
- [ ] 重写 README 为中文游戏运营作品说明。

### 任务 5：交互动效和性能分级

- [ ] 添加 Hero 指针视差。
- [ ] 添加 CTA 磁吸。
- [ ] 添加媒体卡片视差和扫描。
- [ ] 添加 Full/Balanced/Lite CSS。
- [ ] 验证 reduced-motion。

### 任务 6：跨设备复现

- [ ] 移除远程字体。
- [ ] 增加 engines、check 命令、`.nvmrc`。
- [ ] 增加 Dockerfile、`.dockerignore` 和 Nginx 配置。
- [ ] README 添加 Windows/macOS/Linux/Docker 命令。

### 任务 7：Debug、Review 和最终验证

- [ ] 运行自动化测试、check 和 build。
- [ ] Docker 构建验证。
- [ ] 浏览器验证 375/768/1440 和横屏。
- [ ] 检查控制台、资源失败和横向溢出。
- [ ] 请求独立代码 Review，修复 Critical/Important 问题。
- [ ] 合并回 main。

