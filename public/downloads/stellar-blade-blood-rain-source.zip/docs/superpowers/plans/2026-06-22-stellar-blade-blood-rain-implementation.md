# 《Stellar Blade: BLOOD RAIN》宣发网页实现计划

> **面向 AI 代理的工作者：** 必需子技能：使用 superpowers:executing-plans 逐任务实现此计划。步骤使用复选框（`- [ ]`）语法来跟踪进度。

**目标：** 构建一个高完成度、七语言、所有按钮均有真实行为的《Stellar Blade: BLOOD RAIN》非官方概念宣发网站。

**架构：** 使用 Vite + React + TypeScript 构建单页网站。官方事实、外部来源、媒体和七语言文案使用类型安全数据模块集中维护；交互拆分为导航、语言菜单、视频影院、角色档案、画廊灯箱和 FAQ。视觉由响应式 CSS、CSS 雨效和轻量滚动显现完成，不依赖重型 3D。

**技术栈：** React 19、TypeScript、Vite、Vitest、Testing Library、CSS、Lucide React。

---

## 文件结构

- `package.json`：项目命令和依赖。
- `vite.config.ts`：Vite 与 Vitest 配置。
- `tsconfig.json`、`tsconfig.app.json`、`tsconfig.node.json`：TypeScript 配置。
- `index.html`：SEO、Open Graph 和应用入口。
- `src/main.tsx`：React 挂载入口。
- `src/App.tsx`：页面组合与全局弹层状态。
- `src/styles.css`：视觉系统、布局、动效和响应式。
- `src/types.ts`：语言、内容和媒体类型。
- `src/content.ts`：官方事实、来源链接、媒体和七语言文案。
- `src/i18n.ts`：语言识别、读取、写入与内容访问函数。
- `src/components/*`：导航、Hero、章节、弹层、画廊、FAQ 和页脚。
- `src/test/setup.ts`：DOM 测试环境。
- `src/**/*.test.ts(x)`：多语言、交互和内容真实性测试。
- `public/assets/*`：本地视觉素材和来源记录。
- `README.md`：启动、构建、素材来源和作品属性。
- `docs/qa/*`：QA、缺陷和发布检查记录。

### 任务 1：项目骨架与测试环境

**文件：**
- 创建：`package.json`
- 创建：`vite.config.ts`
- 创建：`tsconfig.json`
- 创建：`tsconfig.app.json`
- 创建：`tsconfig.node.json`
- 创建：`index.html`
- 创建：`src/main.tsx`
- 创建：`src/test/setup.ts`

- [ ] **步骤 1：创建最小 Vite/React/TypeScript 配置**
- [ ] **步骤 2：安装依赖**

运行：`npm install`

预期：依赖安装成功，生成 `package-lock.json`。

- [ ] **步骤 3：运行空测试环境**

运行：`npm test -- --run`

预期：测试命令可启动，并报告尚无测试文件。

### 任务 2：多语言与官方事实数据

**文件：**
- 创建：`src/types.ts`
- 创建：`src/i18n.test.ts`
- 创建：`src/i18n.ts`
- 创建：`src/content.ts`

- [ ] **步骤 1：编写失败测试**

测试七种语言均存在、语言回退为英语、内容关键路径完整，并确认平台和发售日状态为“未公布”。

- [ ] **步骤 2：运行测试验证失败**

运行：`npm test -- --run src/i18n.test.ts`

预期：FAIL，原因是 `i18n.ts` 和 `content.ts` 尚不存在。

- [ ] **步骤 3：实现最小语言和内容模块**
- [ ] **步骤 4：运行测试验证通过**

运行：`npm test -- --run src/i18n.test.ts`

预期：全部 PASS。

### 任务 3：页面结构与可操作导航

**文件：**
- 创建：`src/App.test.tsx`
- 创建：`src/App.tsx`
- 创建：`src/components/Header.tsx`
- 创建：`src/components/Hero.tsx`
- 创建：`src/components/Sections.tsx`
- 创建：`src/components/Footer.tsx`

- [ ] **步骤 1：编写失败测试**

测试首页渲染、七语言菜单、主要章节、Hero 两个 CTA 和官方外链。

- [ ] **步骤 2：运行测试验证失败**

运行：`npm test -- --run src/App.test.tsx`

预期：FAIL，原因是页面组件尚不存在。

- [ ] **步骤 3：实现最小页面结构**
- [ ] **步骤 4：运行测试验证通过**

运行：`npm test -- --run src/App.test.tsx`

预期：全部 PASS。

### 任务 4：弹层、画廊和 FAQ 交互

**文件：**
- 创建：`src/components/Interactions.test.tsx`
- 创建：`src/components/VideoModal.tsx`
- 创建：`src/components/CharacterDrawer.tsx`
- 创建：`src/components/Gallery.tsx`
- 创建：`src/components/Faq.tsx`

- [ ] **步骤 1：编写失败测试**

测试视频弹窗打开/关闭、角色档案打开、画廊前后切换、FAQ 展开及 Escape 关闭。

- [ ] **步骤 2：运行测试验证失败**

运行：`npm test -- --run src/components/Interactions.test.tsx`

预期：FAIL，原因是交互组件尚不存在。

- [ ] **步骤 3：实现最小交互**
- [ ] **步骤 4：运行测试验证通过**

运行：`npm test -- --run src/components/Interactions.test.tsx`

预期：全部 PASS。

### 任务 5：官方素材、本地视觉和来源记录

**文件：**
- 创建：`public/assets/reveal-hero.jpg`
- 创建：`public/assets/reveal-city.jpg`
- 创建：`public/assets/reveal-combat.jpg`
- 创建：`public/assets/media-frame-*.jpg`
- 创建：`public/assets/SOURCES.md`

- [ ] **步骤 1：从 SHIFT UP/官方预告获取公开宣传素材**
- [ ] **步骤 2：保存本地文件并记录原始 URL、用途和日期**
- [ ] **步骤 3：检查图片尺寸和文件完整性**

运行：PowerShell 图片属性检查命令。

预期：所有页面引用图片存在且可读取。

### 任务 6：电影式视觉系统与响应式

**文件：**
- 创建：`src/styles.css`
- 修改：`src/App.tsx`
- 修改：`src/components/*.tsx`

- [ ] **步骤 1：实现设计 token、12 栏布局和电影式 Hero**
- [ ] **步骤 2：实现雨线、扫描线、滚动显现和 HUD 细节**
- [ ] **步骤 3：实现 768px 和 480px 响应式规则**
- [ ] **步骤 4：实现 reduced-motion、焦点和高对比状态**
- [ ] **步骤 5：运行组件测试确认行为未回归**

运行：`npm test -- --run`

预期：全部 PASS。

### 任务 7：README 与交付证据

**文件：**
- 创建：`README.md`
- 创建：`docs/qa/test-cases.md`
- 创建：`docs/qa/defect-log.md`
- 创建：`docs/qa/release-checklist.md`

- [ ] **步骤 1：记录启动、构建和项目性质**
- [ ] **步骤 2：记录素材来源和官方/编辑内容边界**
- [ ] **步骤 3：创建功能、语言、响应式和发布检查表**

### 任务 8：自动化与浏览器验收

**文件：**
- 修改：必要的源文件和测试文件。

- [ ] **步骤 1：运行全部测试**

运行：`npm test -- --run`

预期：0 个失败。

- [ ] **步骤 2：运行 TypeScript 与生产构建**

运行：`npm run build`

预期：exit 0，生成 `dist/`。

- [ ] **步骤 3：启动本地服务器并使用浏览器测试**

验证：

- 七语言切换。
- 导航锚点。
- 视频弹窗。
- 角色档案。
- 画廊。
- FAQ。
- 所有外部链接。
- 375px、768px、1440px。
- 控制台无阻塞错误。

- [ ] **步骤 4：修复每个发现问题时先增加失败测试**
- [ ] **步骤 5：重新运行测试和构建，记录最终结果**

